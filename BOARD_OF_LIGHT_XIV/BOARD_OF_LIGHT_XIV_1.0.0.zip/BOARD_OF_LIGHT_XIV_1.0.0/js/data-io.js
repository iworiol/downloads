// ===== js/images.js =====
// images: shared function declarations; initialized by bolxiv.js in the documented order.
function linearKnockbackSvg(color,id){const paths=Array.from({length:4},(_,row)=>Array.from({length:3},(_,col)=>{const x=28+col*32,y=20+row*22;return '<path d="M'+(x-11)+' '+(y+6)+'L'+x+' '+y+'L'+(x+11)+' '+(y+6)+'"/>'}).join('')).join('');return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 110" aria-hidden="true"><defs><filter id="'+id+'" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="3"/></filter></defs><g fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="'+color+'" stroke-width="13" filter="url(#'+id+')" opacity=".9">'+paths+'</g><g stroke="'+color+'" stroke-width="8">'+paths+'</g><g stroke="#fff4bf" stroke-width="3">'+paths+'</g></g></svg>'}

function knockbackSvg(color,id){const rays=Array.from({length:10},(_,i)=>'<g transform="rotate('+i*36+' 100 100)">'+[[28,3.5,4,1.7],[36,4.8,5,2],[48,7,7,2.7],[65,10,9,4],[80,12,10,4.6]].map(([r,w,h,t])=>'<path d="M'+(100-w)+' '+(100-r+h)+'L100 '+(100-r)+'L'+(100+w)+' '+(100-r+h)+'" stroke-width="'+t+'"/>').join('')+'</g>').join('');return '<svg viewBox="0 0 200 200" aria-hidden="true"><defs><filter id="'+id+'" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="4"/></filter></defs><g fill="none" stroke-linecap="square" stroke-linejoin="miter"><g stroke="'+color+'" filter="url(#'+id+')" opacity=".95">'+rays.replace(/stroke-width="([\d.]+)"/g,(_,w)=>'stroke-width="'+(Number(w)+13)+'"')+'</g><g stroke="'+color+'" opacity=".9">'+rays.replace(/stroke-width="([\d.]+)"/g,(_,w)=>'stroke-width="'+(Number(w)+5)+'"')+'</g><g stroke="#fff3c4">'+rays+'</g></g></svg>'}

function fieldImageSource(board=data,index=board.page){return boardImageLibrary.get(board.pageFieldImageIds?.[index])}

function objectImageSource(object){return object.imageId?boardImageLibrary.get(object.imageId):embeddedPngs[object.src]||object.src}

// Original bytes belong to the image library; decoded stills are a memory-only cache.
const importedImageCache=new Map();
const emptyImportedImage='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/%3E';
async function decodeImportedImage(source){
 const image=new Image();image.src=source;await image.decode();
 const width=image.naturalWidth,height=image.naturalHeight;if(!width||!height)throw new Error('画像の大きさを取得できませんでした');
 const blob=await (await fetch(source)).blob();let frame=null,decoder=null;
 let freeze=/image\/(gif|svg\+xml)/i.test(blob.type);
 try{
  if(typeof ImageDecoder!=='undefined'&&await ImageDecoder.isTypeSupported(blob.type)){
   decoder=new ImageDecoder({data:await blob.arrayBuffer(),type:blob.type,preferAnimation:true});await decoder.tracks.ready;
   if(decoder.tracks.selectedTrack?.animated){freeze=true;frame=(await decoder.decode({frameIndex:0})).image}
  }else if(/image\/(png|webp|avif)/i.test(blob.type)){
   const bytes=new Uint8Array(await blob.arrayBuffer()),tag=(offset,count)=>String.fromCharCode(...bytes.subarray(offset,offset+count));
   if(/png/i.test(blob.type)){for(let offset=8;offset+12<=bytes.length;){const size=new DataView(bytes.buffer).getUint32(offset);if(tag(offset+4,4)==='acTL'){freeze=true;break}offset+=size+12}}
   else if(/webp/i.test(blob.type)){for(let offset=12;offset+8<=bytes.length;){const size=new DataView(bytes.buffer).getUint32(offset+4,true);if(tag(offset,4)==='ANIM'){freeze=true;break}offset+=8+size+(size%2)}}
   else freeze=tag(0,Math.min(64,bytes.length)).includes('avis');
  }
  if(!freeze)return {width,height,preview:source};
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
  const context=canvas.getContext('2d');if(!context)throw new Error('画像を静止画として読み込めませんでした');
  context.drawImage(frame||image,0,0,width,height);const preview=canvas.toDataURL('image/png');
  if(!preview.startsWith('data:image/png'))throw new Error('画像を静止画として読み込めませんでした');
  return {width,height,preview};
 }finally{frame?.close();decoder?.close()}
}
function importedImageRecord(source){
 let record=importedImageCache.get(source);if(record)return record;
 record={value:null,promise:null};record.promise=decodeImportedImage(source).then(value=>(record.value=value));
 importedImageCache.set(source,record);record.promise.catch(()=>{if(importedImageCache.get(source)===record)importedImageCache.delete(source)});return record;
}
function bindImportedImage(image,object){
 image.dataset.importedImageId=object.imageId;const record=importedImageRecord(boardImageLibrary.requireImage(object.imageId));
 image.src=record.value?.preview||emptyImportedImage;
 record.promise.then(value=>{if(image.dataset.importedImageId===object.imageId)image.src=value.preview}).catch(()=>{image.alt='画像を読み込めませんでした';if(!record.notified){record.notified=true;notify('配置した画像を読み込めませんでした')}});
}
async function prepareImportedImageElements(root){
 await Promise.all([...root.querySelectorAll('img[data-imported-image-id]')].map(async image=>{
  const value=await importedImageRecord(boardImageLibrary.requireImage(image.dataset.importedImageId)).promise;
  image.src=value.preview;await image.decode();
 }));
}
function selectionHasImportedImages(items=current().filter(o=>selectedIds.includes(o.id))){return items.some(o=>o.type==='image')}

function migrateBoardImages(board,externalLibrary){
 const resolve=id=>{
  if(!id)return '';
  if(externalLibrary){const record=Object.hasOwn(externalLibrary,id)?externalLibrary[id]:null;if(!record||typeof record.source!=='string')throw new Error('画像ライブラリの参照先が見つかりません：'+id);return boardImageLibrary.register(record.source,record)}
  boardImageLibrary.requireImage(id);return id;
 };
 board.pageFieldImageIds=board.pages.map((_,i)=>{
  const image=board.pageFieldImageIds?.[i]??board.pageFieldImages?.[i]??'';
  return typeof image==='string'&&image.startsWith('data:image/')?boardImageLibrary.register(image):resolve(image);
 });
 delete board.pageFieldImages;
 let changedPages=false;const pages=board.pages.map(page=>{let changed=false;const objects=page.map(object=>{
  if(object.imageId){const id=resolve(object.imageId);if(id===object.imageId)return object;changed=true;return {...object,imageId:id}};
  if(typeof object.src==='string'&&object.src.startsWith('data:image/')){changed=true;const {src,...rest}=object;return {...rest,imageId:boardImageLibrary.register(src)}}
  return object;
 });if(changed){changedPages=true;return objects}return page;});
 if(changedPages)board.pages=pages;
 return board;
}

function iconPath(name,folder){if(folder==='00_ROLE'&&name==='MeleeDPS')return 'assets/job-icons/00_ROLE/MeleeDPS.svg';if(folder==='00_ROLE'&&name==='RangedDPS')return 'assets/job-icons/00_ROLE/RangedDPS.svg';if(folder==='field-marker-transparent'&&['1','2','3','4'].includes(name))return 'assets/field-marker-transparent/'+name+'.svg';if(folder==='field-marker-transparent'&&['b','c','d'].includes(name))return 'assets/field-marker-transparent/'+name+'.svg';if(folder==='field-marker-transparent'&&name==='a')return 'assets/field-marker-transparent/a.svg';if(folder==='field-marker-transparent'&&name==='1')return 'assets/field-marker-transparent/1.svg';let root=folder==='target-marker'||folder.startsWith('field-marker')?'assets':'assets/job-icons';return `${root}/${folder}/${name}.png`}

function isBossObject(o){return o.type==='icon'&&['大ボス','中ボス','小ボス'].includes(o.iconName)}

function bossDefaultColor(name){return {'大ボス':'#6b247d','中ボス':'#235b9c','小ボス':'#c8202d'}[name]||'#6b247d'}

function bossIconSource(o){const template=bossIconTemplates[o.iconName];if(!template)return isTowerObject(o)?towerIconSource(o):objectImageSource(o);const base=/^#[0-9a-f]{6}$/i.test(o.color)?o.color:bossDefaultColor(o.iconName);let svg=template;if(base.toLowerCase()!==bossDefaultColor(o.iconName)){const tint=amount=>'#'+[1,3,5].map(i=>Math.round(parseInt(base.slice(i,i+2),16)*(1-amount)+255*amount).toString(16).padStart(2,'0')).join('');const palette={'大ボス':['#6b247d','#e5a4ff','#f2c8ff'],'中ボス':['#235b9c','#8bc8ff','#d8efff'],'小ボス':['#c8202d','#ff7b83','#ffd9dc']}[o.iconName];const colors=[base,tint(.55),tint(.8)];svg=svg.replace(/#[0-9a-f]{6}/gi,color=>{const index=palette.indexOf(color.toLowerCase());return index<0?color:colors[index]})}return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg)}

function isTowerObject(o){return o.type==='icon'&&/^(塔踏み[1-4]|塔ふみ1)$/.test(o.iconName||'')}

function towerIconSource(o){const base=/^#[0-9a-f]{6}$/i.test(o.color)?o.color:'#f39c12';const tint=(amount,toward=255)=>'#'+[1,3,5].map(i=>Math.round(parseInt(base.slice(i,i+2),16)*(1-amount)+toward*amount).toString(16).padStart(2,'0')).join('');const colors={'#f39c12':base,'#fad59b':tint(.58),'#b6750e':tint(.25,0)};const count=Math.max(1,Math.min(4,Number(String(o.iconName||'').slice(-1))||1));const svg=towerIconTemplates[count].replace(/#[0-9a-f]{6}/gi,color=>colors[color.toLowerCase()]||color);return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg)}

;
// ===== js/phases.js =====
// phases: shared function declarations; initialized by bolxiv.js in the documented order.
function phaseComparisonLayout(count=selectedPhaseIndexes.length){const cellSize=count===1?640:320,columns=count===1?1:count<=4?2:count<=9?3:4,rows=count===1?1:count<=4?2:count<=9?3:Math.max(2,Math.ceil(count/columns));return {columns,rows,cellSize,width:columns*cellSize,height:rows*cellSize}}

function phaseComparisonActive(){return !phaseComparisonRendering&&selectedPhaseIndexes.length>1}

let phaseListSelectionAnchor=null;
function selectPhaseFromList(index,event){
 const additive=!!(event.ctrlKey||event.metaKey),owner=phaseListSelectionAnchor?.board===data?phaseListSelectionAnchor:null;
 if(event.shiftKey){const anchor=owner?data.pages.indexOf(owner.page):data.page,start=anchor>=0?anchor:index,range=Array.from({length:Math.abs(index-start)+1},(_,i)=>Math.min(start,index)+i),ids=additive?[...new Set([...selectedPhaseIndexes,...range])]:range;if(ids.length>12){notify('選択できるフェーズは最大12個です');return}if(!owner)phaseListSelectionAnchor={board:data,page:data.pages[start]};selectPhase(index,false,ids);return}
 if(additive){if(!selectedPhaseIndexes.length)selectedPhaseIndexes=[data.page];selectPhase(index,true)}else selectPhase(index);
 phaseListSelectionAnchor={board:data,page:data.pages[index]};
}
// Yield once before expensive desktop comparison rendering so the cursor can paint.
let desktopDisplayBusyCount=0,phaseDisplayRequest=0;
function beginDesktopDisplayBusy(){
 if(!matchMedia('(min-width:851px)').matches)return ()=>{};
 desktopDisplayBusyCount++;document.documentElement.classList.add('phase-display-busy');let finished=false;
 return ()=>{if(finished)return;finished=true;if(--desktopDisplayBusyCount===0)document.documentElement.classList.remove('phase-display-busy')};
}
async function yieldDesktopBusyPaint(){if(matchMedia('(min-width:851px)').matches)await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))}
async function withDesktopDisplayBusy(operation){const finish=beginDesktopDisplayBusy();try{await yieldDesktopBusyPaint();return await operation()}finally{finish()}}
function renderSelectedPhases(){
 const request=++phaseDisplayRequest;
 if(!matchMedia('(min-width:851px)').matches||selectedPhaseIndexes.length<2&&!document.querySelector('.phase-comparison-grid')){render();return}
 const finish=beginDesktopDisplayBusy();
 requestAnimationFrame(()=>requestAnimationFrame(()=>{try{if(request===phaseDisplayRequest)render()}finally{requestAnimationFrame(finish)}}));
}
function selectPhase(index,extend=false,rangeSelection=null){if(!Number.isInteger(index)||index<0||index>=data.pages.length)return;const previousPage=data.page;if(phaseSelectionOwner!==data){phaseSelectionOwner=data;selectedPhaseIndexes=[]}if(rangeSelection){data.page=index;selectedPhaseIndexes=rangeSelection}else if(!extend){data.page=index;selectedPhaseIndexes=[];phaseListSelectionAnchor={board:data,page:data.pages[index]}}else if(selectedPhaseIndexes.includes(index)){selectedPhaseIndexes=selectedPhaseIndexes.filter(i=>i!==index)}else{if(selectedPhaseIndexes.length>=12){document.querySelectorAll('#pages .phase-select-check').forEach((check,i)=>check.checked=selectedPhaseIndexes.includes(i));notify('選択できるフェーズは最大12個です');return}selectedPhaseIndexes.push(index)}if(selectedPhaseIndexes.length===1)data.page=selectedPhaseIndexes[0];selected=null;selectedIds=[];drag=null;clearAlignmentGuides();closeObjectContextMenu();closeColorPopovers();renderSelectedPhases();if(data.page!==previousPage)save(true)}

function comparisonStageClone(index){const clone=stage.cloneNode(true),prefix='phase-preview-'+index+'-';const ids=new Map();for(const node of [clone,...clone.querySelectorAll('[id]')]){if(!node.id)continue;ids.set(node.id,prefix+node.id);node.id=prefix+node.id}for(const node of [clone,...clone.querySelectorAll('*')]){for(const attr of Array.from(node.attributes)){let value=attr.value.replace(/url\(\s*(['"]?)(.*?)\1\s*\)/g,(match,quote,url)=>{const hash=url.lastIndexOf('#'),id=hash>=0?url.slice(hash+1):'',newId=ids.get(id);return newId?'url("#'+newId+'")':match});if(value.startsWith('#')&&ids.has(value.slice(1)))value='#'+ids.get(value.slice(1));if(value!==attr.value)node.setAttribute(attr.name,value)}node.removeAttribute('contenteditable');node.removeAttribute('tabindex');node.classList.remove('selected','selected-many','has-selection-controls')}clone.querySelector('[id="'+prefix+'objectControls"]')?.remove();clone.classList.add('phase-preview-stage');return clone}

// Reuse unchanged phase previews while the user adds or removes selections.
const phasePreviewCaches=new WeakMap();
function phasePreviewCache(board){let cache=phasePreviewCaches.get(board);if(!cache){cache=new Map();phasePreviewCaches.set(board,cache)}return cache}
function renderPhaseComparison(){const surface=document.getElementById('boardZoomSpace');surface.querySelector('.phase-comparison-grid')?.remove();const active=phaseComparisonActive();document.body.classList.toggle('phase-comparison-active',active);if(active){const grid=document.createElement('div');grid.className='phase-comparison-grid';const layout=phaseComparisonLayout();grid.style.gridTemplateColumns='repeat('+layout.columns+','+layout.cellSize+'px)';grid.style.gridTemplateRows='repeat('+layout.rows+','+layout.cellSize+'px)';grid.style.width=layout.width+'px';grid.style.height=layout.height+'px';grid.style.transform='translate(-50%,-50%) scale('+boardDisplayZoom/100+')';grid.setAttribute('aria-label','フェーズを並べて表示（閲覧専用）');const original=data,originalSelected=selected,originalIds=selectedIds,cache=phasePreviewCache(original),{pages:ignoredPages,page:ignoredPage,...metadata}=original,context=JSON.stringify([metadata,gridVisible,fieldVisible,fieldClipEnabled,boardReadOnly]);let drewPhase=false;phaseComparisonRendering=true;try{selected=null;selectedIds=[];for(const index of selectedPhaseIndexes){const page=original.pages[index],key=context+'|'+index+'|'+JSON.stringify(page);let record=cache.get(page),tile;if(record?.key===key){tile=record.tile;cache.delete(page);cache.set(page,record)}else{if(!drewPhase){data=JSON.parse(JSON.stringify(original));drewPhase=true}data.page=index;renderSingle();tile=comparisonStageClone(index);cache.delete(page);cache.set(page,{key,tile});while(cache.size>12)cache.delete(cache.keys().next().value);}const cell=document.createElement('div');cell.className='phase-comparison-cell';cell.style.width=cell.style.height=layout.cellSize+'px';const label=document.createElement('div');label.className='phase-comparison-label';label.textContent=String(index+1).padStart(2,'0')+' '+(data.pageNames[index]||'');label.title=label.textContent;tile.style.transform='scale('+(layout.cellSize/640)+')';cell.appendChild(tile);cell.appendChild(label);grid.appendChild(cell)}}finally{data=original;selected=originalSelected;selectedIds=originalIds;try{if(drewPhase)renderSingle()}finally{phaseComparisonRendering=false}}surface.appendChild(grid);document.getElementById('inspector').textContent='閲覧中は設定を変更できません。並列表示中はフェーズを1つに戻すと元のモードに戻ります。閲覧モードの場合は、編集モードに切り替えてください。';document.getElementById('toggleInspector').textContent='オブジェクト：閲覧専用';document.getElementById('toggleInspector').title='オブジェクト：閲覧専用\nオブジェクト設定を開閉';document.getElementById('selectionTitle').textContent='フェーズを並べて表示：'+selectedPhaseIndexes.map(i=>String(i+1).padStart(2,'0')).join('・');document.getElementById('selectionTitle').title=document.getElementById('selectionTitle').textContent}
document.getElementById('phaseComparisonStatus').hidden=selectedPhaseIndexes.length===0;document.getElementById('phaseComparisonStatus').classList.remove('comparison-pending');document.getElementById('phaseComparisonCount').textContent=active?'表示中：'+selectedPhaseIndexes.length:selectedPhaseIndexes.length===1?'選択中：1':'';document.getElementById('exitPhaseComparison').hidden=selectedPhaseIndexes.length===0;updateComparisonPropertyMessage(active||boardReadOnly);if(boardReadOnly){document.getElementById('inspector').textContent='閲覧中は設定を変更できません。並列表示中はフェーズを1つに戻すと元のモードに戻ります。閲覧モードの場合は、編集モードに切り替えてください。';document.getElementById('toggleInspector').textContent='オブジェクト：閲覧専用'}updateModeStatus();setBoardDisplayZoom(boardDisplayZoom,false,false);for(const id of ['clearBtn','undo','redo','addPage','copyPage','copyPageToContent']){const button=document.getElementById(id);if(button)button.disabled=active||(id==='undo'?history.length===0:id==='redo'?future.length===0:false)}if(active)document.querySelectorAll('#layoutPropertiesPanel input,#layoutPropertiesPanel select,#layoutPropertiesPanel button').forEach(node=>node.disabled=true);document.getElementById('pages').querySelectorAll('.page-tab').forEach((tab,i)=>{tab.classList.toggle('phase-selected',selectedPhaseIndexes.includes(i));tab.setAttribute('aria-pressed',String(active?selectedPhaseIndexes.includes(i):i===data.page));tab.draggable=!active;const checkbox=tab.querySelector('.phase-select-check');if(checkbox)checkbox.checked=selectedPhaseIndexes.includes(i);tab.querySelector('.page-tab-x').disabled=active;const renameButton=tab.querySelector('.page-tab-edit');if(renameButton)renameButton.disabled=active})}

function updateComparisonPropertyMessage(active){const panel=document.getElementById('layoutPropertiesPanel');let message=panel.querySelector('.comparison-property-message');if(!message){message=document.createElement('div');message.className='comparison-property-message';message.textContent='閲覧中は設定を変更できません。並列表示中はフェーズを1つに戻すと元のモードに戻ります。閲覧モードの場合は、編集モードに切り替えてください。';panel.prepend(message)}message.hidden=!active;}

function phaseComparisonBlocksTarget(target){return !!target.closest('#objects,#objectControls,#objectList,#inspector,#layoutPropertiesPanel,#objectContextMenu,.object-layout-rect,.phase-comparison-grid,.left .icon-choice,.left .tool,#clearBtn,#clearYes,#confirmYes,#addPage,#copyPage,#copyPageToContent,#undo,#redo,#fieldImageInput')}

function renderPages(){updateSelectionLabel();document.getElementById('activePhaseIndex').textContent=String(data.page+1).padStart(2,'0');document.getElementById('activePhaseLabel').textContent=data.pageNames[data.page]||'';document.getElementById('activePhaseLabel').title=data.pageNames[data.page]||'';let box=$('#pages');const listKey=!data.phaseGroups?.length?JSON.stringify([data.pageNames,data.pages.length,data.page,selectedPhaseIndexes,boardReadOnly,data.activePhaseGroup,phaseComparisonRendering,!!window.Bolxiv?.phaseMasters?.active]):null,cached=box._phaseRowsCache;if(listKey&&cached?.owner===data&&cached.key===listKey&&cached.rows.length===box.children.length&&cached.rows.every((row,i)=>box.children[i]===row)&&!box.contains(document.activeElement))return;box._phaseRowsCache=null;box.innerHTML='';data.pages.forEach((_,i)=>{const {row:b,index,label,action:del}=createListItemView({model:{name:data.pageNames[i],number:i+1,active:i===data.page,selected:!data.activePhaseGroup&&(selectedPhaseIndexes.length?selectedPhaseIndexes.includes(i):i===data.page)},select:e=>{selectPhaseFromList(i,e);document.querySelector('#pages .page-tab.active')?.focus()},activate:e=>selectPhaseFromList(i,e),resolveRow:()=>document.querySelector('#pages .page-tab.active'),action:()=>deleteCurrentPage(i)});b.classList.add('page');b.title=(data.pageNames[i]||'フェーズ'+(i+1))+'\nクリックで単独選択、Shift＋クリックで範囲選択、Ctrl＋クリックで追加・解除（最大12個）。チェックでも追加・解除\n右クリック／長押しで操作メニュー';let check=document.createElement('input');check.type='checkbox';check.className='phase-select-check';check.checked=selectedPhaseIndexes.includes(i);check.title=check.checked?'このフェーズを表示対象から外す':'このフェーズを表示対象にする';check.setAttribute('aria-label','フェーズ'+(i+1)+(check.checked?'を表示対象から外す':'を表示対象にする'));check.onclick=e=>{e.stopPropagation();selectPhase(i,true)};b.insertBefore(check,label);del.title='このフェーズを削除';b.draggable=true;b.ondblclick=null;b.ondragstart=e=>{e.dataTransfer.setData('application/x-tactica-page',String(i));e.dataTransfer.effectAllowed='move';b.classList.add('dragging')};b.ondragend=()=>b.classList.remove('dragging');b.ondragover=e=>{if(!Array.from(e.dataTransfer.types).includes('application/x-tactica-page')){b.classList.remove('drag-over','drop-before','drop-after');return}e.preventDefault();let after=e.clientY>b.getBoundingClientRect().top+b.offsetHeight/2;b.classList.add('drag-over');b.classList.toggle('drop-after',after);b.classList.toggle('drop-before',!after);e.dataTransfer.dropEffect='move'};b.ondragleave=()=>b.classList.remove('drag-over','drop-before','drop-after');b.ondrop=e=>{if(!Array.from(e.dataTransfer.types).includes('application/x-tactica-page')){b.classList.remove('drag-over','drop-before','drop-after');return}e.preventDefault();b.classList.remove('drag-over','drop-before','drop-after');let from=Number(e.dataTransfer.getData('application/x-tactica-page')),to=i;if(!Number.isInteger(from)||from===to)return;let groupMap=new Map(data.pages.map((page,index)=>[page,data.pageGroupIds[index]]));let comparisonPages=selectedPhaseIndexes.map(index=>data.pages[index]);let currentPage=data.pages[data.page],pages=data.pages.slice(),names=data.pageNames.slice(),notes=data.pageNotes.slice(),colors=data.pageColors.slice(),shapes=data.pageBoardShapes.slice(),fieldBackgrounds=data.pageFieldBackgroundColors.slice(),fieldImages=data.pageFieldImageIds.slice(),fieldImageTints=data.pageFieldImageTints.slice(),fieldSizes=data.pageFieldSizes.slice(),moving=pages[from],movingName=names[from],movingNote=notes[from],movingColor=colors[from],movingShape=shapes[from],movingFieldBackground=fieldBackgrounds[from],movingFieldImage=fieldImages[from],movingFieldImageTint=fieldImageTints[from],movingFieldSize=fieldSizes[from];recordHistory();pages.splice(from,1);names.splice(from,1);notes.splice(from,1);colors.splice(from,1);shapes.splice(from,1);fieldBackgrounds.splice(from,1);fieldImages.splice(from,1);fieldImageTints.splice(from,1);fieldSizes.splice(from,1);let at=pages.indexOf(data.pages[to])+(e.clientY>b.getBoundingClientRect().top+b.offsetHeight/2?1:0);pages.splice(at,0,moving);names.splice(at,0,movingName);notes.splice(at,0,movingNote);colors.splice(at,0,movingColor);shapes.splice(at,0,movingShape);fieldBackgrounds.splice(at,0,movingFieldBackground);fieldImages.splice(at,0,movingFieldImage);fieldImageTints.splice(at,0,movingFieldImageTint);fieldSizes.splice(at,0,movingFieldSize);data.pages=pages;data.pageGroupIds=pages.map(page=>groupMap.get(page)||null);data.pageNames=names;data.pageNotes=notes;data.pageColors=colors;data.pageBoardShapes=shapes;data.pageFieldBackgroundColors=fieldBackgrounds;data.pageFieldImageIds=fieldImages;data.pageFieldImageTints=fieldImageTints;data.pageFieldSizes=fieldSizes;data.page=data.pages.indexOf(currentPage);selectedPhaseIndexes=comparisonPages.map(page=>data.pages.indexOf(page));openPhaseListForCreation(at);renderAndSave();revealCreatedPhase(at)};box.appendChild(b)});if(listKey)box._phaseRowsCache={owner:data,key:listKey,rows:[...box.children]}}

function deleteCurrentPage(index=data.page){if(phaseComparisonActive())return;recordHistory();selectedPhaseIndexes=[];data.pages.splice(index,1);data.pageMasterIds?.splice(index,1);data.pageGroupIds.splice(index,1);data.pageNames.splice(index,1);data.pageNotes.splice(index,1);data.pageColors.splice(index,1);data.pageBoardShapes.splice(index,1);data.pageFieldBackgroundColors.splice(index,1);data.pageFieldImageIds.splice(index,1);data.pageFieldImageTints.splice(index,1);data.pageFieldGuides.splice(index,1);data.pageFieldSizes.splice(index,1);if(!data.pages.length){data.pageMasterIds=['initial'];data.pageGroupIds=[null];data.pages=[[]];data.pageFieldGuides=[fieldGuides({},0)];data.pageNames=['新規フェーズ'];data.pageNotes=[''];data.pageColors=['#ffffff'];data.pageBoardShapes=['square'];data.pageFieldBackgroundColors=['#17212c'];data.page=0}else data.page=Math.min(index,data.pages.length-1);selected=null;selectedIds=[];renderAndSave();notify('フェーズを削除しました')}

function normalizePhaseGroups(board){
 if(!Array.isArray(board.phaseGroups))board.phaseGroups=[];
 const ids=new Set();board.phaseGroups=board.phaseGroups.filter(group=>group&&typeof group.id==='string'&&!ids.has(group.id)&&ids.add(group.id)).map(group=>({...group,name:String(group.name||'新規グループ'),note:String(group.note||''),collapsed:!!group.collapsed}));
 board.pageGroupIds=board.pages.map((_,i)=>ids.has(board.pageGroupIds?.[i])?board.pageGroupIds[i]:null);
 if(!ids.has(board.activePhaseGroup))board.activePhaseGroup=null;
}

function normalizePageNames(){normalizeObjectGroups(data);normalizePhaseGroups(data);data.pageFieldImageTints=data.pages.map((_,i)=>fieldImageTint(data,i));delete data.pageFieldImageOpacities;data.pageNotes=data.pages.map((_,i)=>typeof data.pageNotes?.[i]==='string'?data.pageNotes[i]:'');let defaults=['メイン','サブ','予備','前半','後半','処理','戻し','練習'];if(!/^#[0-9a-f]{6}$/i.test(data.layoutColor||''))data.layoutColor='#17212c';if(!Array.isArray(data.pageColors))data.pageColors=[];data.pageColors=data.pages.map((_,i)=>/^#[0-9a-f]{6}$/i.test(data.pageColors[i]||'')?data.pageColors[i]:data.layoutColor);if(!Array.isArray(data.pageBoardShapes))data.pageBoardShapes=[];let legacyShape=['none','square','landscape','portrait','circle','image','image4'].includes(data.boardShape)?data.boardShape:'square';data.pageBoardShapes=data.pages.map((_,i)=>['none','square','landscape','portrait','circle','image','image4'].includes(data.pageBoardShapes[i])?data.pageBoardShapes[i]:legacyShape);if(!Array.isArray(data.pageFieldSizes))data.pageFieldSizes=[];data.pageFieldSizes=data.pages.map((_,i)=>{let size=data.pageFieldSizes[i]||{},shape=data.pageBoardShapes[i],width=Math.max(64,Math.min(['image','image4'].includes(shape)?960:640,Number(size.width)||(shape==='portrait'?320:538))),height=Math.max(64,Math.min(['image','image4'].includes(shape)?960:640,Number(size.height)||(shape==='landscape'?320:538)));if(shape==='landscape'&&width<=height){width=538;height=320}else if(shape==='portrait'&&height<=width){width=320;height=538}return{width,height}});data.pageFieldGuides=data.pages.map((_,i)=>fieldGuides(data,i));if(!Array.isArray(data.pageFieldBackgroundColors))data.pageFieldBackgroundColors=[];let legacyFieldBackground=/^#[0-9a-f]{6}$/i.test(data.fieldBackgroundColor||'')?data.fieldBackgroundColor:'#17212c';data.pageFieldBackgroundColors=data.pages.map((_,i)=>/^#[0-9a-f]{6}$/i.test(data.pageFieldBackgroundColors[i]||'')?data.pageFieldBackgroundColors[i]:legacyFieldBackground);migrateBoardImages(data);if(!Array.isArray(data.pageNames))data.pageNames=[];data.pageNames=data.pages.map((_,i)=>typeof data.pageNames[i]==='string'&&data.pageNames[i].trim()?data.pageNames[i].trim():defaults[i]||'新規フェーズ');data.pages.forEach(p=>p.forEach(o=>{if(o.type==='icon'&&/^ヒーラ[12]$/.test(o.iconName||''))o.iconName=o.iconName.replace('ヒーラ','ヒーラー');if(o.type==='icon'&&o.iconName==='塔ふみ1')o.iconName='塔踏み1';if(o.type==='icon'&&typeof o.src==='string')o.src=o.src.replace('assets/field-marker/','assets/field-marker-transparent/')}))}

function openPhaseListForCreation(index=null){
 document.getElementById('contentPanel').dispatchEvent(new Event('reveal-phase-list'));
 const group=data.phaseGroups?.find(item=>item.id===data.pageGroupIds?.[index]);if(group)group.collapsed=false;
 const button=document.getElementById('toggleBattlePages');if(button.getAttribute('aria-expanded')!=='true')button.click();
}
function revealCreatedPhase(index){
 const owner=data,reveal=()=>{if(data!==owner)return;const row=document.getElementById('pages').querySelectorAll('.page-tab')[index];if(row)revealMovedListItems(document.getElementById('pages'),[row])};reveal();requestAnimationFrame(reveal);
}
function revealMovedPhase(index){
 const list=document.getElementById('pages');revealMovedListItems(list,list?.querySelectorAll('.page-tab')[index]?[list.querySelectorAll('.page-tab')[index]]:[]);
}

function beginPageRename(tab,cancelAddition=null){
 if(boardReadOnly)return;const list=$('#pages'),index=Array.from(list.querySelectorAll('.page-tab')).indexOf(tab);if(index<0||!tab.querySelector('.page-tab-name'))return;const oldName=data.pageNames[index];
 beginListNameEdit({row:tab,list,value:oldName,label:'フェーズ名',inputClass:'page-tab-input',addition:!!cancelAddition,cancelButton:tab.querySelector('.page-tab-x'),additionLabel:'フェーズ',onFinish(commit,name){if(!commit&&cancelAddition){cancelAddition();return}if(commit&&name&&name!==oldName){if(!cancelAddition)recordHistory();data.pageNames[index]=name;save()}else if(commit&&!name)notify('フェーズ名を入力してください');if(cancelAddition)renderAndSave();else{renderPages();window.Bolxiv?.phaseMasters?.paint()}}});
}

function nextCopiedPhaseName(name,names){
 const base=(String(name||'フェーズ').replace(/(?:[\s　]+コピー|[\s　]*[（(][0-9]+[）)])+$/u,'').trim()||'フェーズ');
 let number=2;
 for(const existing of names){const match=String(existing).match(/^(.*?)[（(]([0-9]+)[）)]$/u);if(match&&match[1].trim()===base){const used=Number(match[2]);if(Number.isSafeInteger(used)&&used>=2)number=Math.max(number,used+1)}}
 let candidate=base+'（'+number+'）';while(names.includes(candidate)){number++;candidate=base+'（'+number+'）'}return candidate
}

function copyPhaseAt(from=data.page){if(boardReadOnly||phaseComparisonActive()||!Number.isInteger(from)||!data.pages[from])return;let at=from+1,copied=data.pages[from].map(o=>{let item=JSON.parse(JSON.stringify(o));item.id=createObjectId();return item});snapshot();selectedPhaseIndexes=[];data.pageGroupIds.splice(at,0,data.pageGroupIds[from]||null);data.pages.splice(at,0,copied);data.pageMasterIds?.splice(at,0,data.pageMasterIds[from]);data.pageNames.splice(at,0,nextCopiedPhaseName(data.pageNames[from],data.pageNames));data.pageNotes.splice(at,0,data.pageNotes[from]||'');data.pageColors.splice(at,0,data.pageColors[from]);data.pageBoardShapes.splice(at,0,data.pageBoardShapes[from]);data.pageFieldBackgroundColors.splice(at,0,data.pageFieldBackgroundColors[from]);data.pageFieldImageIds.splice(at,0,data.pageFieldImageIds[from]);data.pageFieldImageTints.splice(at,0,fieldImageTint(data,from));data.pageFieldGuides.splice(at,0,fieldGuides(data,from));data.pageFieldSizes.splice(at,0,JSON.parse(JSON.stringify(data.pageFieldSizes[from])));data.page=at;selected=null;selectedIds=[];openPhaseListForCreation(at);renderAndSave();revealCreatedPhase(at)}

;
// ===== js/help.js =====
// help: shared function declarations; initialized by bolxiv.js in the documented order.
function closeHelpMenu(restoreFocus=false){helpMenu.hidden=true;document.getElementById('operationGuideBtn').setAttribute('aria-expanded','false');if(restoreFocus)document.getElementById('operationGuideBtn').focus()}

function showDeletionDialog(id,message){const dialog=document.getElementById(id);dialog.querySelector('p').textContent=message;dialog.showModal()}

function positionToast(){
 const toast=$('#toast'),viewport=stage.closest('.object-layout-rect');
 if(!toast?.classList.contains('show')||!viewport)return;
 const rect=viewport.getBoundingClientRect(),left=Math.max(0,rect.left),right=Math.min(window.innerWidth,rect.right),top=Math.max(0,rect.top),bottom=Math.min(window.innerHeight,rect.bottom);
 if(right<=left||bottom<=top)return;
 const width=Math.max(0,right-left-24);
 toast.style.maxWidth=width+'px';
 toast.style.left=(left+right)/2+'px';
 toast.style.top='auto';
 toast.style.bottom=(window.innerHeight-bottom+12)+'px';
}

function notifyFailure(message,{error=null,retained='',action=''}={}){
 const reasons={QuotaExceededError:'ブラウザーの保存領域が不足している可能性があります',SecurityError:'ブラウザーの設定で保存先へのアクセスが制限されています',SyntaxError:'JSONの形式が正しくありません',NotAllowedError:'ファイルへのアクセスが許可されませんでした'};
 const reason=error?(reasons[error.name]||(/[ぁ-んァ-ヶ一-龠]/.test(error.message||'')?error.message:'')):'';
 notify([message,reason,retained,action].filter(Boolean).map(text=>String(text).replace(/。+$/,'')).join('。'));
 clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),15000);
}
function notify(s,names=[]){
 let t=$('#toast');document.body.appendChild(t);const message=String(s).trimEnd().replace(/。*$/,'。'),ranges=[];
 for(const match of message.matchAll(/「([^」]+)」/g))ranges.push([match.index+1,match.index+1+match[1].length]);
 for(const name of names){if(!name)continue;let from=0,at;while((at=message.indexOf(name,from))>=0){ranges.push([at,at+name.length]);from=at+name.length}}
 t.replaceChildren();let from=0;for(const [start,end] of ranges.sort((a,b)=>a[0]-b[0]||b[1]-a[1])){if(start<from)continue;t.append(document.createTextNode(message.slice(from,start)));const span=document.createElement('span');span.className='toast-name';span.textContent=message.slice(start,end);t.append(span);from=end}t.append(document.createTextNode(message.slice(from)));t.classList.add('show');positionToast();
 if(!positionToast.watching){
  positionToast.watching=true;
  let frame=0;const schedule=()=>{if(!frame&&t.classList.contains('show'))frame=requestAnimationFrame(()=>{frame=0;positionToast()})};
  const resize=new ResizeObserver(schedule);resize.observe(t);const viewport=stage.closest('.object-layout-rect');if(viewport)resize.observe(viewport);resize.observe(document.querySelector('.layout'));
  new MutationObserver(schedule).observe(document.querySelector('.layout'),{subtree:true,childList:true,attributes:true,attributeFilter:['class','style','data-phone-pane']});
  window.addEventListener('resize',schedule);window.addEventListener('scroll',schedule,true);window.visualViewport?.addEventListener('resize',schedule);
 }
 clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),4000);
}

;
// ===== js/state-access.js =====
// state-access: shared function declarations; initialized by bolxiv.js in the documented order.
function current(){return data.pages[data.page]}

function activeBoardShape(){return data.pageBoardShapes?.[data.page]||data.boardShape||'square'}

function activeFieldBackground(){return data.pageFieldBackgroundColors?.[data.page]||data.fieldBackgroundColor||'#17212c'}

function activePageColor(){return data.pageColors?.[data.page]||data.layoutColor||'#808080'}

;
// ===== js/history.js =====
// history: shared function declarations; initialized by bolxiv.js in the documented order.
function storeContentHistory(){commitPendingHistory();pendingHistoryState=null;pendingHistoryOwner=null;contentHistoryStore.set(data,{history,future});}

function restoreContentHistory(){pendingHistoryState=null;pendingHistoryOwner=null;const saved=contentHistoryStore.get(data);history=saved?saved.history:[];future=saved?saved.future:[];}

function snapshot(){recordHistory();render()}

function historySnapshot(state){
 if(typeof state!=='string')return state;
 if(historySnapshotCache.has(state))return historySnapshotCache.get(state);
 const parsed=JSON.parse(state);historySnapshotCache.set(state,parsed);
 if(historySnapshotCache.size>8)historySnapshotCache.delete(historySnapshotCache.keys().next().value);
 return parsed;
}

function sameHistoryState(a,b){if(a===b)return true;const left=historySnapshot(a),right=historySnapshot(b),keys=Object.keys(left).filter(key=>key!=='page'&&key!=='title'),other=Object.keys(right).filter(key=>key!=='page'&&key!=='title');return keys.length===other.length&&keys.every(key=>Object.hasOwn(right,key)&&sameBoardSaveState(left[key],right[key]))}

function finishNumericHistoryGesture(){const gesture=numericHistoryGesture;numericHistoryGesture=null;if(!gesture)return;delete gesture.spin.dataset.historyPushed;if(gesture.board===data&&gesture.recorded)updateHistoryButtons()}

function startNumericHistoryGesture(spin,kind,id){
 if(numericHistoryGesture?.spin===spin&&numericHistoryGesture.board===data&&numericHistoryGesture.kind===kind&&numericHistoryGesture.id===id)return;
 finishNumericHistoryGesture();numericHistoryGesture={spin,kind,id,board:data,recorded:false};
}

function recordHistory(state){if(window.Bolxiv?.phaseMasters?.active){window.Bolxiv.phaseMasters.record();return}
 const gesture=numericHistoryGesture;
 if(gesture?.board===data&&gesture.recorded)return;
 state??=JSON.stringify(data);if(gesture?.board===data)gesture.recorded=true;
 commitPendingHistory(state);pendingHistoryState=state;pendingHistoryOwner=data;updateHistoryButtons(state);
}

function commitPendingHistory(currentState){if(phaseComparisonRendering||pendingHistoryState===null)return;if(pendingHistoryOwner!==data){pendingHistoryState=null;pendingHistoryOwner=null;return}if(sameHistoryState(pendingHistoryState,currentState??JSON.stringify(data)))return;if(!history.length||!sameHistoryState(history[history.length-1],pendingHistoryState))history.push(pendingHistoryState);if(history.length>100)history.shift();future=[];pendingHistoryState=null;pendingHistoryOwner=null;}

function historyActionLabel(beforeState,afterState){
 const cacheable=typeof beforeState==='string'&&typeof afterState==='string';
 if(cacheable){const cached=historyLabelCache.find(entry=>entry.before===beforeState&&entry.after===afterState);if(cached)return cached.label;}
 const before=historySnapshot(beforeState),after=historySnapshot(afterState),labels=[];
 const changed=(a,b)=>!sameBoardSaveState(a,b);

 if(before.pages.length!==after.pages.length)labels.push(after.pages.length>before.pages.length?'フェーズの追加':'フェーズの削除');
 else{
 const fields=[['pageFieldGuides','フィールドガイドの変更'],['pageNotes','フェーズノートの変更'],['pageNames','フェーズ名の変更'],['pageBoardShapes','フィールド形状の変更'],['pageFieldSizes','フィールドサイズの変更'],['pageFieldBackgroundColors','フィールド背景色の変更'],['pageColors','キャンバス背景色の変更'],['pageFieldImageIds','フィールド画像の変更'],['pageFieldImageTints','フィールド画像の色調補正']];
 for(const [key,label] of fields)if(changed(before[key],after[key]))labels.push(label);
 const oldObjects=new Map(before.pages.flat().map(o=>[o.id,o])),newObjects=new Map(after.pages.flat().map(o=>[o.id,o]));
 if([...newObjects.keys()].some(id=>!oldObjects.has(id)))labels.push('オブジェクトの追加');
 if([...oldObjects.keys()].some(id=>!newObjects.has(id)))labels.push('オブジェクトの削除');
 const groups=[['オブジェクトのグループ変更',['objectGroupId','objectGroupName']],['オブジェクトの移動',['x','y']],['オブジェクトのサイズ変更',['width','height','innerSize','fontSize']],['オブジェクトの回転',['rotation']],['オブジェクトの色変更',['color','strokeColor']],['オブジェクトの透明度変更',['opacity']],['オブジェクトの表示切替',['visible']],['オブジェクトの固定切替',['locked']],['オブジェクトの文字変更',['label']]];
 for(const [label,keys] of groups)if([...newObjects].some(([id,o])=>oldObjects.has(id)&&keys.some(k=>changed(oldObjects.get(id)[k],o[k]))))labels.push(label);
 if(!labels.length&&changed(before.pages.map(p=>p.map(o=>o.id)),after.pages.map(p=>p.map(o=>o.id))))labels.push('フェーズ・レイヤーの並べ替え');
 }
 const label=labels.length===1?labels[0]:labels.length>1?'複数の変更':'設定の変更';
 if(cacheable){historyLabelCache.push({before:beforeState,after:afterState,label});if(historyLabelCache.length>8)historyLabelCache.shift()}
 return label;
}

function historyResultMessage(beforeState,afterState,action){
 const before=historySnapshot(beforeState),after=historySnapshot(afterState);
 const shortName=(value,limit)=>{const chars=Array.from(String(value||'').replace(/\s+/g,' ').trim());return chars.length>limit?chars.slice(0,limit).join('')+'…':chars.join('')};
 const phaseName=index=>'フェーズ'+String(index+1).padStart(2,'0')+'「'+shortName(after.pageNames?.[index]||before.pageNames?.[index]||'名称未設定',16)+'」';
 let scope='コンテンツ「'+shortName(after.title||before.title||'名称未設定',20)+'」';
 if(before.title===after.title&&before.pages.length===after.pages.length){
  const keys=['pages','pageNames','pageNotes','pageBoardShapes','pageFieldSizes','pageFieldBackgroundColors','pageColors','pageFieldImageIds','pageFieldImageTints','pageFieldGuides'];
  const indexes=before.pages.map((_,i)=>i).filter(i=>keys.some(key=>!sameBoardSaveState(before[key]?.[i],after[key]?.[i])));
  if(indexes.length===1)scope=phaseName(indexes[0]);
  else if(indexes.length>1)scope=indexes.length<=2?indexes.map(phaseName).join('・'):'複数フェーズ（'+indexes.length+'件）';
 }
 return scope+'：'+historyActionLabel(beforeState,afterState)+'を'+action;
}

// Output mode permits note-only history steps, never changes to the diagram.
function outputNoteHistoryTarget(forward=false){
 if(!window.Bolxiv?.pngPreview?.active||window.Bolxiv.pngPreview.saving)return null;
 const stack=forward?future:history;let index=stack.length-1;
 while(index>=0&&sameHistoryState(stack[index],data))index--;
 if(index<0)return null;const state=historySnapshot(stack[index]);
 return sameHistoryState({...state,pageNotes:data.pageNotes},data)?{index,state}:null;
}
function applyOutputNoteHistory(forward=false){
 const input=document.querySelector('#phaseMemo textarea'),focused=input&&document.activeElement===input;
 const caret=focused?[input.selectionStart,input.selectionEnd]:null;
 commitPendingHistory();
 const target=outputNoteHistoryTarget(forward);if(!target)return;
 input?.blur();
 const currentState=JSON.stringify(data),stack=forward?future:history;
 stack.splice(target.index);(forward?history:future).push(currentState);
 pendingHistoryState=null;pendingHistoryOwner=null;
 data.pageNotes=target.state.pageNotes?.slice()||data.pages.map(()=>'');
 render();scheduleNoteSave();notify(forward?'ノートをやり直しました':'ノートを元に戻しました');
 if(focused&&input.isConnected){input.focus({preventScroll:true});input.setSelectionRange(Math.min(caret[0],input.value.length),Math.min(caret[1],input.value.length))}
}

function updateHistoryButtons(state=JSON.stringify(data)){const pm=window.Bolxiv?.phaseMasters;if(pm?.active){for(const [id,available,action,key]of [['undo',pm.canUndo,'元に戻す','Ctrl+Z'],['redo',pm.canRedo,'やり直す','Ctrl+Y']]){const button=document.getElementById(id);if(!button)continue;button.disabled=!available;button.setAttribute('aria-disabled',String(!available));button.title=available?'フィールドの操作を'+action+' ('+key+')':'フィールドに'+(id==='undo'?'元に戻せる':'やり直せる')+'操作はありません';button.setAttribute('aria-label',button.title)}return}commitPendingHistory(state);let undoButton=document.getElementById('undo'),redoButton=document.getElementById('redo');if(!undoButton||!redoButton)return;const output=!!window.Bolxiv?.pngPreview?.active;undoButton.disabled=output?!outputNoteHistoryTarget(false):phaseComparisonActive()||history.length===0;redoButton.disabled=output?!outputNoteHistoryTarget(true):phaseComparisonActive()||future.length===0;undoButton.setAttribute('aria-disabled',String(undoButton.disabled));redoButton.setAttribute('aria-disabled',String(redoButton.disabled));let undoState;for(let i=history.length-1;i>=0;i--){if(!sameHistoryState(history[i],state)){undoState=history[i];break}}const redoState=future[future.length-1];const comparison=phaseComparisonActive()&&!output;undoButton.title=comparison?'並列表示中は元に戻せません':undoState?'このコンテンツの操作を元に戻す (Ctrl+Z)\n対象：'+historyActionLabel(undoState,state):'このコンテンツに元に戻せる操作はありません';redoButton.title=comparison?'並列表示中はやり直せません':redoState?'このコンテンツの操作をやり直す (Ctrl+Y)\n対象：'+historyActionLabel(state,redoState):'このコンテンツにやり直せる操作はありません';undoButton.setAttribute('aria-label',undoButton.title);redoButton.setAttribute('aria-label',redoButton.title)}

// Keep the mobile inspector on surviving objects when applying history.
function restoreHistorySelection(){
 const panel=document.getElementById('objectLayerPanel');
 if(matchMedia('(max-width:850px)').matches&&panel?.dataset.objectTab==='properties'){
  const ids=new Set(current().map(object=>object.id));
  selectedIds=selectedIds.filter(id=>ids.has(id));
  selected=selectedIds.includes(selected)?selected:selectedIds[selectedIds.length-1]||null;
  if(!selectedIds.length)document.getElementById('toggleInspector').parentElement.querySelector('.phone-object-tabs button')?.click();
 }else{selected=null;selectedIds=[]}
}

function undo(){if(window.Bolxiv?.phaseMasters?.active){window.Bolxiv.phaseMasters.history(false);return}if(window.Bolxiv?.pngPreview?.active){applyOutputNoteHistory(false);return}if(boardReadOnly)return;if(phaseComparisonActive())return;commitPendingHistory();pendingHistoryState=null;pendingHistoryOwner=null;let page=data.page,currentState=JSON.stringify(data);while(history.length&&history[history.length-1]===currentState)history.pop();if(!history.length)return;future.push(currentState);const restoredState=history.pop(),message=historyResultMessage(restoredState,currentState,'元に戻しました');const previousBoard=data;data=cloneBoardSaveState(historySnapshot(restoredState));data.title=previousBoard.title;replaceContentHistoryBoard(previousBoard,data);data.page=Math.max(0,Math.min(page,data.pages.length-1));restoreHistorySelection();contentBoards[activeContent]=data;render();scheduleObjectPropertySave();notify(message)}

function redo(){if(window.Bolxiv?.phaseMasters?.active){window.Bolxiv.phaseMasters.history(true);return}if(window.Bolxiv?.pngPreview?.active){applyOutputNoteHistory(true);return}if(boardReadOnly)return;if(phaseComparisonActive())return;commitPendingHistory();pendingHistoryState=null;pendingHistoryOwner=null;if(!future.length)return;let page=data.page;const previousState=JSON.stringify(data),restoredState=future.pop(),message=historyResultMessage(previousState,restoredState,'やり直しました');history.push(previousState);const previousBoard=data;data=cloneBoardSaveState(historySnapshot(restoredState));data.title=previousBoard.title;replaceContentHistoryBoard(previousBoard,data);data.page=Math.max(0,Math.min(page,data.pages.length-1));restoreHistorySelection();contentBoards[activeContent]=data;render();scheduleObjectPropertySave();notify(message)}

;
// ===== js/contents.js =====
// contents: shared function declarations; initialized by bolxiv.js in the documented order.
// List history keeps board references, not copies of every canvas. Content edits
// remain in their own history and survive removing/restoring a content item.
function captureContentList(){return {boards:contentBoards.slice(),active:data,phaseMasters:window.Bolxiv?.phaseMasters?.records(),phaseMasterGroups:window.Bolxiv?.phaseMasters?.groupRecords()}}
function recordContentListChange(label,before,rename=null){
 contentListHistory.push({label,before,after:captureContentList(),rename});
 if(contentListHistory.length>100)contentListHistory.shift();contentListFuture.length=0;contentSelectorCache=null;
}
function replaceContentHistoryBoard(previous,next){
 const saved=contentHistoryStore.get(previous);if(saved)contentHistoryStore.set(next,saved);
 for(const entry of [...contentListHistory,...contentListFuture]){
  for(const state of [entry.before,entry.after]){state.boards=state.boards.map(board=>board===previous?next:board);if(state.active===previous)state.active=next}
  if(entry.rename?.board===previous)entry.rename.board=next;
 }
}
function restoreContentList(redo=false){
 if(boardReadOnly||phaseComparisonActive()||editingContentIndex>=0)return;
 const source=redo?contentListFuture:contentListHistory,target=redo?contentListHistory:contentListFuture,entry=source.pop();if(!entry)return;
 flushScheduledBoardSave();storeContentHistory();contentBoards[activeContent]=data;
 const state=redo?entry.after:entry.before,active=data;
 contentBoards=state.boards.slice();if(state.phaseMasters&&entry.label.startsWith('JSON'))window.Bolxiv?.phaseMasters?.restoreRecords(state.phaseMasters,state.phaseMasterGroups);
 if(entry.rename)entry.rename.board.title=redo?entry.rename.after:entry.rename.before;
 activeContent=contentBoards.indexOf(active);if(activeContent<0)activeContent=Math.max(0,contentBoards.indexOf(state.active));
 data=contentBoards[activeContent];restoreContentHistory();selected=null;selectedIds=[];selectedPhaseIndexes=[];phaseSelectionOwner=data;
 target.push(entry);contentSelectorCache=null;
 $('#contentOptions').hidden=false;$('#contentSelect').setAttribute('aria-expanded','true');
 renderAndSave();notify('コンテンツ一覧：'+entry.label+'を'+(redo?'やり直しました':'元に戻しました'));
}
function appendContentListHistoryButtons(row){
 const actions=document.createElement('div');actions.className='content-list-history-actions';
 for(const [id,label,entries,redo] of [['contentListUndo','元に戻す',contentListHistory,false],['contentListRedo','やり直す',contentListFuture,true]]){
  const button=document.createElement('button');button.id=id;button.type='button';button.className='content-list-history-button';
  button.innerHTML=document.getElementById(redo?'redo':'undo').innerHTML;
  button.disabled=boardReadOnly||phaseComparisonActive()||editingContentIndex>=0||!entries.length;
  button.title=entries.length?'コンテンツ一覧：'+entries.at(-1).label+'を'+label:'コンテンツ一覧に'+(redo?'やり直せる':'元に戻せる')+'操作はありません';
  button.setAttribute('aria-label',button.title);button.onclick=event=>{event.stopPropagation();restoreContentList(redo)};actions.append(button);
 }row.append(actions);
}
function switchContent(next){if(!Number.isInteger(next)||next<0||next>=contentBoards.length||next===activeContent||editingContentIndex>=0)return;flushScheduledBoardSave();storeContentHistory();contentBoards[activeContent]=data;activeContent=next;data=contentBoards[activeContent];restoreContentHistory();selected=null;selectedIds=[];$('#contentOptions').hidden=true;$('#contentSelect').setAttribute('aria-expanded','false');render();save(true)}

function moveContentBoard(from,to,after){if(editingContentIndex>=0||!Number.isInteger(from)||!Number.isInteger(to)||from<0||to<0||from>=contentBoards.length||to>=contentBoards.length||from===to)return;contentBoards[activeContent]=data;const before=captureContentList();let target=contentBoards[to],moving=contentBoards[from];contentBoards.splice(from,1);contentBoards.splice(contentBoards.indexOf(target)+(after?1:0),0,moving);activeContent=contentBoards.indexOf(data);recordContentListChange('並べ替え',before);save()}

function updateContentSelector(){const optionsNode=document.getElementById('contentOptions');if(optionsNode)optionsNode.dataset.contentEditable=String(!boardReadOnly&&!window.Bolxiv?.pngPreview?.active);const signature=JSON.stringify([activeContent,editingContentIndex,contentEditDraft,pendingContentAddition?.index,contentListHistory.length,contentListFuture.length,boardReadOnly,phaseComparisonActive(),contentBoards.map(board=>board.title)]);if(contentSelectorCache&&contentSelectorCache.signature===signature&&contentSelectorCache.boards.length===contentBoards.length&&contentSelectorCache.boards.every((board,index)=>board===contentBoards[index]))return;contentSelectorCache={signature,boards:contentBoards.slice()};let select=$('#contentSelect'),options=$('#contentOptions');if(!select||!options)return;let board=contentBoards[activeContent];select.textContent=board?.title||`コンテンツ${activeContent+1}`;select.title=select.textContent+'\nコンテンツリストを開閉';options.innerHTML='';let addRow=document.createElement('div');addRow.className='content-option-row content-option-add-row';let addButton=document.createElement('button');addButton.id='addContent';addButton.className='page page-add content-option-add';addButton.type='button';addButton.textContent='＋';addButton.title='コンテンツを追加';addButton.setAttribute('aria-label','コンテンツを追加');addButton.onclick=addContentBoard;addRow.appendChild(addButton);appendContentListHistoryButtons(addRow);options.appendChild(addRow);let list=document.createElement('div');list.className='content-options-scroll';options.appendChild(list);contentBoards.forEach((item,i)=>{let row=document.createElement('div');row.className='content-option-row'+(i===activeContent?' active':'');row.setAttribute('role','option');row.setAttribute('aria-selected',String(i===activeContent));row.draggable=editingContentIndex<0;row.title='左ボタンでドラッグして並べ替え';row.onpointerdown=e=>{row.draggable=editingContentIndex<0&&!e.target.closest('.content-row-action,input')};row.ondragstart=e=>{if(!row.draggable){e.preventDefault();return}e.dataTransfer.setData('application/x-tactica-content',String(i));e.dataTransfer.effectAllowed='move';row.classList.add('dragging')};row.ondragend=()=>options.querySelectorAll('.content-option-row').forEach(node=>node.classList.remove('dragging','drop-before','drop-after'));row.ondragover=e=>{if(editingContentIndex>=0||!Array.from(e.dataTransfer.types).includes('application/x-tactica-content'))return;e.preventDefault();let after=e.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;row.classList.toggle('drop-after',after);row.classList.toggle('drop-before',!after);e.dataTransfer.dropEffect='move'};row.ondragleave=()=>row.classList.remove('drop-before','drop-after');row.ondrop=e=>{if(!Array.from(e.dataTransfer.types).includes('application/x-tactica-content'))return;e.preventDefault();let from=Number(e.dataTransfer.getData('application/x-tactica-content')),after=e.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;row.classList.remove('drop-before','drop-after');moveContentBoard(from,i,after)};let index=document.createElement('span');index.className='content-option-index';index.textContent=String(i+1).padStart(2,'0');row.appendChild(index);if(i===editingContentIndex){let input=document.createElement('input');input.className='content-option-input';input.type='text';input.value=contentEditDraft;input.setAttribute('aria-label',`コンテンツ${i+1}の名称`);input.oninput=e=>contentEditDraft=e.target.value;input.onkeydown=e=>{if(e.isComposing||e.keyCode===229)return;if(e.key==='Enter'){e.preventDefault();finishContentRename(i,true)}else if(e.key==='Escape'){e.preventDefault();finishContentRename(i,false)}};if(pendingContentAddition?.index===i)input.onblur=()=>finishContentRename(i,true);row.appendChild(input);let done=document.createElement('button');done.className='content-row-action';done.type='button';done.textContent='✓';done.title='名称を保存';done.setAttribute('aria-label','名称を保存');done.onclick=()=>finishContentRename(i,true);row.appendChild(done);let cancel=document.createElement('button');cancel.className='content-row-action';cancel.type='button';cancel.textContent=pendingContentAddition?.index===i?'↶':'×';cancel.title=pendingContentAddition?.index===i?'コンテンツ追加を取り消す':'編集をキャンセル';cancel.setAttribute('aria-label',cancel.title);cancel.dataset.cancelContentRename='true';cancel.onpointerdown=e=>{e.preventDefault();e.stopPropagation()};cancel.onclick=()=>finishContentRename(i,false);row.appendChild(cancel)}else{let button=document.createElement('button');button.className='content-option-select';button.type='button';button.textContent=item.title||`コンテンツ${i+1}`;button.title=button.textContent+'\nクリックで切り替え、左ボタンでドラッグして並べ替え';button.onclick=()=>switchContent(i);row.appendChild(button);let remove=document.createElement('button');remove.className='content-row-action content-row-delete';remove.type='button';remove.textContent='×';remove.title='コンテンツを削除';remove.setAttribute('aria-label','コンテンツを削除');remove.onclick=e=>{e.stopPropagation();deleteContentIndex=i;showDeletionDialog('deleteContentDialog','コンテンツ「'+(contentBoards[i].title||'新規コンテンツ')+'」と、その中のすべてのフェーズを削除しますか？')};row.appendChild(remove)}list.appendChild(row)});options.hidden=!(editingContentIndex>=0||$('#contentSelect').getAttribute('aria-expanded')==='true')}

let importedContentToReveal=null;
function revealContentRow(index=editingContentIndex>=0?editingContentIndex:importedContentToReveal&&contentBoards.includes(importedContentToReveal)?contentBoards.indexOf(importedContentToReveal):activeContent){const reveal=()=>{const options=$('#contentOptions'),list=options?.querySelector('.content-options-scroll'),row=list?.children[index];if(!list||!row||options.hidden||!list.clientHeight)return;const bounds=list.getBoundingClientRect(),rect=row.getBoundingClientRect(),top=bounds.top+list.clientTop+4,bottom=bounds.top+list.clientTop+list.clientHeight-4;if(rect.top<top)list.scrollTop+=rect.top-top;else if(rect.bottom>bottom)list.scrollTop+=rect.bottom-bottom;if(importedContentToReveal===contentBoards[index]){revealMovedListItems(list,[row]);importedContentToReveal=null}};reveal();requestAnimationFrame(reveal)}
function beginContentRename(i){if(!contentBoards[i]||boardReadOnly||phaseComparisonActive())return;editingContentIndex=i;contentEditDraft=String(contentBoards[i].title||('コンテンツ'+(i+1)));$('#contentOptions').hidden=false;$('#contentSelect').setAttribute('aria-expanded','true');updateContentSelector();const input=document.querySelector('#contentOptions input');input?.focus();input?.select();revealContentRow(i)}
function finishContentRename(i,commit){if(i!==editingContentIndex)return;const addition=pendingContentAddition?.index===i?pendingContentAddition:null;if(!commit&&addition){editingContentIndex=-1;contentEditDraft='';pendingContentAddition=null;contentHistoryStore.delete(addition.board);contentBoards.splice(i,1);activeContent=addition.previousIndex;data=contentBoards[activeContent];restoreContentHistory();selected=addition.selected;selectedIds=addition.selectedIds;selectedPhaseIndexes=addition.phases;phaseSelectionOwner=data;$('#contentOptions').hidden=false;$('#contentSelect').setAttribute('aria-expanded','true');renderAndSave();notify('コンテンツ追加を取り消しました');return}let name=contentEditDraft.trim();if(commit&&!name){notify('コンテンツ名を入力してください');document.querySelector('#contentOptions input')?.focus();return}if(commit&&!addition&&contentBoards[i].title!==name)recordContentListChange('名称変更',captureContentList(),{board:contentBoards[i],before:contentBoards[i].title,after:name});if(commit){contentBoards[i].title=name;if(i===activeContent){data.title=name;updateSelectionLabel()}}editingContentIndex=-1;contentEditDraft='';if(addition){recordContentListChange('追加',addition.before);pendingContentAddition=null;renderAndSave()}else if(commit)save();else updateContentSelector();if(commit)notify(addition?'コンテンツを追加しました':'コンテンツ名を保存しました')}

function deleteContentBoard(index){if(!Number.isInteger(index)||index<0||index>=contentBoards.length)return;storeContentHistory();contentBoards[activeContent]=data;const before=captureContentList();contentBoards.splice(index,1);if(!contentBoards.length)contentBoards=[{title:'新規コンテンツ1',layout:'square',boardShape:'square',pageBoardShapes:['square'],layoutColor:'#ffffff',fieldBackgroundColor:'#17212c',pageFieldBackgroundColors:['#17212c'],pageFieldImageIds:[''],pageFieldImageTints:[{color:"#000000",strength:0}],pageFieldSizes:[{width:538,height:538}],pageColors:['#ffffff'],pages:[[]],pageNames:['新規フェーズ'],pageNotes:[''],page:0}];if(index<activeContent)activeContent--;else if(index===activeContent)activeContent=Math.min(index,contentBoards.length-1);data=contentBoards[activeContent];restoreContentHistory();selected=null;selectedIds=[];editingContentIndex=-1;$('#contentOptions').hidden=false;$('#contentSelect').setAttribute('aria-expanded','true');recordContentListChange('削除',before);renderAndSave();notify('コンテンツを削除しました')}

function addContentBoard(){if(editingContentIndex>=0){finishContentRename(editingContentIndex,true);if(editingContentIndex>=0)return}const before=captureContentList(),previousIndex=activeContent,previousSelected=selected,previousSelectedIds=selectedIds.slice(),previousPhases=selectedPhaseIndexes.slice();storeContentHistory();contentBoards[activeContent]=data;let n=contentBoards.length+1;data={title:`新規コンテンツ${n}`,pageMasterIds:['initial'],layout:'square',boardShape:'square',pageBoardShapes:['square'],layoutColor:'#ffffff',fieldBackgroundColor:'#17212c',pageFieldBackgroundColors:['#17212c'],pageFieldImageIds:[''],pageFieldImageTints:[{color:"#000000",strength:0}],pageFieldSizes:[{width:538,height:538}],pageColors:['#ffffff'],pages:[[]],pageNames:['新規フェーズ'],pageNotes:[''],page:0};contentBoards.push(data);activeContent=contentBoards.length-1;restoreContentHistory();selected=null;selectedIds=[];pendingContentAddition={before,index:activeContent,board:data,previousIndex,selected:previousSelected,selectedIds:previousSelectedIds,phases:previousPhases};editingContentIndex=activeContent;contentEditDraft=data.title;selectedPhaseIndexes=[];phaseSelectionOwner=data;$('#contentOptions').hidden=false;$('#contentSelect').setAttribute('aria-expanded','true');renderAndSave();const input=document.querySelector('#contentOptions input');if(input){input.focus();input.select();revealContentRow(activeContent)}}

;
// ===== js/storage.js =====
// storage: shared function declarations; initialized by bolxiv.js in the documented order.
function persistBoardSafely(value,navigationOnly=false){if(boardSaveSuspended)return false;return window.boardStorage.save(value,{navigationOnly,imageAssets:boardImageLibrary.entries(window.Bolxiv?.phaseMasters?window.Bolxiv.phaseMasters.imageBoards(contentBoards):contentBoards)})}

function renderAndSave(){if(window.Bolxiv?.phaseMasters?.active){render();window.Bolxiv.phaseMasters.commit();return}contentBoards[activeContent]=data;render();save(false,true)}

function cloneBoardSaveState(value){if(!value||typeof value!=='object')return value;if(Array.isArray(value))return value.map(cloneBoardSaveState);const copy={};for(const key of Object.keys(value))copy[key]=cloneBoardSaveState(value[key]);return copy}

function sameBoardSaveState(left,right){
 if(Object.is(left,right))return true;
 if(!left||!right||typeof left!=='object'||typeof right!=='object'||Array.isArray(left)!==Array.isArray(right))return false;
 const keys=Object.keys(left);if(keys.length!==Object.keys(right).length)return false;
 return keys.every(key=>Object.hasOwn(right,key)&&sameBoardSaveState(left[key],right[key]));
}

function boardSaveState(){if(window.Bolxiv?.phaseMasters)return window.Bolxiv.phaseMasters.state();contentBoards[activeContent]=data;return {version:4,activeContent,contents:contentBoards}}

function cancelScheduledBoardSave(){clearTimeout(boardSaveDelayTimer);clearTimeout(boardSaveMaxTimer);boardSaveDelayTimer=boardSaveMaxTimer=null;boardSavePending=false;boardSaveNavigationOnly=false;boardSaveNoteOnly=false;boardSavePropertyOnly=false;}

function flushScheduledBoardSave(){
 if(boardSaveSuspended)return;
 if(!boardSavePending)return;
 const navigationOnly=boardSaveNavigationOnly,noteOnly=boardSaveNoteOnly,propertyOnly=boardSavePropertyOnly;
 cancelScheduledBoardSave();
 try{
  const state=boardSaveState();
  if(boardSaveCheckpointDirty){boardSaveCheckpoint=cloneBoardSaveState(state);boardSaveCheckpointDirty=false}
  if(noteOnly||propertyOnly)updateHistoryButtons();
  persistBoardSafely(JSON.stringify(state),navigationOnly);
 }
 catch(error){boardSavePending=true;window.BolxivSaveStatus.set('content','未保存');console.warn('Board serialization failed',error);notifyFailure('自動保存できませんでした',{error,retained:'編集中の内容は画面に残っています',action:'ページを閉じずに「エクスポート」からコンテンツJSONを保存してください'})}
}

function scheduleBoardSave(navigationOnly=false){
 if(boardSaveSuspended)return;
 if(phaseComparisonRendering)return;
 const state=boardSaveState();
 if(boardSaveCheckpoint===null){boardSaveCheckpoint=cloneBoardSaveState(state);return}
 if(!boardSavePending&&!boardSaveCheckpointDirty&&window.BolxivSaveStatus.get('content')!=='未保存'&&sameBoardSaveState(boardSaveCheckpoint,state))return;
 // The immutable checkpoint is refreshed once at flush, not for every drag event.
 boardSaveCheckpointDirty=true;
 // Navigation must not postpone an outstanding note edit.
 if(navigationOnly&&boardSavePending&&(boardSaveNoteOnly||boardSavePropertyOnly))return;
 boardSaveNoteOnly=false;boardSavePropertyOnly=false;
 boardSaveNavigationOnly=navigationOnly&&(!boardSavePending||boardSaveNavigationOnly);
 boardSavePending=true;
 if(!boardSaveNavigationOnly)window.BolxivSaveStatus.set('content','未保存の変更あり');
 clearTimeout(boardSaveDelayTimer);boardSaveDelayTimer=setTimeout(flushScheduledBoardSave,boardSaveNavigationOnly?phaseSaveDelay:boardSaveDelay);
 if(boardSaveMaxTimer===null)boardSaveMaxTimer=setTimeout(flushScheduledBoardSave,boardSaveNavigationOnly?phaseSaveMaxWait:boardSaveMaxWait);
}

function scheduleObjectPropertySave(){
 if(boardSaveSuspended)return;
 if(phaseComparisonRendering)return;
 contentBoards[activeContent]=data;boardSaveCheckpointDirty=true;
 const propertyOnly=!boardSavePending||boardSaveNavigationOnly||boardSavePropertyOnly;
 if(boardSavePending&&boardSaveNavigationOnly){clearTimeout(boardSaveDelayTimer);clearTimeout(boardSaveMaxTimer);boardSaveDelayTimer=boardSaveMaxTimer=null}
 boardSavePending=true;boardSaveNavigationOnly=false;boardSaveNoteOnly=false;boardSavePropertyOnly=propertyOnly;
 window.BolxivSaveStatus.set('content','未保存の変更あり');
 clearTimeout(boardSaveDelayTimer);boardSaveDelayTimer=setTimeout(flushScheduledBoardSave,boardSaveDelay);
 if(boardSaveMaxTimer===null)boardSaveMaxTimer=setTimeout(flushScheduledBoardSave,boardSaveMaxWait);
}

function scheduleNoteSave(){
 if(boardSaveSuspended)return;
 if(phaseComparisonRendering)return;
 contentBoards[activeContent]=data;
 boardSavePropertyOnly=false;
 boardSaveCheckpointDirty=true;
 const noteOnly=!boardSavePending||boardSaveNavigationOnly||boardSaveNoteOnly;
 if(boardSavePending&&boardSaveNavigationOnly){clearTimeout(boardSaveDelayTimer);clearTimeout(boardSaveMaxTimer);boardSaveDelayTimer=boardSaveMaxTimer=null}
 boardSavePending=true;boardSaveNavigationOnly=false;boardSaveNoteOnly=noteOnly;
 window.BolxivSaveStatus.set('content','未保存の変更あり');
 if(!noteOnly)return;
 clearTimeout(boardSaveDelayTimer);boardSaveDelayTimer=setTimeout(flushScheduledBoardSave,noteSaveDelay);
 if(boardSaveMaxTimer===null)boardSaveMaxTimer=setTimeout(flushScheduledBoardSave,noteSaveMaxWait);
}

function save(navigationOnly=false,historyFresh=false){if(window.Bolxiv?.phaseMasters?.active){window.Bolxiv.phaseMasters.commit();return}if(phaseComparisonRendering)return;if(objectPropertyInputActive&&!navigationOnly){scheduleObjectPropertySave();return}if(!historyFresh)updateHistoryButtons();for(let o of current()){if(o.type==='targetcircle'){let el=Array.from(layer.children).find(node=>node.dataset.id===o.id);if(el)refreshTargetCircleTriangle(o,el)}}contentBoards[activeContent]=data;updateContentSelector();scheduleBoardSave(navigationOnly)}

function rememberViewSetting(key,value){viewSettings[key]=value;try{localStorage.setItem(viewSettingsKey,JSON.stringify(viewSettings))}catch{}}

;
// ===== js/file-io.js =====
// file-io: shared function declarations; initialized by bolxiv.js in the documented order.
function safeExportName(ext){const group=data.phaseGroups?.find(group=>group.id===data.activePhaseGroup);let name=ext==='.png'?(group?[(data.title||'strategy-board'),'グループ',group.name].join('_'):phaseComparisonActive()?[(data.title||'strategy-board'),'フェーズを並べて表示',selectedPhaseIndexes.map(i=>i+1).join('-')].join('_'):[(data.title||'strategy-board'),data.page+1,(data.pageNames?.[data.page]||'フェーズ'+(data.page+1))].join('_')):(data.title||'strategy-board');return name.replace(/[\\/:*?"<>|\x00-\x1f]/g,'_')+ext}

function exportPickerOptions(filename,mime,description){return {suggestedName:filename,types:[{description,accept:{[mime]:[filename.slice(filename.lastIndexOf('.'))]}}]}}

async function saveExportBlob(blob,filename,mime,description,handlePromise){let handle=null;if(handlePromise){try{handle=await handlePromise}catch(error){if(error?.name==='AbortError')return false;throw error}}else if(window.showSaveFilePicker){try{handle=await window.showSaveFilePicker(exportPickerOptions(filename,mime,description))}catch(error){if(error?.name==='AbortError')return false;throw error}}if(handle){let writable=await handle.createWritable();try{await writable.write(new Uint8Array(await blob.arrayBuffer()));await writable.close()}catch(error){try{await writable.abort()}catch{}throw error}}else{let url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}notify(handle?(description||'ファイル')+'を保存しました':(description||'ファイル')+'のダウンロードを開始しました');return handle?'saved':'download'}

function jsonExportPayload(boards,includeUnused=false){
 if(window.Bolxiv?.phaseMasters)return window.Bolxiv.phaseMasters.exportPayload(boards,includeUnused);
 const contents=boards.map(board=>{const {page,...content}=board;return content});
 return {version:4,imageLibrary:Object.fromEntries(boardImageLibrary.entries(boards)),contents};
}

function importedFieldImage(image,assets){
 if(image&&typeof image==='object'){
  const index=image.imageRef;
  if(!Number.isInteger(index)||index<0||!Array.isArray(assets)||typeof assets[index]!=='string'||!assets[index])throw new Error('フィールド画像の参照先が見つかりません');
  return assets[index];
 }
 return typeof image==='string'?image:'';
}

async function exportJson(scope){if(window.Bolxiv?.phaseMasters?.active)window.Bolxiv.phaseMasters.leave();
 save();flushScheduledBoardSave();
 const contents=(scope==='selected'?[data]:contentBoards).map(board=>{
  const {page,...content}=board;return content;
 });
 const snapshot=JSON.stringify(jsonExportPayload(contents,scope!=='selected')),contentName=data.title||'名称未設定';
 const blob=new Blob([JSON.stringify(JSON.parse(snapshot),null,2)],{type:'application/json'});
 const delivery=await saveExportBlob(blob,safeExportName('.json'),'application/json','JSONファイル');
 if(delivery)await rememberJsonBackup(scope,snapshot,contentName,delivery);
}

function loadJsonBackupRecords(){try{return JSON.parse(localStorage.getItem(jsonBackupRecordKey)||'{}')||{}}catch{return {}}}

function jsonBackupSnapshot(scope){
 const boards=scope==='selected'?[data]:contentBoards.map((board,i)=>i===activeContent?data:board);
 return JSON.stringify(jsonExportPayload(boards,scope!=='selected'));
}

async function jsonBackupFingerprint(snapshot){
 const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(snapshot));
 return Array.from(new Uint8Array(bytes),byte=>byte.toString(16).padStart(2,'0')).join('');
}

async function rememberJsonBackup(scope,snapshot,contentName,delivery){
 try{
  const records=loadJsonBackupRecords();records[scope]={at:Date.now(),fingerprint:await jsonBackupFingerprint(snapshot),contentName,delivery};
  localStorage.setItem(jsonBackupRecordKey,JSON.stringify(records));
 }catch(error){console.warn('JSON backup record could not be saved',error)}
}

function jsonBackupStatusText(scope,record,fingerprint){
 if(!record?.at||!record.fingerprint)return 'JSON書き出し記録：まだありません';
 const date=new Intl.DateTimeFormat('ja-JP',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(record.at));
 const label=record.delivery==='download'?'最終ダウンロード開始':'最終JSON保存';
 const target=scope==='selected'?'\n保存対象：'+record.contentName:'';
 const state=record.fingerprint===fingerprint?'書き出し時から変更はありません':scope==='selected'?'選択中の内容は、このJSONと異なります':'書き出し後に変更があります';
 return label+'：'+date+target+'\n'+state;
}

async function updateJsonBackupStatus(){
 const records=loadJsonBackupRecords();
 await Promise.all(['all','selected'].map(async scope=>{
  const node=jsonExportMenu.querySelector('[data-backup-status="'+scope+'"]');
  try{node.textContent=jsonBackupStatusText(scope,records[scope],records[scope]?await jsonBackupFingerprint(jsonBackupSnapshot(scope)):null)}
  catch{node.textContent='JSON書き出し記録を確認できません'}
 }));
}

function closeJsonExportMenu(restoreFocus=false){jsonExportMenu.hidden=true;$('#exportBtn').setAttribute('aria-expanded','false');if(restoreFocus)$('#exportBtn').focus()}

function closeJsonImportMenu(restoreFocus=false){jsonImportMenu.hidden=true;$('#importBtn').setAttribute('aria-expanded','false');if(restoreFocus)$('#importBtn').focus()}

function parseImportedBoards(text){
 const value=JSON.parse(String(text).replace(/^\uFEFF/,''));
 if(!value||typeof value!=='object')throw new Error('コンテンツまたはフェーズのデータがありません');
 const source=Array.isArray(value.contents)?value.contents:[value];
 const boards=source.filter(board=>board&&Array.isArray(board.pages)&&board.pages.length);
 if(!boards.length)throw new Error('コンテンツまたはフェーズのデータがありません');
 const imported=boards.map(board=>migrateBoardImages({
  ...board,title:String(board.title||'Imported Strategy'),page:0,
  pages:board.pages.map(page=>Array.isArray(page)?page:[]),
  pageNotes:Array.from({length:board.pages.length},(_,i)=>typeof board.pageNotes?.[i]==='string'?board.pageNotes[i]:''),
  pageFieldImageIds:Array.from({length:board.pages.length},(_,i)=>board.pageFieldImageIds?.[i]??importedFieldImage(board.pageFieldImages?.[i],value.imageAssets)),
  pageFieldGuides:Array.from({length:board.pages.length},(_,i)=>fieldGuides(board,i)),
  pageFieldImageTints:Array.from({length:board.pages.length},(_,i)=>fieldImageTint(board,i)),
  pageFieldSizes:Array.from({length:board.pages.length},(_,i)=>board.pageFieldSizes?.[i]||{width:538,height:538}),
  pageBoardShapes:Array.from({length:board.pages.length},(_,i)=>board.pageBoardShapes?.[i]||board.boardShape||'square'),
  pageFieldBackgroundColors:Array.from({length:board.pages.length},(_,i)=>board.pageFieldBackgroundColors?.[i]||board.fieldBackgroundColor||'#17212c'),
  pageColors:Array.from({length:board.pages.length},(_,i)=>board.pageColors?.[i]||board.layoutColor||'#808080')
 },value.version>=4?(value.imageLibrary||{}):null));
 return window.Bolxiv?.phaseMasters?window.Bolxiv.phaseMasters.prepareImport(imported,value):imported;
}

function applyImportedBoards(imported,mode){if(window.Bolxiv?.phaseMasters?.active)window.Bolxiv.phaseMasters.leave();if(boardReadOnly)throw new Error("閲覧中はインポートできません");
 flushScheduledBoardSave();storeContentHistory();contentBoards[activeContent]=data;
 const before=captureContentList();window.Bolxiv?.phaseMasters?.acceptImport(imported,mode);if(mode==='append'){contentBoards=[...contentBoards,...imported]}
 else{contentBoards=imported;activeContent=0;data=contentBoards[0];restoreContentHistory()}
 selected=null;selectedIds=[];selectedPhaseIndexes=[];phaseSelectionOwner=data;
 recordContentListChange(mode==='append'?'JSONによる追加':'JSONによる置換',before);
 renderAllIconGrids();renderAndSave();flushScheduledBoardSave();
 importedContentToReveal=imported[0]||null;revealContentRow();
}

function confirmReplaceImport(imported){
 return new Promise(resolve=>{
  document.getElementById('replaceImportSummary').textContent='現在の全コンテンツ（'+contentBoards.length+'件）が、読み込んだ編集データ（'+imported.length+'件）に置き換わります。';
  const finish=accepted=>{replaceImportDialog.oncancel=null;replaceImportDialog.onclose=null;replaceImportDialog.close();resolve(accepted)};
  document.getElementById('replaceImportCancel').onclick=()=>finish(false);
  document.getElementById('replaceImportConfirm').onclick=()=>finish(true);
  replaceImportDialog.oncancel=e=>{e.preventDefault();finish(false)};
  replaceImportDialog.onclose=()=>finish(false);
  replaceImportDialog.showModal();document.getElementById('replaceImportCancel').focus();
 });
}

function pngStyleValue(value){return value.replace(/url\((['"]?)(.*?)\1\)/g,(match,quote,url)=>{let hash=url.lastIndexOf('#');if(hash<0)return match;let id=url.slice(hash+1),definition=document.getElementById(id);return definition&&(stage.contains(definition)||definition.closest('.phase-comparison-grid,.phase-group-artwork'))?'url("#'+id+'")':match})}

// Standard computed properties already resolve CSS variables. Copying inherited variables would repeat embedded field images on every descendant.
function copyPngStyle(source,target,pseudo){
 const style=getComputedStyle(source,pseudo),declarations=[];
 for(const key of target.style)if(key.startsWith('--')){const priority=target.style.getPropertyPriority(key);declarations.push(key+':'+target.style.getPropertyValue(key)+(priority?' !'+priority:''))}
 for(const key of style){if(key.startsWith('--'))continue;const value=pngStyleValue(style.getPropertyValue(key)),priority=style.getPropertyPriority(key);declarations.push(key+':'+value+(priority?' !'+priority:''))}
 // Resolve standard inline declarations too, including !important var() values.
 // One parse avoids hundreds of individual CSSOM mutations per element.
 target.style.cssText=declarations.join(';')+';animation:none!important;transition:none!important';
 return style;
}

function clonePngNode(source,{materializePseudo=true}={}){if(source.nodeType===Node.TEXT_NODE)return source.cloneNode();if(source.nodeType!==Node.ELEMENT_NODE)return null;if(source.id==='objectControls'||source.classList.contains('selection-marquee')||source.classList.contains('guide-selection-controls')||source.classList.contains('guide-editor-overlay'))return null;let target=source.cloneNode(false);copyPngStyle(source,target);if(source.namespaceURI!=='http://www.w3.org/2000/svg')target.removeAttribute('id');if(source.classList.contains('selected')){target.classList.remove('selected');target.style.filter='none';target.style.outline='none'}if(source instanceof HTMLImageElement){let src=source.getAttribute('src');target.src=embeddedPngs[src]||source.currentSrc||source.src;if(!target.src.startsWith('data:'))throw new Error('画像を埋め込めません：'+(source.alt||src));target.removeAttribute('srcset');target.loading='eager'}let appendPseudo=pseudo=>{let style=getComputedStyle(source,pseudo);if(style.content==='none'||style.content==='normal'||style.display==='none')return;let node=document.createElement('span');copyPngStyle(source,node,pseudo);node.style.setProperty('content','normal');if(style.content!=='""'&&style.content!=="''")node.textContent=style.content.replace(/^['"]|['"]$/g,'');target.appendChild(node)};if(materializePseudo&&source.namespaceURI==='http://www.w3.org/1999/xhtml')appendPseudo('::before');for(let child of source.childNodes){let cloned=clonePngNode(child);if(cloned)target.appendChild(cloned)}if(materializePseudo&&source.namespaceURI==='http://www.w3.org/1999/xhtml')appendPseudo('::after');return target}

function clonePngStage({preserveDisplay=false,liveField=false}={}){let originalClass=stage.className,originalClip=objectClip.style.getPropertyValue('clip-path'),originalPriority=objectClip.style.getPropertyPriority('clip-path');try{if(!preserveDisplay){stage.classList.add('grid-hidden');stage.classList.remove('field-hidden');objectClip.style.setProperty('clip-path','none','important')}const clone=clonePngNode(stage,{materializePseudo:!liveField});return clone}finally{stage.className=originalClass;if(originalClip)objectClip.style.setProperty('clip-path',originalClip,originalPriority);else objectClip.style.removeProperty('clip-path')}}

const phasePngCaches=new WeakMap();
async function rasterizePngSource(source,scale=1,stageSource=false,readable=false){await prepareImportedImageElements(source);
 for(const image of source.querySelectorAll('img')){if(!image.complete)await image.decode();if(!image.naturalWidth)throw new Error('画像を読み込めません：'+(image.alt||'アイコン'))}
 const width=source.offsetWidth,height=source.offsetHeight,clone=stageSource?clonePngStage():clonePngNode(source);
 if(readable)enhancePrintReadability(clone);
 for(const [key,value] of Object.entries({margin:'0',position:'relative',left:'auto',top:'auto',right:'auto',bottom:'auto',transform:'none',zoom:'1',boxShadow:'none',display:'block',width:width+'px',height:height+'px'}))clone.style.setProperty(key.replace(/[A-Z]/g,c=>'-'+c.toLowerCase()),value,'important');
 clone.setAttribute('xmlns','http://www.w3.org/1999/xhtml');const outputWidth=width*scale,outputHeight=height*scale,html=new XMLSerializer().serializeToString(clone),svg='<svg xmlns="http://www.w3.org/2000/svg" width="'+outputWidth+'" height="'+outputHeight+'" viewBox="0 0 '+width+' '+height+'"><foreignObject x="0" y="0" width="100%" height="100%">'+html+'</foreignObject></svg>',image=new Image();image.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);await image.decode();const canvas=document.createElement('canvas');canvas.width=outputWidth;canvas.height=outputHeight;const ctx=canvas.getContext('2d');if(!ctx)throw new Error('Canvas context unavailable');ctx.drawImage(image,0,0);return canvas;
}
async function drawPngCanvas(scale=1,readable=false){
 if(document.fonts)await document.fonts.ready;
 const groupArtwork=document.querySelector('.phase-group-overview:not([hidden]) .phase-group-artwork'),comparison=!groupArtwork&&phaseComparisonActive()?document.querySelector('.phase-comparison-grid'):null;
 if(!comparison)return rasterizePngSource(groupArtwork||stage,scale,!groupArtwork,readable);
 const cells=[...comparison.querySelectorAll(':scope>.phase-comparison-cell')],layout=phaseComparisonLayout(),width=comparison.offsetWidth,height=comparison.offsetHeight;
 const images=await Promise.all(cells.map(cell=>{
  const tile=cell.querySelector('.phase-preview-stage'),key=scale+'|'+readable+'|'+cell.querySelector('.phase-comparison-label').textContent;
  let cache=phasePngCaches.get(tile);if(!cache){cache=new Map();phasePngCaches.set(tile,cache)}
  if(!cache.has(key)){const pending=rasterizePngSource(cell,scale,false,readable);cache.set(key,pending);pending.catch(()=>{if(cache.get(key)===pending)cache.delete(key)})}
  return cache.get(key);
 }));
 const canvas=document.createElement('canvas');canvas.width=width*scale;canvas.height=height*scale;const ctx=canvas.getContext('2d');if(!ctx)throw new Error('Canvas context unavailable');ctx.fillStyle=getComputedStyle(comparison).backgroundColor;ctx.fillRect(0,0,canvas.width,canvas.height);images.forEach((image,i)=>ctx.drawImage(image,i%layout.columns*layout.cellSize*scale,Math.floor(i/layout.columns)*layout.cellSize*scale));return canvas;
}


async function exportPng(handlePromise,scale=1,previewCanvas=null){
 const filename=safeExportName('.png');let target=handlePromise;
 try{if(target)target=await target;else if(window.showSaveFilePicker)target=await window.showSaveFilePicker(exportPickerOptions(filename,'image/png','PNG画像'))}catch(error){if(error?.name==='AbortError')return false;throw error}
 return withDesktopDisplayBusy(async()=>{const c=previewCanvas||await drawPngCanvas(scale),blob=await new Promise((resolve,reject)=>{c.toBlob(result=>result?resolve(result):reject(new Error('PNG encoding failed')),'image/png')});const bytes=new Uint8Array(await blob.arrayBuffer()),signature=[137,80,78,71,13,10,26,10];if(bytes.length<33||!signature.every((value,index)=>bytes[index]===value))throw new Error('Invalid PNG data');return saveExportBlob(new Blob([bytes],{type:'image/png'}),filename,'image/png','PNG画像',target)});
}

;

// Shared note layout for the output preview, PNG and print.
function outputPhaseNote(width,text){
 text=String(text||'').replace(/\r\n?/g,'\n').trim();
 const rows=Math.max(5,Math.min(10,Number(document.getElementById('outputNoteRows')?.value)||5)),scale=width/640,font=16*scale,lineHeight=24*scale,padding=12*scale,ctx=document.createElement('canvas').getContext('2d');ctx.font=font+"px 'BIZ UDGothic', 'BIZ UDゴシック', monospace";ctx.fontKerning='none';const metrics=ctx.measureText('国あＡｇ'),ascent=metrics.actualBoundingBoxAscent,descent=metrics.actualBoundingBoxDescent;const lines=[];
 for(const paragraph of text.split('\n')){let line='';for(const char of paragraph){if(line&&ctx.measureText(line+char).width>width-padding*2){lines.push(line);line=''}line+=char}lines.push(line)}
 return {height:padding*2+(rows-1)*lineHeight+ascent+descent,lines:lines.slice(0,rows),font,lineHeight,padding,scale,ascent,error:''};
}
function outputNoteLayout(width){
 const includeNote=Number(document.getElementById('outputNoteRows')?.value)>0;
 if(data.activePhaseGroup)return {height:0,lines:[],error:''};
 if(phaseComparisonActive()){
  const layout=phaseComparisonLayout(),gapX=Math.max(0,Math.min(100,Number(document.getElementById('outputPhaseGapX')?.value)||0)),gapY=Math.max(0,Math.min(100,Number(document.getElementById('outputPhaseGapY')?.value)||0)),notes=selectedPhaseIndexes.map(index=>({...includeNote?outputPhaseNote(layout.cellSize,data.pageNotes[index]):{height:0,lines:[],error:''},index}));
  return {height:layout.rows*notes[0].height+(layout.rows-1)*gapY,width:layout.width+(layout.columns-1)*gapX,gapX,gapY,notes,layout,error:notes.filter(note=>note.error).map(note=>(data.pageNames[note.index]||'フェーズ'+(note.index+1))+': '+note.error).join('\n')};
 }
 return includeNote?outputPhaseNote(width,data.pageNotes[data.page]):{height:0,lines:[],error:''};
}
function drawOutputNote(ctx,width,y,note,readable=false){
 if(!note.height)return;ctx.save();ctx.translate(0,y);ctx.fillStyle='#ffffff';ctx.fillRect(0,0,width,note.height);const scale=note.scale||1;ctx.strokeStyle='#9ca8ba';ctx.lineWidth=2*scale;ctx.strokeRect(scale,scale,width-2*scale,note.height-2*scale);ctx.strokeStyle='#e0e5ed';ctx.lineWidth=scale;ctx.strokeRect(5.5*scale,5.5*scale,width-11*scale,note.height-11*scale);ctx.fillStyle='#17212c';ctx.font=note.font+"px 'BIZ UDGothic', 'BIZ UDゴシック', monospace";ctx.fontKerning='none';ctx.textBaseline='alphabetic';for(let i=0;i<note.lines.length;i++){if(readable){ctx.strokeStyle="#17212c";ctx.lineWidth=.6*scale;ctx.strokeText(note.lines[i],note.padding,note.padding+note.ascent+i*note.lineHeight)}ctx.fillText(note.lines[i],note.padding,note.padding+note.ascent+i*note.lineHeight);}ctx.restore();
}

const drawDiagramPngCanvas=drawPngCanvas;
drawPngCanvas=async function(scale=1,readable=false){return composeOutputPngCanvas(await drawDiagramPngCanvas(scale,readable),scale,true,readable)};
// One outer guard pixel, one frame pixel and four clear pixels before the content.
const outputBorderPadding=6;
function outputFrameLayout(width,height){
 const note=outputNoteLayout(width),padding=document.getElementById('outputShowBorder')?.checked?outputBorderPadding:0;
 if(note.notes){const {cellSize,columns,rows}=note.layout,blockWidth=cellSize,blockHeight=cellSize+note.notes[0].height;return {note,padding,blockWidth,blockHeight,width:columns*blockWidth+(columns-1)*note.gapX+padding*2,height:rows*blockHeight+(rows-1)*note.gapY+padding*2}}
 return {note,padding,width:width+padding*2,height:height+note.height+padding*2};
}
function drawOutputBorder(ctx,width,height){
 if(!document.getElementById('outputShowBorder')?.checked)return;const frame=outputFrameLayout(width,height),{note}=frame;ctx.save();ctx.fillStyle='#999999';
 // Filled strips avoid half-pixel strokes at the bitmap edge during print scaling.
 const pixelScale=ctx.getTransform().a||1,snap=value=>Math.round(value*pixelScale)/pixelScale;
 function rectangle(x,y,w,h){const left=snap(x+1),top=snap(y+1),right=snap(x+w-2),bottom=snap(y+h-2);ctx.fillRect(left,top,right-left+1,1);ctx.fillRect(left,bottom,right-left+1,1);ctx.fillRect(left,top+1,1,bottom-top-1);ctx.fillRect(right,top+1,1,bottom-top-1)}
 if(note.notes){const {columns}=note.layout;note.notes.forEach((entry,i)=>{const x=i%columns*(frame.blockWidth+note.gapX),y=Math.floor(i/columns)*(frame.blockHeight+note.gapY);rectangle(x,y,frame.blockWidth+frame.padding*2,frame.blockHeight+frame.padding*2)})}
 else rectangle(0,0,frame.width,frame.height);ctx.restore();
}

function composeOutputPngCanvas(source,scale=1,includeBorder=true,readable=false){
 const width=source.width/scale,height=source.height/scale,frame=outputFrameLayout(width,height),{note,padding}=frame;if(note.error)throw new Error(note.error);if(!note.height&&!note.notes&&!padding)return source;
 const canvas=document.createElement('canvas');canvas.width=Math.ceil(frame.width*scale);canvas.height=Math.ceil(frame.height*scale);const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.scale(scale,scale);
 if(note.notes){const {cellSize,columns}=note.layout;note.notes.forEach((entry,i)=>{const column=i%columns,x=column*(frame.blockWidth+note.gapX)+padding,row=Math.floor(i/columns),y=row*(frame.blockHeight+note.gapY)+padding;ctx.drawImage(source,column*cellSize*scale,row*cellSize*scale,cellSize*scale,cellSize*scale,x,y,cellSize,cellSize);ctx.save();ctx.translate(x,0);drawOutputNote(ctx,cellSize,y+cellSize,entry,readable);ctx.restore()})}
 else{ctx.drawImage(source,padding,padding,width,height);ctx.save();ctx.translate(padding,0);drawOutputNote(ctx,width,height+padding,note,readable);ctx.restore()}if(includeBorder)drawOutputBorder(ctx,width,height);return canvas;
};
