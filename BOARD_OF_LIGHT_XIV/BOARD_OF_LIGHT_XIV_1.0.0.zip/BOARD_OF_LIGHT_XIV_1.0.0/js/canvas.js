function moveHandleMarkup(){return "<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><g fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M12 3v18M3 12h18M10 5l2-2 2 2M10 19l2 2 2-2M5 10l-2 2 2 2M19 10l2 2-2 2\" stroke=\"#999999\" stroke-width=\"5.5\"/><path d=\"M12 3v18M3 12h18M10 5l2-2 2 2M10 19l2 2 2-2M5 10l-2 2 2 2M19 10l2 2-2 2\" stroke=\"#ffffff\" stroke-width=\"2.8\"/></g></svg>"}
function rotationHandleMarkup(){return "<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M19 9a7.5 7.5 0 1 0 .3 5M19 3v6h-6\" fill=\"none\" stroke=\"#999999\" stroke-width=\"5.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M19 9a7.5 7.5 0 1 0 .3 5M19 3v6h-6\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>"}
// ===== Definitions =====
// Layer blocks are ordered front to back. A group always occupies one block.
function objectLayerBlocks(front=current().slice().reverse()){
 const groups=new Map();for(const item of front)if(item.objectGroupId){if(!groups.has(item.objectGroupId))groups.set(item.objectGroupId,[]);groups.get(item.objectGroupId).push(item)}
 const seen=new Set(),blocks=[];for(const item of front){if(!item.objectGroupId){blocks.push([item]);continue}if(seen.has(item.objectGroupId))continue;seen.add(item.objectGroupId);blocks.push(groups.get(item.objectGroupId))}return blocks;
}
function moveObjectLayerBlock(from,to,after=false){
 if(boardReadOnly||phaseComparisonActive())return;const blocks=objectLayerBlocks(),source=blocks.find(b=>b.some(o=>o.id===from)),target=blocks.find(b=>b.some(o=>o.id===to));if(!source||!target||source===target)return;
 const next=blocks.filter(b=>b!==source);next.splice(next.indexOf(target)+(after?1:0),0,source);const ordered=next.flat().reverse();if(ordered.every((o,i)=>o===current()[i]))return;
 recordHistory();data.pages[data.page]=ordered;renderAndSave();revealMovedLayers(source.map(o=>o.id));
}
function applyGroupMemberOrder(groupId,front,id){
 const back=front.slice().reverse();let index=0;const ordered=current().map(o=>o.objectGroupId===groupId?back[index++]:o);if(ordered.every((o,i)=>o===current()[i]))return;
 recordHistory();data.pages[data.page]=ordered;individualGroupSelection={board:data,page:ordered,id};selected=id;selectedIds=[id];renderAndSave();
 const list=document.getElementById('objectList'),row=[...list.children].find(n=>n.classList.contains('object-group-member')&&n.dataset.id===id);if(row)revealMovedListItems(list,[row]);
}
function moveGroupMember(from,to,after=false){
 if(boardReadOnly||phaseComparisonActive())return;const source=current().find(o=>o.id===from),target=current().find(o=>o.id===to);if(!source?.objectGroupId||source.objectGroupId!==target?.objectGroupId||from===to)return;
 const front=current().filter(o=>o.objectGroupId===source.objectGroupId).reverse().filter(o=>o.id!==from);front.splice(front.findIndex(o=>o.id===to)+(after?1:0),0,source);applyGroupMemberOrder(source.objectGroupId,front,from);
}
function relocateObjectMembership(id,groupId,targetId,after=false){
 if(boardReadOnly||phaseComparisonActive())return;const source=current().find(o=>o.id===id);if(!source||id===targetId)return;
 const members=groupId?current().filter(o=>o.objectGroupId===groupId):[];if(groupId&&!members.length)return;
 const front=current().slice().reverse().filter(o=>o.id!==id),copy={...source};
 if(groupId){copy.objectGroupId=groupId;copy.objectGroupName=objectGroupName(members)}else{delete copy.objectGroupId;delete copy.objectGroupName}
 let at=targetId?front.findIndex(o=>o.id===targetId):front.length;
 if(groupId&&!targetId)at=front.findIndex(o=>o.objectGroupId===groupId);
 if(at<0)at=front.length;if(targetId&&after)at++;
 front.splice(at,0,copy);const ordered=front.reverse();if(ordered.every((o,i)=>o.id===current()[i].id&&o.objectGroupId===current()[i].objectGroupId))return;
 recordHistory();data.pages[data.page]=ordered;selected=id;selectedIds=[id];individualGroupSelection=groupId?{board:data,page:ordered,id}:null;
 const list=document.getElementById('objectList');if(groupId)list._expandedObjectGroups?.add(groupId);renderAndSave();
 const row=[...list.children].find(n=>n.dataset.id===id&&!n.classList.contains('object-group-row'));if(row)revealMovedListItems(list,[row]);
}
function handleObjectMembershipDrop(event){
 const list=document.getElementById('objectList'),row=event.target.closest('.object-row'),types=Array.from(event.dataTransfer?.types||[]),memberDrag=types.includes('application/x-tactica-group-member'),layerDrag=types.includes('application/x-tactica-layer');if(!memberDrag&&!layerDrag)return;
 const target=row?current().find(o=>o.id===row.dataset.id):null,groupTarget=row?.classList.contains('object-group-row')||row?.classList.contains('object-group-member');
 if(!row){const visible=[...list.children].filter(n=>n.classList.contains('object-row')&&!n.hidden),bottom=visible.at(-1)?.getBoundingClientRect().bottom;if(!memberDrag||bottom===undefined||event.clientY<bottom)return}
 if(event.type==='dragover'){if(memberDrag||groupTarget){event.preventDefault();if(memberDrag){event.stopImmediatePropagation();list.querySelectorAll('.drag-over,.drop-before,.drop-after').forEach(n=>n.classList.remove('drag-over','drop-before','drop-after'));const guide=row||[...list.children].filter(n=>n.classList.contains('object-row')&&!n.hidden).at(-1);if(guide){const after=!row||event.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;guide.classList.add('drag-over',after?'drop-after':'drop-before')}}else if(row)row.classList.add('drag-over')}return}
 const id=event.dataTransfer.getData(memberDrag?'application/x-tactica-group-member':'application/x-tactica-layer'),source=current().find(o=>o.id===id);if(!source)return;
 if(!memberDrag&&source.objectGroupId)return;
 if(!memberDrag&&!groupTarget)return;
 event.preventDefault();event.stopImmediatePropagation();list.querySelectorAll('.drag-over,.drop-before,.drop-after').forEach(n=>n.classList.remove('drag-over','drop-before','drop-after'));
 const after=!!row&&event.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;
 if(groupTarget)relocateObjectMembership(id,target.objectGroupId,row.classList.contains('object-group-member')?target.id:null,after);
 else relocateObjectMembership(id,null,target?.id||null,after);
}
function bindGroupMemberReorder(row,item){
 row.draggable=!boardReadOnly&&!phaseComparisonActive();const handle=row.querySelector('.object-index');handle.title='ドラッグしてレイヤー順やグループの所属を変更';
 row.ondragstart=e=>{if(boardReadOnly||phaseComparisonActive()){e.preventDefault();return}e.stopPropagation();e.dataTransfer.setData('application/x-tactica-group-member',item.id);e.dataTransfer.effectAllowed='move'};
 row.ondragover=e=>{const types=Array.from(e.dataTransfer.types);if(!types.includes('application/x-tactica-group-member')&&!types.includes('application/x-tactica-layer'))return;e.preventDefault();const after=e.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;row.classList.add('drag-over');row.classList.toggle('drop-after',after);row.classList.toggle('drop-before',!after)};
 row.ondragleave=()=>row.classList.remove('drag-over','drop-before','drop-after');row.ondrop=e=>{e.preventDefault();e.stopPropagation();row.classList.remove('drag-over','drop-before','drop-after');const after=e.clientY>row.getBoundingClientRect().top+row.offsetHeight/2,member=e.dataTransfer.getData('application/x-tactica-group-member');if(member)moveGroupMember(member,item.id,after);else{const group=e.dataTransfer.getData('application/x-tactica-layer');if(group)moveObjectLayerBlock(group,item.id,after)}};
}
function changeObjectLayerPriority(ids,action){
 if(individualGroupSelectionActive()&&ids.length===1&&ids[0]===individualGroupSelection.id){
  if(boardReadOnly||phaseComparisonActive())return;const item=current().find(o=>o.id===ids[0]),front=current().filter(o=>o.objectGroupId===item.objectGroupId).reverse(),index=front.indexOf(item);front.splice(index,1);const at=action==='top'?0:action==='bottom'?front.length:action==='up'?Math.max(0,index-1):Math.min(front.length,index+1);front.splice(at,0,item);applyGroupMemberOrder(item.objectGroupId,front,item.id);return;
 }
 if(boardReadOnly||phaseComparisonActive())return;const selectedSet=new Set(expandObjectGroups(ids)),blocks=objectLayerBlocks(),moving=b=>b.some(o=>selectedSet.has(o.id));let next=blocks.slice();
 if(action==='top')next=[...blocks.filter(moving),...blocks.filter(b=>!moving(b))];
 else if(action==='bottom')next=[...blocks.filter(b=>!moving(b)),...blocks.filter(moving)];
 else if(action==='up'){for(let i=1;i<next.length;i++)if(moving(next[i])&&!moving(next[i-1]))[next[i-1],next[i]]=[next[i],next[i-1]]}
 else if(action==='down'){for(let i=next.length-2;i>=0;i--)if(moving(next[i])&&!moving(next[i+1]))[next[i],next[i+1]]=[next[i+1],next[i]]}
 const ordered=next.flat().reverse();if(ordered.every((o,i)=>o===current()[i]))return;recordHistory();data.pages[data.page]=ordered;renderAndSave();revealMovedLayers([...selectedSet]);
}
function objectGroupName(items){return items.find(o=>typeof o.objectGroupName==='string'&&o.objectGroupName.trim())?.objectGroupName||'グループ'}
function revealCreatedObjectGroup(groupId){
 const owner=data,page=current(),items=page.filter(o=>o.objectGroupId===groupId);if(!items.length)return;
 const panel=document.getElementById('objectLayerPanel'),heading=document.getElementById('toggleLayers'),list=document.getElementById('objectList');
 panel.dispatchEvent(new Event('reveal-object-list'));
 if(heading.getAttribute('aria-expanded')!=='true'&&!heading.disabled)heading.click();
 revealCanvasSelectionRow(items[0].id,list);beginObjectGroupRename(groupId);
 requestAnimationFrame(()=>{if(owner!==data||page!==current())return;revealCanvasSelectionRow(items[0].id,list);updateObjectGroupFrames()});
}
function beginObjectGroupRename(groupId){
 if(boardReadOnly||phaseComparisonActive())return;const items=current().filter(o=>o.objectGroupId===groupId),row=[...document.querySelectorAll('#objectList .object-group-row')].find(n=>n.dataset.objectGroupId===groupId);if(!items.length||!row||row.querySelector('input[type=text]'))return;
 const owner=data,page=current(),name=row.querySelector('.object-name'),input=document.createElement('input');input.type='text';input.className='object-group-name-input';input.value=objectGroupName(items);input.maxLength=80;input.setAttribute('aria-label','グループ名');row.draggable=false;row.classList.add('renaming');row.append(input);requestAnimationFrame(updateObjectGroupFrames);let done=false,revealFrame=0;const mobile=matchMedia('(max-width:850px)'),viewport=window.visualViewport;
 function stopViewportWatch(){viewport?.removeEventListener('resize',scheduleReveal);viewport?.removeEventListener('scroll',scheduleReveal);window.removeEventListener('resize',scheduleReveal);if(revealFrame)cancelAnimationFrame(revealFrame)}
 function scheduleReveal(){if(revealFrame)return;revealFrame=requestAnimationFrame(()=>{revealFrame=0;revealInput()})}
 function finish(cancel=false){if(done)return;done=true;stopViewportWatch();const value=input.value.trim();if(!cancel&&value&&owner===data&&page===current()&&value!==objectGroupName(items)){recordHistory();for(const item of items)item.objectGroupName=value;renderAndSave()}else renderObjectList()}
 input.onpointerdown=e=>e.stopPropagation();input.onkeydown=e=>{e.stopPropagation();if(e.isComposing||e.keyCode===229)return;if(e.key==='Enter'){e.preventDefault();finish()}else if(e.key==='Escape'){e.preventDefault();finish(true)}};input.onblur=()=>finish();if(mobile.matches)input.focus();else input.focus({preventScroll:true});input.select();
 function revealInput(){if(done)return;if(!input.isConnected){stopViewportWatch();return}const list=document.getElementById('objectList');let bounds=list.getBoundingClientRect(),rect=input.getBoundingClientRect(),top=bounds.top+list.clientTop,bottom=top+list.clientHeight;
 if(mobile.matches&&viewport){const visibleTop=viewport.offsetTop,visibleBottom=visibleTop+viewport.height;if(top>=visibleBottom-rect.height||bottom<=visibleTop+rect.height){input.scrollIntoView({block:'center',inline:'nearest'});bounds=list.getBoundingClientRect();rect=input.getBoundingClientRect()}top=Math.max(bounds.top+list.clientTop,viewport.offsetTop+8);bottom=Math.min(bounds.top+list.clientTop+list.clientHeight,viewport.offsetTop+viewport.height-8)}
 if(rect.bottom>bottom-4)list.scrollTop+=rect.bottom-bottom+4;else if(rect.top<top+4)list.scrollTop+=rect.top-top-4}
 if(mobile.matches){viewport?.addEventListener('resize',scheduleReveal);viewport?.addEventListener('scroll',scheduleReveal);window.addEventListener('resize',scheduleReveal)}revealInput();scheduleReveal();
}

function ungroupObjectGroup(groupId){if(boardReadOnly||phaseComparisonActive())return;const items=current().filter(o=>o.objectGroupId===groupId);if(!items.length)return;recordHistory();for(const item of items){delete item.objectGroupId;delete item.objectGroupName}individualGroupSelection=null;selectedIds=items.map(o=>o.id);selected=selectedIds.at(-1)||null;closeObjectContextMenu();renderAndSave()}
function objectGroupIds(id){const item=current().find(o=>o.id===id);return item?.objectGroupId?current().filter(o=>o.objectGroupId===item.objectGroupId).map(o=>o.id):[id]}
function individualGroupSelectionActive(){
 if(!individualGroupSelection||individualGroupSelection.board!==data||individualGroupSelection.page!==current()||!selectedIds.length||!selectedIds.includes(individualGroupSelection.id))return false;
 const page=current();if(selectedIds.length===1)return page.some(item=>item.id===individualGroupSelection.id&&!!item.objectGroupId);
 const groups=new Map();for(const item of page){if(!item.objectGroupId)continue;if(!groups.has(item.objectGroupId))groups.set(item.objectGroupId,new Set());groups.get(item.objectGroupId).add(item.id)}
 return page.some(item=>item.id===individualGroupSelection.id&&item.objectGroupId&&selectedIds.every(id=>groups.get(item.objectGroupId).has(id)));
}
function selectIndividualGroupMember(id,extend=false,reveal=false){
 if(phaseComparisonActive())return;const item=current().find(o=>o.id===id);if(!item?.objectGroupId)return;
 const sameGroup=individualGroupSelectionActive()&&current().find(o=>o.id===individualGroupSelection.id)?.objectGroupId===item.objectGroupId;
 const anchor=extend&&!sameGroup&&selected!==id&&current().find(o=>o.id===selected&&o.objectGroupId===item.objectGroupId);
 selectedIds=extend&&sameGroup?(selectedIds.includes(id)?selectedIds.filter(key=>key!==id):[...selectedIds,id]):anchor?[anchor.id,id]:[id];
 selected=selectedIds.includes(id)?id:selectedIds.at(-1)||null;individualGroupSelection=selected?{board:data,page:current(),id:selected}:null;if(reveal&&selectedIds.includes(id)){const list=document.getElementById('objectList');list._expandedObjectGroups??=new Set();list._expandedObjectGroups.add(item.objectGroupId);pendingLayerRevealId=id}renderSelectionOnly();
}
let objectListSelectionAnchor=null;
function selectObjectListItem(id,event,member=false){
 if(phaseComparisonActive())return;const item=current().find(o=>o.id===id);if(!item)return;
 if(matchMedia('(max-width:850px)').matches){if(member){selectIndividualGroupMember(id,!!event.shiftKey);return}individualGroupSelection=null;selectedIds=event.shiftKey?toggleObjectGroup(id):objectGroupIds(id);selected=selectedIds.includes(id)?id:selectedIds.at(-1)||null;renderSelectionOnly();return}
 const scope=member?item.objectGroupId:null,rows=[...document.getElementById('objectList').children].filter(row=>row.classList.contains('object-row')&&!row.hidden&&(member?row.classList.contains('object-group-member')&&current().find(o=>o.id===row.dataset.id)?.objectGroupId===scope:!row.classList.contains('object-group-member'))),key=row=>row.classList.contains('object-group-row')?'group:'+row.dataset.objectGroupId:row.dataset.id,target=rows.findIndex(row=>member?row.dataset.id===id:item.objectGroupId?row.dataset.objectGroupId===item.objectGroupId:row.dataset.id===id);
 if(target<0)return;const additive=!!(event.ctrlKey||event.metaKey),saved=objectListSelectionAnchor,valid=saved?.board===data&&saved.page===current()&&saved.scope===scope,anchor=valid?rows.findIndex(row=>key(row)===saved.key):-1,base=anchor>=0?anchor:target;
 let next;if(event.shiftKey){const range=rows.slice(Math.min(base,target),Math.max(base,target)+1).flatMap(row=>member?[row.dataset.id]:objectGroupIds(row.dataset.id));next=additive?[...new Set([...selectedIds,...range])]:range;if(!valid)objectListSelectionAnchor={board:data,page:current(),scope,key:key(rows[base])}}
 else{const ids=member?[id]:objectGroupIds(id),existing=member?(individualGroupSelectionActive()&&current().find(o=>o.id===individualGroupSelection.id)?.objectGroupId===scope?selectedIds:[]):selectedIds;next=additive?(ids.every(key=>existing.includes(key))?existing.filter(key=>!ids.includes(key)):[...new Set([...existing,...ids])]):ids;objectListSelectionAnchor={board:data,page:current(),scope,key:key(rows[target])}}
 selectedIds=next;selected=next.includes(id)?id:next.at(-1)||null;individualGroupSelection=member&&selected?{board:data,page:current(),id:selected}:null;renderSelectionOnly();
}
function normalizeObjectSelection(){if(!individualGroupSelectionActive()){individualGroupSelection=null;selectedIds=expandObjectGroups(selectedIds)}}
function renderIndividualGroupHint(el){el.querySelectorAll('.individual-group-edit').forEach(node=>node.remove());if(!individualGroupSelectionActive())return;const item=current().find(o=>o.id===selected),field=document.createElement('div'),label=document.createElement('div');field.className='field individual-group-edit';label.textContent=(selectedIds.length>1?'グループ内 '+selectedIds.length+'個を選択：':'個別編集：')+objectGroupName(current().filter(o=>o.objectGroupId===item.objectGroupId));field.append(label);el.prepend(field);const lock=el.querySelector('#editableInput');if(lock){lock.title='このオブジェクトの編集可／不可を切り替えます';lock.closest('label').title=lock.title}}
function expandObjectGroups(ids){
 if(!ids.length)return [];if(ids.length===1)return [...new Set(objectGroupIds(ids[0]))];
 const objects=new Map(),groups=new Map();for(const item of current()){if(!objects.has(item.id))objects.set(item.id,item);if(item.objectGroupId){if(!groups.has(item.objectGroupId))groups.set(item.objectGroupId,[]);groups.get(item.objectGroupId).push(item.id)}}
 const result=new Set(),expanded=new Set();for(const id of ids){const group=objects.get(id)?.objectGroupId;if(group){if(expanded.has(group))continue;expanded.add(group);for(const member of groups.get(group))result.add(member)}else result.add(id)}return [...result];
}
function toggleObjectGroup(id){const ids=objectGroupIds(id);return selectedIds.includes(id)?selectedIds.filter(key=>!ids.includes(key)):expandObjectGroups([...selectedIds,id])}
function remapCopiedObjectGroups(items){const groups=new Map();for(const item of items){if(!item.objectGroupId)continue;if(!groups.has(item.objectGroupId))groups.set(item.objectGroupId,createObjectId());item.objectGroupId=groups.get(item.objectGroupId)}return items}
function selectedObjectGroup(){if(individualGroupSelectionActive())return [];const items=current().filter(o=>selectedIds.includes(o.id));return items.length>1&&items[0].objectGroupId&&items.every(o=>o.objectGroupId===items[0].objectGroupId)&&objectGroupIds(items[0].id).length===items.length?items:[]}
function syncObjectGroupMenu(){
 const items=current().filter(o=>selectedIds.includes(o.id)),blocked=boardReadOnly||phaseComparisonActive();
 const group=document.getElementById('contextGroup'),ungroup=document.getElementById('contextUngroup');if(!group)return;
 group.disabled=blocked||individualGroupSelectionActive()||items.length<2||selectedObjectGroup().length>0;
 ungroup.disabled=blocked||individualGroupSelectionActive()||!items.some(o=>o.objectGroupId);const rename=document.getElementById('contextRenameObjectGroup');if(rename)rename.disabled=blocked||!selectedObjectGroup().length;
}
function renderObjectGroupControls(){
 controls.querySelectorAll('.object-group-control').forEach(node=>node.remove());
 if(boardReadOnly||phaseComparisonActive()||phaseComparisonRendering)return;
 const picked=new Set(selectedIds),groups=new Map();
 for(const item of current())if(item.objectGroupId){if(!groups.has(item.objectGroupId))groups.set(item.objectGroupId,[]);groups.get(item.objectGroupId).push(item)}
 for(const items of groups.values()){
  if(items.length<2)continue;
  if(individualGroupSelectionActive()&&items.some(item=>picked.has(item.id)))renderSelectedObjectGroupFrame(items,false,true);
  else if(items.every(item=>picked.has(item.id)))renderSelectedObjectGroupFrame(items,items.length===picked.size);
 }
}
function renderSelectedObjectGroupFrame(items,canResize,contextOnly=false){
 const width=layer.clientWidth||640,height=layer.clientHeight||640;
 const bounds=items.map(o=>{const node=layer.querySelector('[data-id="'+o.id+'"]'),r=node?.getBoundingClientRect(),s=layer.getBoundingClientRect();return {left:r?(r.left-s.left)/s.width*width:o.x/100*width-o.width/2,right:r?(r.right-s.left)/s.width*width:o.x/100*width+o.width/2,top:r?(r.top-s.top)/s.height*height:o.y/100*height-o.height/2,bottom:r?(r.bottom-s.top)/s.height*height:o.y/100*height+o.height/2}});
 const left=Math.min(...bounds.map(b=>b.left)),right=Math.max(...bounds.map(b=>b.right)),top=Math.min(...bounds.map(b=>b.top)),bottom=Math.max(...bounds.map(b=>b.bottom));
 const box=document.createElement('div');box.className='controlbox object-group-control'+(canResize?' group-only-selection':'')+(contextOnly?' object-group-context':'');box.style.cssText=`left:${(left+right)/2}px;top:${(top+bottom)/2}px;width:${right-left}px;height:${bottom-top}px;--rot:0deg`;
 box.dataset.objectGroupId=items[0].objectGroupId;if(contextOnly)box.setAttribute('aria-hidden','true');
 if(canResize&&!items.some(o=>o.locked))for(const [sx,sy] of [[-1,-1],[1,-1],[-1,1],[1,1]]){
  const handle=document.createElement('button');handle.type='button';handle.className='handle group-resize-handle';handle.style.cssText=`left:${sx<0?0:100}%;top:${sy<0?0:100}%;transform:translate(-50%,-50%);cursor:${sx===sy?'nwse':'nesw'}-resize`;handle.title='グループの中心を固定して拡大・縮小（Shift：配置間隔のみ）';handle.setAttribute('aria-label',handle.title);
  handle.onpointerdown=e=>{if(e.button!==0||boardReadOnly||phaseComparisonActive())return;e.preventDefault();e.stopPropagation();const r=layer.getBoundingClientRect(),cx=(left+right)/2/width*100,cy=(top+bottom)/2/height*100;drag={mode:'group-scale',spacing:e.shiftKey,pointerId:e.pointerId,beforeData:JSON.stringify(data),cx,cy,startX:e.clientX,startY:e.clientY,geometry:objectGroupDimensions(items),vx:e.clientX-(r.left+cx/100*r.width),vy:e.clientY-(r.top+cy/100*r.height),items:items.map(o=>JSON.parse(JSON.stringify(o))),moved:false};stage.setPointerCapture(e.pointerId)};
  box.append(handle);
 }
 if(canResize&&!items.some(o=>o.locked)){
  const handle=document.createElement('button');handle.type='button';handle.className='handle rotate group-rotate-handle';handle.innerHTML=rotationHandleMarkup();handle.title='回転（配置）：ドラッグ／回転（向き）：Shift＋ドラッグ';handle.setAttribute('aria-label',handle.title);
  handle.onpointerdown=e=>{if(e.button!==0||boardReadOnly||phaseComparisonActive())return;e.preventDefault();e.stopPropagation();const r=layer.getBoundingClientRect(),{cx,cy}=objectGroupRotationCenter(items),angle=Math.atan2(e.clientY-(r.top+cy/100*r.height),e.clientX-(r.left+cx/100*r.width));drag={mode:'group-rotate',pointerId:e.pointerId,board:data,page:current(),beforeData:JSON.stringify(data),items:JSON.parse(JSON.stringify(items)),cx,cy,lastAngle:angle,degrees:0,rotateContents:e.shiftKey,orientationOnly:e.shiftKey,moved:false};stage.setPointerCapture(e.pointerId)};
  box.append(handle);
 }
 if(canResize&&!items.some(o=>o.locked)&&matchMedia('(max-width:850px)').matches){
  const handle=document.createElement('button');handle.type='button';handle.className='handle move-handle group-move-handle';handle.title='ドラッグでグループ全体を移動';handle.setAttribute('aria-label',handle.title);handle.innerHTML=moveHandleMarkup();
  if(drag?.mode==='move'&&drag.moveHandlePressed&&drag.pointerType==='touch'&&items.every(o=>drag.ids.includes(o.id)))handle.classList.add('phone-control-pressed');
  handle.onpointerdown=e=>{if(e.button!==0||boardReadOnly||phaseComparisonActive()||items.some(o=>o.locked))return;e.preventDefault();e.stopPropagation();const ids=items.map(o=>o.id);stage.setPointerCapture(e.pointerId);drag={mode:'move',moveHandlePressed:true,pointerId:e.pointerId,pointerType:e.pointerType,ids,originalIds:ids.slice(),starts:items.map(o=>({id:o.id,x:o.x,y:o.y})),startX:e.clientX,startY:e.clientY,lastX:e.clientX,lastY:e.clientY,moved:false,ctrlAtStart:false,ctrlBroken:false,beforeData:JSON.stringify(data)}};
  box.append(handle);
 }
 controls.append(box);
}

// ===== js/canvas.js =====
// canvas: shared function declarations; initialized by bolxiv.js in the documented order.
function blockReadOnlyEvent(event){event.preventDefault();event.stopImmediatePropagation()}

function readOnlyTarget(target){return target instanceof Element&&!!target.closest(readOnlyEditTargets)}

// LAN HTTP origins lack randomUUID, but still support getRandomValues.
function createObjectId(){
 if(typeof crypto.randomUUID==='function')return crypto.randomUUID();
 const bytes=crypto.getRandomValues(new Uint8Array(16));
 bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;
 const hex=Array.from(bytes,byte=>byte.toString(16).padStart(2,'0')).join('');
 return hex.slice(0,8)+'-'+hex.slice(8,12)+'-'+hex.slice(12,16)+'-'+hex.slice(16,20)+'-'+hex.slice(20);
}

function selectPlacementTool(type){stage.classList.remove('placement-waiting');if(type!=='image')pendingImage=null;tool=type;activeIcon=null;document.querySelectorAll('.tool').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.icon-choice').forEach(x=>{x.classList.remove('active');x.setAttribute('aria-pressed','false')});document.querySelectorAll('.tool[data-tool]').forEach(button=>{const active=button.dataset.tool===type;button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active))})}

function selectPlacementIcon(icon,refresh=true){stage.classList.remove('placement-waiting');pendingImage=null;activeIcon=icon;tool='icon';document.querySelectorAll('.tool').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.icon-choice').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.icon-choice').forEach(button=>{const active=icon.userPresetId?button.classList.contains('user-preset')&&button.dataset.presetId===icon.userPresetId:!button.classList.contains('user-preset')&&button.title===icon.name;button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active))})}

function renderIconGrid(group,gridId){group=group||$('#iconGroup').value;let grid=$('#'+(gridId||'iconGrid'));grid.innerHTML='';for(let [name,folder,fileName,badge=''] of iconFiles[group]){let src=iconPath(fileName,folder),imageSrc=embeddedPngs[src]||src,b=document.createElement('button');b.className='icon-choice';b.title=name;b.draggable=true;b.innerHTML=`<img src="${imageSrc}" alt="${name}">${badge?`<span class="role-badge">${badge}</span>`:''}`;let icon={name,src,badge};b.onclick=()=>{selectPlacementIcon(icon);};b.ondragstart=e=>{selectPlacementIcon(icon,false);e.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));e.dataTransfer.effectAllowed='copy'};grid.appendChild(b)}}

function renderEnemyGrid(){let grid=document.getElementById('enemyGrid');if(!grid)return;grid.innerHTML='';let icons=[{name:'大ボス',src:'assets/enemies/mini-boss.svg',badge:''},{name:'中ボス',src:'assets/enemies/mid-boss.svg',badge:''},{name:'小ボス',src:'assets/enemies/small-boss.svg',badge:''}];for(let icon of icons){let button=document.createElement('button');button.className='icon-choice';button.title=icon.name;button.draggable=true;button.innerHTML='<img src="'+bossIconSource({iconName:icon.name,src:icon.src,color:bossDefaultColor(icon.name)})+'" alt="'+icon.name+'">';button.onclick=()=>{selectPlacementIcon(icon);};button.ondragstart=e=>{selectPlacementIcon(icon,false);e.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));e.dataTransfer.effectAllowed='copy'};grid.appendChild(button)}}

function renderDistanceFalloffIcon(){const grid=document.getElementById('aoeTools');if(!grid)return;grid.querySelector('[data-aoe-icon="distance-falloff"]')?.remove();const icon={name:'距離減衰',src:'assets/aoe/distance-falloff.svg',badge:''},button=document.createElement('button');button.className='icon-choice';button.dataset.aoeIcon='distance-falloff';button.title=icon.name;button.setAttribute('aria-label',icon.name);button.draggable=true;button.innerHTML='<img src="'+embeddedPngs[icon.src]+'" alt="'+icon.name+'">';button.onclick=()=>{selectPlacementIcon(icon);};button.ondragstart=e=>{selectPlacementIcon(icon,false);e.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));e.dataTransfer.effectAllowed='copy'};grid.insertBefore(button,grid.querySelector('[data-tool="gaze"]'))}

function renderFlareIcon(){const grid=document.getElementById('aoeTools');if(!grid)return;grid.querySelector('[data-aoe-icon="flare"]')?.remove();const icon={name:'フレア',src:'assets/aoe/flare.svg',badge:''},button=document.createElement('button');button.className='icon-choice';button.dataset.aoeIcon='flare';button.title=icon.name;button.setAttribute('aria-label',icon.name);button.draggable=true;button.innerHTML='<img src="'+embeddedPngs[icon.src]+'" alt="'+icon.name+'">';button.onclick=()=>{selectPlacementIcon(icon);};button.ondragstart=e=>{selectPlacementIcon(icon,false);e.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));e.dataTransfer.effectAllowed='copy'};grid.appendChild(button)}

function renderDivebombIcon(){const grid=document.getElementById('aoeTools');if(!grid)return;grid.querySelector('[data-aoe-icon="divebomb"]')?.remove();const icon={name:'ロックオン青',src:'assets/aoe/divebomb.svg',badge:''},button=document.createElement('button');button.className='icon-choice';button.dataset.aoeIcon='divebomb';button.title=icon.name;button.setAttribute('aria-label',icon.name);button.draggable=true;button.innerHTML='<img src="'+embeddedPngs[icon.src]+'" alt="'+icon.name+'">';button.onclick=()=>{selectPlacementIcon(icon);};button.ondragstart=e=>{selectPlacementIcon(icon,false);e.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));e.dataTransfer.effectAllowed='copy'};grid.insertBefore(button,grid.querySelector('[data-aoe-icon="target-purple"]'))}

function renderTargetRedIcon(){const grid=document.getElementById('aoeTools');if(!grid)return;grid.querySelector('[data-aoe-icon="target-red"]')?.remove();const icon={name:'ロックオン赤',src:'assets/aoe/target-red.svg',badge:''},button=document.createElement('button');button.className='icon-choice';button.dataset.aoeIcon='target-red';button.title=icon.name;button.setAttribute('aria-label',icon.name);button.draggable=true;button.innerHTML='<img src="'+embeddedPngs[icon.src]+'" alt="'+icon.name+'">';button.onclick=()=>{selectPlacementIcon(icon);};button.ondragstart=e=>{selectPlacementIcon(icon,false);e.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));e.dataTransfer.effectAllowed='copy'};grid.appendChild(button)}

function renderTargetPurpleIcon(){const grid=document.getElementById('aoeTools');if(!grid)return;grid.querySelector('[data-aoe-icon="target-purple"]')?.remove();const icon={name:'ロックオン紫',src:'assets/aoe/target-purple.svg',badge:''},button=document.createElement('button');button.className='icon-choice';button.dataset.aoeIcon='target-purple';button.title=icon.name;button.setAttribute('aria-label',icon.name);button.draggable=true;button.innerHTML='<img src="'+embeddedPngs[icon.src]+'" alt="'+icon.name+'">';button.onclick=()=>{selectPlacementIcon(icon);};button.ondragstart=e=>{selectPlacementIcon(icon,false);e.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));e.dataTransfer.effectAllowed='copy'};grid.appendChild(button)}

function renderTargetGreenIcon(){const grid=document.getElementById('aoeTools');if(!grid)return;grid.querySelector('[data-aoe-icon="target-green"]')?.remove();const icon={name:'ロックオン緑',src:'assets/aoe/target-green.svg',badge:''},button=document.createElement('button');button.className='icon-choice';button.dataset.aoeIcon='target-green';button.title=icon.name;button.setAttribute('aria-label',icon.name);button.draggable=true;button.innerHTML='<img src="'+embeddedPngs[icon.src]+'" alt="'+icon.name+'">';button.onclick=()=>{selectPlacementIcon(icon);};button.ondragstart=e=>{selectPlacementIcon(icon,false);e.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));e.dataTransfer.effectAllowed='copy'};grid.querySelector('[data-aoe-icon="target-purple"]').after(button)}

function renderTowerIcons(){const grid=document.getElementById('aoeTools');if(!grid)return;grid.querySelectorAll('[data-aoe-icon^="tower"]').forEach(button=>button.remove());let anchor=grid.querySelector('[data-aoe-icon="target-purple"]')||grid.querySelector('[data-aoe-icon="divebomb"]');for(let number=1;number<=4;number++){const icon={name:'塔踏み'+number,src:'assets/aoe/tower'+number+'.svg',badge:''},button=document.createElement('button');button.className='icon-choice';button.dataset.aoeIcon='tower'+number;button.title=icon.name;button.setAttribute('aria-label',icon.name);button.draggable=true;button.innerHTML='<img src="'+towerIconSource({type:'icon',iconName:icon.name})+'" alt="'+icon.name+'">';button.onclick=()=>selectPlacementIcon(icon);button.ondragstart=e=>{selectPlacementIcon(icon,false);e.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));e.dataTransfer.effectAllowed='copy'};if(anchor)anchor.after(button);else grid.append(button);anchor=button}}

function addTowerColorSetting(el,o){if(!isTowerObject(o))return;const field=document.createElement('div');field.className='field';field.innerHTML='<label>色</label>'+colorPickerMarkup('object',o.color||'#f39c12',o.id);el.append(field);if(boardReadOnly||o.locked)field.querySelector('[data-color-trigger]').disabled=true}

function renderAllIconGrids(){renderDistanceFalloffIcon();renderFlareIcon();renderTargetRedIcon();renderTargetPurpleIcon();renderDivebombIcon();renderTowerIcons();renderTargetGreenIcon();renderEnemyGrid();renderIconGrid('role','roleGrid');let group=$('#iconGroup').value;if(group==='none')$('#iconGrid').innerHTML='';else renderIconGrid(group,'iconGrid');renderIconGrid('targetMarker','targetMarkerGrid');renderIconGrid('fieldMarker','fieldMarkerGrid')}

function render(){if(phaseComparisonRendering){renderSingle();return}document.querySelectorAll('#layoutPropertiesPanel input,#layoutPropertiesPanel select,#layoutPropertiesPanel button').forEach(node=>node.disabled=false);if(phaseSelectionOwner!==data){phaseSelectionOwner=data;selectedPhaseIndexes=[]}selectedPhaseIndexes=selectedPhaseIndexes.filter(i=>i>=0&&i<data.pages.length);const comparing=selectedPhaseIndexes.length>1;try{renderSingle();renderPhaseComparison()}catch(error){if(!comparing)throw error;console.error('Phase comparison failed',error);phaseComparisonRendering=false;selectedPhaseIndexes=[];document.body.classList.remove('phase-comparison-active');document.querySelector('.phase-comparison-grid')?.remove();document.querySelectorAll('#layoutPropertiesPanel input,#layoutPropertiesPanel select,#layoutPropertiesPanel button').forEach(node=>node.disabled=false);try{renderSingle();renderPhaseComparison()}catch(recoveryError){console.error('Phase comparison recovery failed',recoveryError)}notify('並べて表示に失敗：'+(error?.message||String(error)));clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),15000)}}

function updateModeStatus(){
 const button=document.getElementById('editModeToggle');if(!button)return;
 const preview=!!window.Bolxiv?.pngPreview?.active,parallel=phaseComparisonActive(),view=preview||boardReadOnly||parallel,label=preview?(window.Bolxiv.pngPreview.kind==='print'?'印刷モード':'画像生成モード'):parallel?'閲覧モード（並列表示）':view?'閲覧モード':'編集モード';
 let modeLine=document.getElementById('phoneCanvasModeStatus');if(!modeLine){modeLine=document.createElement('span');modeLine.id='phoneCanvasModeStatus';modeLine.className='phone-canvas-mode-status';modeLine.setAttribute('aria-live','polite');document.querySelector('.board-title-row').append(modeLine)}modeLine.textContent=preview?(window.Bolxiv.pngPreview.kind==='print'?'印刷':'画像生成'):view?'閲覧':'編集';
 let contentMode=document.getElementById('phoneContentModeStatus');if(!contentMode){contentMode=document.createElement('span');contentMode.id='phoneContentModeStatus';contentMode.setAttribute('aria-live','polite');document.getElementById('toggleContent').append(contentMode)}contentMode.textContent=modeLine.textContent;contentMode.title=label;
 button.querySelector('.mode-label').textContent=label;
 button.querySelector('.mode-icon').innerHTML='<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(preview&&window.Bolxiv.pngPreview.kind==='print'?'<path d="M6 9V3h12v6M6 18H4V9h16v9h-2M6 14h12v7H6Z"/><path d="M17 12h.01"/>':preview?'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 5-5 4 4 3-3 6 6"/>':view?'<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>':'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L8 18l-4 1 1-4Z"/>')+'</svg>';
 button.classList.toggle('view-state',view);button.removeAttribute('aria-pressed');
 button.disabled=!!window.Bolxiv?.fieldGuideEditor?.active||preview&&!!window.Bolxiv.pngPreview.saving;button.title=window.Bolxiv?.fieldGuideEditor?.active?'ガイドの編集を完了するとモードを切り替えられます':'モード切替メニューを開く';
 button.setAttribute('aria-label',label+'：'+button.title);
}

function aoeGeometry(o){let angle=Math.max(5,Math.min(179.5,Number(o.angle)||34)),rad=angle*Math.PI/180,r=90,apexX=50,apexY=5,leftX=apexX-r*Math.sin(rad),rightX=apexX+r*Math.sin(rad),endY=apexY+r*Math.cos(rad);return{angle,rad,apexX,apexY,leftX,rightX,endY,path:`M${apexX} ${apexY} L${leftX} ${endY} A${r} ${r} 0 ${angle>90?1:0} 0 ${rightX} ${endY} Z`}}

function donutMaxInnerDiameter(o){return Math.max(0,Math.min(o.width,o.height)-donutMinRingWidth*2)}

function donutInnerDiameter(o){return Math.max(0,Math.min(donutMaxInnerDiameter(o),Math.hypot(o.width,o.height)/Math.sqrt(8)*(Number.isFinite(o.innerSize)?o.innerSize:79)/100))}

function setDonutInnerDiameter(o,value){const diameter=Math.max(0,Math.min(donutMaxInnerDiameter(o),Math.round(Number(value)||0)));o.innerSize=diameter/Math.hypot(o.width,o.height)*Math.sqrt(8)*100;return diameter}

function donutInnerRadius(o){return donutInnerDiameter(o)/2}

function syncDonutInnerInputs(o){const value=Math.round(donutInnerDiameter(o));for(const id of ['donutInnerInput','donutInnerSpin']){const input=document.getElementById(id);if(input){input.max=donutMaxInnerDiameter(o);input.value=value}}const label=document.getElementById('donutInnerValue');if(label)label.textContent=value}

function placeDonutInnerHandles(o,box){
 const radius=donutInnerRadius(o);
 for(const handle of box.querySelectorAll('.donut-inner-handle')){handle.style.left=(50+(handle.dataset.side==='left'?-1:1)*radius/o.width*100)+'%';handle.style.top='50%'}
}

function placeAoeAngleHandles(o,box){let g=aoeGeometry(o);for(let h of box.querySelectorAll('.aoe-angle-handle')){h.style.left=(h.dataset.side==='left'?g.leftX:g.rightX)+'%';h.style.top=g.endY+'%'}}

function allowNativeContextMenu(target){return target instanceof Element&&!!target.closest('input,textarea,select,a,[contenteditable]:not([contenteditable="false"])')}

function createFieldImageLayer(className){const visual=document.createElement('div'),img=document.createElement('img'),tint=document.createElement('span');visual.className=className;img.alt='';tint.className='field-image-tint';visual.append(img,tint);return visual}

function renderImage4Fields(){let holder=stage.querySelector('.image4-fields');if(activeBoardShape()!=='image4'){holder?.remove();return}if(!holder){holder=document.createElement('div');holder.className='image4-fields';for(let i=0;i<4;i++){const cell=document.createElement('div');cell.className='image4-cell';cell.append(createFieldImageLayer('field-image-tile'));holder.append(cell)}stage.insertBefore(holder,stage.firstChild)}for(const img of holder.querySelectorAll('img'))img.src=fieldImageSource()}

// Field guides are phase artwork, independent of the editing grid.
function fieldGuideReference(board,index){const shape=board.pageBoardShapes?.[index]||board.boardShape,size=board.pageFieldSizes?.[index]||{width:shape==='portrait'?320:538,height:shape==='landscape'?320:538};return {width:size.width,height:size.height,shape:shape==='circle'?'circle':shape==='image4'?'image4':'rect'}}
function fieldGuides(board,index){
 const value=board.pageFieldGuides?.[index]||{},integer=(key,fallback,min,max)=>Number.isFinite(value[key])?Math.max(min,Math.min(max,Math.round(value[key]))):fallback;
 const shapes=[],ids=new Set();
 for(const item of (Array.isArray(value.shapes)?value.shapes:[]).slice(0,500)){
  if(!item||!['line','circle','rect','triangle','diamond'].includes(item.type)||!['x','y','width','height','rotation'].every(key=>Number.isFinite(item[key])))continue;
  const id=typeof item.id==='string'&&/^[\w-]{1,80}$/.test(item.id)?item.id:'guide-'+shapes.length;if(ids.has(id))continue;ids.add(id);
  shapes.push({...(item.appearance&&/^#[0-9a-f]{6}$/i.test(item.appearance.color)&&Number.isFinite(item.appearance.opacity)?{appearance:{color:item.appearance.color.toLowerCase(),opacity:Math.max(0,Math.min(100,Math.round(item.appearance.opacity)))}}:{}),id,type:item.type,x:Math.max(0,Math.min(640,item.x)),y:Math.max(0,Math.min(640,item.y)),width:Math.max(1,Math.min(1280,item.width)),height:Math.max(1,Math.min(1280,item.height)),rotation:((item.rotation%360)+360)%360,...(item.type!=='line'&&(item.fill===true||item.fill==='solid')?{fill:item.fill}:{}),...(typeof item.objectGroupId==='string'&&/^[\w-]{1,80}$/.test(item.objectGroupId)?{objectGroupId:item.objectGroupId}:{})});
 }
 const groupCounts=new Map();for(const item of shapes)if(item.objectGroupId)groupCounts.set(item.objectGroupId,(groupCounts.get(item.objectGroupId)||0)+1);for(const item of shapes)if(item.objectGroupId&&groupCounts.get(item.objectGroupId)<2)delete item.objectGroupId;
 const source=value.reference&&typeof value.reference==='object'?value.reference:value.circles||value.rays||shapes.length?fieldGuideReference(board,index):null;
 const reference=source?{width:Number.isFinite(source.width)?Math.max(64,Math.min(960,source.width)):538,height:Number.isFinite(source.height)?Math.max(64,Math.min(960,source.height)):538,shape:['circle','image4'].includes(source.shape)?source.shape:'rect'}:null;
 return {...(['field','circle'].includes(value.rayMode)?{rayMode:value.rayMode,fieldRayLength:integer('fieldRayLength',100,0,100),circleRayLength:integer('circleRayLength',100,0,3200)}:{}),reference,circles:value.circles===true,outerRing:value.outerRing!==false,rays:value.rays===true,rings:integer('rings',3,2,12),ringScale:integer('ringScale',100,1,200),sectors:integer('sectors',8,2,32),rayLength:integer('rayLength',100,0,100),rayBoundary:value.rayBoundary==='circle'?'circle':'field',rayScale:Number.isFinite(value.rayScale)?Math.max(0,Math.min(32,value.rayScale)):null,rotation:integer('rotation',0,0,359),color:/^#[0-9a-f]{6}$/i.test(value.color)?value.color:'#ffffff',opacity:integer('opacity',50,0,100),shapes};
}
function fieldGuideRayMetrics(board=data,index=board.page){
 const size=fieldGuideReference(board,index),tiled=size.shape==='image4',rx=Math.min(size.width/2,tiled?160:Infinity),ry=Math.min(size.height/2,tiled?160:Infinity),circle=Math.min(rx,ry),square=Math.hypot(rx,ry);return {circle,square,maximum:square/circle};
}
function fieldGuideRayScale(settings,metrics){return Math.min(metrics.maximum,settings.rayScale??settings.rayLength/100*(settings.rayBoundary==='circle'?1:metrics.maximum))}
function fieldGuideRayValues(settings,metrics){const scale=fieldGuideRayScale(settings,metrics);return settings.rayMode?{fieldRayLength:settings.fieldRayLength,circleRayLength:settings.circleRayLength}:{fieldRayLength:Math.round(scale/metrics.maximum*100),circleRayLength:Math.round(scale*100)}}
function createFieldGuideShape(shape){
 const node=document.createElementNS('http://www.w3.org/2000/svg',shape.type==='line'?'line':shape.type==='circle'?'ellipse':['triangle','diamond'].includes(shape.type)?'polygon':'rect');
 const attributes=shape.type==='line'?{x1:-shape.width/2,y1:0,x2:shape.width/2,y2:0}:shape.type==='circle'?{cx:0,cy:0,rx:shape.width/2,ry:shape.height/2}:shape.type==='diamond'?{points:'0,'+(-shape.height/2)+' '+shape.width/2+',0 0,'+shape.height/2+' '+(-shape.width/2)+',0'}:shape.type==='triangle'?{points:'0,'+(-shape.height/2)+' '+shape.width/2+','+shape.height/2+' '+(-shape.width/2)+','+shape.height/2}:{x:-shape.width/2,y:-shape.height/2,width:shape.width,height:shape.height};
 for(const [key,value] of Object.entries(attributes))node.setAttribute(key,value);
 if(shape.type==='line')node.setAttribute('stroke-width',Math.max(1.5,shape.height));
 node.setAttribute('transform','translate('+shape.x+' '+shape.y+') rotate('+shape.rotation+')');if(shape.type!=='line'&&(shape.fill===true||shape.fill==='solid')){node.setAttribute('fill','currentColor');node.setAttribute('fill-opacity',shape.fill==='solid'?'1':'0.25')}node.dataset.guideShapeId=shape.id;return node;
}
function renderFieldGuides(){
 stage.querySelector('.field-guides')?.remove();
 const settings=fieldGuides(data,data.page),reference=fieldGuideReference(data,data.page),shape=reference.shape;
 if(!settings.circles&&!settings.rays&&!settings.shapes.length)return;
 const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');
 svg.setAttribute('class','field-guides');svg.setAttribute('viewBox','0 0 640 640');svg.setAttribute('aria-hidden','true');
 const size=reference,tiles=shape==='image4'?[[160,160],[480,160],[160,480],[480,480]]:[[320,320]],defs=document.createElementNS(ns,'defs');svg.append(defs);
 tiles.forEach(([cx,cy],tile)=>{
  const clipId='field-guide-clip-'+tile,clip=document.createElementNS(ns,'clipPath');clip.id=clipId;
  const boundary=document.createElementNS(ns,shape==='circle'?'ellipse':'rect');
  if(shape==='circle'){for(const [key,value] of Object.entries({cx,cy,rx:size.width/2,ry:size.height/2}))boundary.setAttribute(key,value)}
  else for(const [key,value] of Object.entries({x:cx-size.width/2,y:cy-size.height/2,width:size.width,height:size.height}))boundary.setAttribute(key,value);
  clip.append(boundary);defs.append(clip);
  const group=document.createElementNS(ns,'g');group.setAttribute('clip-path','url(#'+clipId+')');
  group.setAttribute('fill','none');group.setAttribute('stroke',settings.color);group.setAttribute('stroke-width','1.5');group.setAttribute('opacity',settings.opacity/100);
  if(shape==='image4'){const cellClip=document.createElementNS(ns,'clipPath'),rect=document.createElementNS(ns,'rect');cellClip.id=clipId+'-cell';for(const [key,value] of Object.entries({x:cx-160,y:cy-160,width:320,height:320}))rect.setAttribute(key,value);cellClip.append(rect);defs.append(cellClip);const cell=document.createElementNS(ns,'g');cell.setAttribute('clip-path','url(#'+cellClip.id+')');cell.append(group);svg.append(cell)}else svg.append(group);
  if(settings.circles)for(let i=1;i<settings.rings+(settings.outerRing?1:0);i++){const circle=document.createElementNS(ns,'circle');for(const [key,value] of Object.entries({cx,cy,r:Math.max(0,fieldGuideRayMetrics().circle*settings.ringScale/100*i/settings.rings-(i===settings.rings ? .75 : 0))}))circle.setAttribute(key,value);group.append(circle)}
  if(settings.rays)for(let i=0;i<settings.sectors;i++){const angle=(settings.rotation+i*360/settings.sectors-90)*Math.PI/180,metrics=fieldGuideRayMetrics(),length=settings.rayMode==='field'?Math.min(Math.min(size.width/2,shape==='image4'?160:Infinity)/Math.max(Math.abs(Math.cos(angle)),1e-12),Math.min(size.height/2,shape==='image4'?160:Infinity)/Math.max(Math.abs(Math.sin(angle)),1e-12))*settings.fieldRayLength/100:settings.rayMode==='circle'?metrics.circle*Math.min(metrics.maximum,settings.circleRayLength/100):metrics.circle*fieldGuideRayScale(settings,metrics),line=document.createElementNS(ns,'line');for(const [key,value] of Object.entries({x1:cx,y1:cy,x2:cx+Math.cos(angle)*length,y2:cy+Math.sin(angle)*length}))line.setAttribute(key,value);group.append(line)}
 });
 if(settings.shapes.length){const group=document.createElementNS(ns,'g');group.setAttribute('class','field-guide-shapes');group.setAttribute('color',settings.color);group.setAttribute('fill','none');group.setAttribute('stroke',settings.color);group.setAttribute('stroke-width','1.5');group.setAttribute('opacity',settings.opacity/100);const individual=settings.reference||reference;if(individual.shape!=='image4'){const clip=document.createElementNS(ns,'clipPath'),boundary=document.createElementNS(ns,individual.shape==='circle'?'ellipse':'rect');clip.id='field-guide-shape-clip';const attrs=individual.shape==='circle'?{cx:320,cy:320,rx:individual.width/2,ry:individual.height/2}:{x:320-individual.width/2-1,y:320-individual.height/2-1,width:individual.width+2,height:individual.height+2};for(const [key,value] of Object.entries(attrs))boundary.setAttribute(key,value);clip.append(boundary);defs.append(clip);group.setAttribute('clip-path','url(#field-guide-shape-clip)')}if(!settings.shapes.some(item=>item.appearance)){for(const item of settings.shapes)group.append(createFieldGuideShape(item))}else{group.removeAttribute('opacity');let run=null,key=null;for(const item of settings.shapes){const appearance=item.appearance||settings,next=appearance.color+':'+appearance.opacity;if(next!==key){run=document.createElementNS(ns,'g');run.setAttribute('color',appearance.color);run.setAttribute('stroke',appearance.color);run.setAttribute('opacity',appearance.opacity/100);group.append(run);key=next}run.append(createFieldGuideShape(item))}}svg.append(group)}
 stage.insertBefore(svg,objectClip);
}

function renderFieldImageAppearance(){
 const shape=activeBoardShape(),tint=fieldImageTint(data,data.page);let visual=stage.querySelector('.field-image-visual');
 stage.style.setProperty('--field-image-tint-color',tint.color);stage.style.setProperty('--field-image-tint-strength',String(tint.strength/100));
 if(shape==='image'){
  if(!visual){visual=createFieldImageLayer('field-image-visual');stage.insertBefore(visual,stage.firstChild)}
  const img=visual.querySelector('img'),source=fieldImageSource();if(img.getAttribute('src')!==source)img.src=source;
 }else visual?.remove();
}

function showLockedSelection(o,el){
 if(!o.locked||!selectedIds.includes(o.id)||boardReadOnly||phaseComparisonRendering)return;
 // The lock frame already represents selection; suppress the object's fallback outline.
 el.classList.add('has-selection-controls');
 const box=document.createElement('div');box.className='controlbox locked-selection-control'+(o.objectGroupId&&selectedIds.length>1&&!individualGroupSelectionActive()?' group-member-selection':'');box.setAttribute('role','img');box.setAttribute('aria-label','編集不可のオブジェクト');box.style.left=o.x+'%';box.style.top=o.y+'%';box.style.width=(o.width||el.offsetWidth||34)+'px';box.style.height=(o.type==='text'?el.offsetHeight:o.height||el.offsetHeight||34)+'px';box.style.setProperty('--rot',(o.rotation||0)+'deg');
 let frame=box;
 if(['stack','linestack','targetcircle','aoe'].includes(o.type)){const names={stack:'stack',linestack:'stack',targetcircle:'targetcircle',aoe:'aoe'},name=names[o.type];box.classList.add(name+'-control');frame=document.createElement('div');frame.className=name+'-control-frame';box.append(frame);if(name==='stack')fitStackControl(o,box);else if(name==='targetcircle')fitTargetCircleControl(o,box);else fitAoeControl(o,box)}
 const badge=document.createElement('span');badge.className='selection-lock-badge';badge.setAttribute('aria-hidden','true');badge.style.transform='rotate('+(-(o.rotation||0))+'deg)';badge.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M8 9V7a4 4 0 018 0v2"/><rect x="4.5" y="9" width="15" height="12" rx="3"/><circle cx="12" cy="14" r="1.2" fill="currentColor" stroke="none"/><path d="M12 15v2" stroke-width="2"/></svg>';frame.append(badge);controls.append(box)
}

function showLockedSelectionHint(el,items){
 const count=items.filter(o=>o.locked).length;if(!count||boardReadOnly)return;
 const note=document.createElement('p');note.className='hint locked-selection-hint';note.textContent=(items.length===1?'編集不可':count+'個が編集不可')+'：キャンバス上では移動・サイズ変更できません。上の鍵ボタンで解除できます。';const kind=el.querySelector('.property-kind-row');if(kind)kind.after(note);else{note.textContent=note.textContent.replace('上の鍵ボタン','オブジェクトリストの鍵ボタン');el.prepend(note)}
}

function renderObjectSelectionControls(o,el){if(boardReadOnly||phaseComparisonActive())return;showLockedSelection(o,el);
if(selectedIds.length===1&&selected===o.id&&(['circle','donut','aoe','line','gaze','segment'].includes(o.type)||o.type==='icon'||o.type==='image'||o.type==='text'||o.type==='marker'||(o.type==='targetcircle'||['stack','linestack'].includes(o.type)||(['knockback','lineknockback'].includes(o.type))))&&!o.locked){el.classList.add('has-selection-controls');let box=document.createElement('div');box.className='controlbox';box.dataset.id=o.id;box.style.left=o.x+'%';box.style.top=o.y+'%';box.style.width=(o.width||el.offsetWidth||34)+'px';box.style.height=o.type==='text'?el.offsetHeight+'px':(o.height||el.offsetHeight||34)+'px';box.style.setProperty('--rot',(o.rotation||0)+'deg');const proportionalResize=proportionalSizeType(o.type);let handleContainer=box;if(['stack','linestack'].includes(o.type)){box.classList.add('stack-control');const frame=document.createElement('div');frame.className='stack-control-frame';box.appendChild(frame);fitStackControl(o,box);handleContainer=frame}if(o.type==='targetcircle'){box.classList.add('targetcircle-control');let frame=document.createElement('div');frame.className='targetcircle-control-frame';box.appendChild(frame);fitTargetCircleControl(o,box);handleContainer=frame}if(o.type==='donut'){
 for(const side of ['left','right']){const handle=document.createElement('button');handle.className='handle donut-inner-handle';handle.dataset.side=side;handle.title='ドラッグで内円サイズを変更';handle.setAttribute('aria-label',handle.title);handle.addEventListener('pointerdown',e=>{if(boardReadOnly||o.locked||phaseComparisonActive()||e.button!==0)return;e.preventDefault();e.stopPropagation();recordHistory();drag={mode:'resize-donut-inner',id:o.id,pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,ox:o.x,oy:o.y,width:o.width,height:o.height,rotation:o.rotation||0};handle.setPointerCapture(e.pointerId)});box.appendChild(handle)}
 placeDonutInnerHandles(o,box);
}
if(o.type==='aoe'){for(let side of ['left','right']){let h=document.createElement('button');h.className='handle aoe-angle-handle';h.dataset.side=side;h.title='扇範囲の角度';h.setAttribute('aria-label','扇範囲の角度');h.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();recordHistory();drag={mode:'resize-angle',id:o.id,side,startX:e.clientX,startY:e.clientY,ox:o.x,oy:o.y,width:o.width||100,height:o.height||100,rotation:o.rotation||0}});box.appendChild(h)}}if(o.type==='aoe'){box.classList.add('aoe-control');const frame=document.createElement('div');frame.className='aoe-control-frame';box.appendChild(frame);fitAoeControl(o,box);for(const [sx,sy] of [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[1,-1],[-1,1],[1,1]]){const h=document.createElement('button');h.className='handle aoe-box-handle';h.style.left=((sx+1)*50)+'%';h.style.top=((sy+1)*50)+'%';h.style.cursor=sx&&sy?(sx===sy?'nwse-resize':'nesw-resize'):sx?'ew-resize':'ns-resize';h.title=sx&&sy?'縦横比を維持してサイズ変更':'この辺だけサイズ変更';h.setAttribute('aria-label',h.title);h.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();recordHistory();drag={mode:'resize-aoe-box',id:o.id,sx,sy,startX:e.clientX,startY:e.clientY,ox:o.x,oy:o.y,width:o.width,height:o.height,rotation:o.rotation||0,bounds:aoeControlBounds(o)}});frame.appendChild(h)}}if(o.type==='line'){for(const axis of ['x','y']){const h=document.createElement('button');h.className='handle resize-'+axis+' circle-opposite-handle';if(axis==='x'){h.style.right='auto';h.style.left='-7px'}else{h.style.bottom='auto';h.style.top='-7px'}h.title=axis==='x'?'左側からサイズ変更':'上側からサイズ変更';h.setAttribute('aria-label',h.title);h.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();recordHistory();drag={mode:'resize-'+axis,id:o.id,resizeSign:-1,startX:e.clientX,startY:e.clientY,ox:o.x,oy:o.y,width:o.width,height:o.height,rotation:o.rotation||0}});box.appendChild(h)}}if(o.type==='line'||proportionalResize){for(const [sx,sy] of [[-1,-1],[1,-1],[-1,1],[1,1]]){const h=document.createElement('button');h.className='handle aoe-box-handle';h.style.left=((sx+1)*50)+'%';h.style.top=((sy+1)*50)+'%';h.style.cursor=sx===sy?'nwse-resize':'nesw-resize';h.title='縦横比を維持してサイズ変更';h.setAttribute('aria-label',h.title);h.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();recordHistory();drag={mode:'resize-aoe-box',id:o.id,sx,sy,startX:e.clientX,startY:e.clientY,ox:o.x,oy:o.y,width:o.width,height:o.height,rotation:o.rotation||0,integerSize:proportionalResize&&o.type!=='image',minSize:o.type==='image'?Math.min(1,o.width,o.height):o.type==='icon'?24:20,maxSize:o.type==='icon'?640:960};if(['stack','linestack'].includes(o.type)){const b=stackControlBounds(o);drag.bounds={left:b.left/o.width,top:b.top/o.height,right:(b.left+b.width)/o.width,bottom:(b.top+b.height)/o.height}}if(o.type==='targetcircle'){drag.integerSize=true;const b=targetCircleControlBounds(o.width,o.height,targetCircleTriangleInside(o));drag.bounds={left:b.left/o.width,top:b.top/o.height,right:(b.left+b.width)/o.width,bottom:(b.top+b.height)/o.height}}});handleContainer.appendChild(h)}}let kinds=(o.type==='aoe'||proportionalResize||o.type==='marker')?['rotate']:o.type==='segment'||o.type==='text'?['resize-x','rotate']:['resize-x','resize-y','rotate'];for(let kind of kinds){let h=document.createElement('button');h.className='handle '+kind;if(kind==='rotate'){h.innerHTML=rotationHandleMarkup();h.setAttribute('aria-label','回転')} h.title=kind==='resize-icon'?'アイコンのサイズ':kind==='resize-x'?'X軸方向のサイズ':kind==='resize-y'?'Y軸方向のサイズ':'回転';h.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();recordHistory();drag={mode:kind,id:o.id,startX:e.clientX,startY:e.clientY,ox:o.x,oy:o.y,width:o.width||48,height:o.height||48,rotation:o.rotation||0}});handleContainer.appendChild(h)}if(o.type==='aoe'){placeAoeAngleHandles(o,box);fitAoeControl(o,box)}if(matchMedia('(max-width:850px)').matches){const h=document.createElement('button');h.type='button';h.className='handle move-handle';h.title='ドラッグで移動';h.setAttribute('aria-label',h.title);h.innerHTML=moveHandleMarkup();h.addEventListener('pointerdown',e=>{if(e.button!==0||boardReadOnly||o.locked||phaseComparisonActive())return;e.preventDefault();e.stopPropagation();stage.setPointerCapture(e.pointerId);drag={mode:'move',pointerId:e.pointerId,pointerType:e.pointerType,ids:[o.id],originalIds:[o.id],starts:[{id:o.id,x:o.x,y:o.y}],startX:e.clientX,startY:e.clientY,lastX:e.clientX,lastY:e.clientY,moved:false,ctrlAtStart:false,ctrlBroken:false,beforeData:JSON.stringify(data)}});handleContainer.appendChild(h);if(o.type==='aoe')fitAoeControl(o,box)}controls.appendChild(box)}}

let selectionPanelsRevision=0;
function renderSelectionOnly(deferPanels=false){
 const revision=++selectionPanelsRevision;
 if(phaseComparisonActive()){render();return}
 normalizeObjectSelection();clearAlignmentGuides();controls.replaceChildren();const selectedSet=new Set(selectedIds),objects=new Map(current().map(o=>[o.id,o]));
 for(const node of layer.children){const item=objects.get(node.dataset.id);if(!item)continue;const picked=selectedSet.has(item.id);node.classList.toggle('selected',picked);node.classList.toggle('selected-many',picked&&selectedIds.length>1);node.classList.toggle('group-member-selected',picked&&selectedIds.length>1&&!!item.objectGroupId&&!individualGroupSelectionActive());node.classList.remove('has-selection-controls');if(picked)renderObjectSelectionControls(item,node)}
 renderObjectGroupControls();
 if(deferPanels){const board=data,ids=selectedIds.join('|');requestAnimationFrame(()=>requestAnimationFrame(()=>{if(revision!==selectionPanelsRevision||data!==board||selectedIds.join('|')!==ids)return;renderObjectList();renderInspector()}))}else{renderObjectList();renderInspector()}
}

function placementToolPayload(){return tool==='image'&&pendingImage?pendingImage:tool==='icon'&&activeIcon?{type:'icon',...activeIcon}:{type:tool}}
function createImportedImageVisual(o,objectIndex,selectionIds){
 const el=document.createElement('div');el.dataset.id=o.id;el.className='obj imported-image';
 el.classList.toggle('selected',selectionIds.includes(o.id));
 if(selectionIds.length>1&&selectionIds.includes(o.id)){el.classList.add('selected-many');if(o.objectGroupId&&!individualGroupSelectionActive())el.classList.add('group-member-selected')}
 Object.assign(el.style,{zIndex:String(objectIndex+2),left:o.x+'%',top:o.y+'%',width:o.width+'px',height:o.height+'px',transform:'translate(-50%,-50%) rotate('+(o.rotation||0)+'deg)'});
 const image=document.createElement('img');image.alt='取り込み画像';image.draggable=false;bindImportedImage(image,o);el.append(image);applyShapeStyle(el,o);return el;
}
function createCanvasObjectVisual(o,objectIndex,selectionIds=selectedIds){if(o.type==='image')return createImportedImageVisual(o,objectIndex,selectionIds);
let el=document.createElement('div');el.dataset.id=o.id;el.style.zIndex=String(objectIndex+2);el.style.left=o.x+'%';el.style.top=o.y+'%';el.style.setProperty('--c',o.color);el.className='obj'+(selectionIds.includes(o.id)?' selected':'');if(Number.isFinite(o.rotation))el.style.transform='translate(-50%,-50%) rotate('+o.rotation+'deg)';if(selectionIds.length>1&&selectionIds.includes(o.id))el.classList.add('selected-many');if(selectionIds.length>1&&selectionIds.includes(o.id)&&o.objectGroupId&&!individualGroupSelectionActive())el.classList.add('group-member-selected');if(o.type==='icon'){el.classList.add('job-icon');if(['距離減衰','フレア','ロックオン青','ターゲット青','ロックオン赤','ロックオン緑','ロックオン紫','ダイブボム','ターゲット赤','ターゲット紫'].includes(o.iconName))el.classList.add('flare-icon');el.style.width=(o.width||44)+'px';el.style.height=(o.height||44)+'px';el.style.setProperty('--icon-size',(o.width||44)+'px');let img=document.createElement('img');img.src=isBossObject(o)?bossIconSource(o):isTowerObject(o)?towerIconSource(o):objectImageSource(o);img.alt=objectTitle(o);if(hasAdditionalOpacity(o))img.style.opacity=String(additionalOpacityValue(o)/100);if(o.iconName==='AoE 円範囲')img.style.opacity=String((Number.isFinite(o.opacity)?o.opacity:50)/100);if(['大ボス','中ボス','小ボス'].includes(o.iconName)){img.style.opacity=String((Number.isFinite(o.opacity)?o.opacity:100)/100);el.style.transform='translate(-50%,-50%) rotate('+(o.rotation||0)+'deg)'}if(['距離減衰','フレア','ロックオン青','ターゲット青','ロックオン赤','ロックオン緑','ロックオン紫','ダイブボム','ターゲット赤','ターゲット紫'].includes(o.iconName))el.style.transform='translate(-50%,-50%) rotate('+(o.rotation||0)+'deg)';el.appendChild(img);if(o.iconBadge){let badge=document.createElement('span'),iconSize=o.width||48;badge.className='role-badge';badge.textContent=o.iconBadge;badge.style.setProperty('font-size',Math.max(8,iconSize*.36)+'px','important');badge.style.right=(iconSize*.06)+'px';badge.style.bottom=(iconSize*.06)+'px';badge.style.webkitTextStroke=(iconSize*.03)+'px #111';el.appendChild(badge)}}else if(o.type==='marker'){el.classList.add('marker');el.style.background=o.color;el.textContent=o.label||'1'}else if(o.type==='text'){el.classList.add('labelobj');el.style.color=o.color;el.style.fontSize=(o.fontSize||12)+'px';el.style.width=(o.width||180)+'px';el.style.whiteSpace='pre-wrap';el.style.overflowWrap='anywhere';el.textContent=o.label||'メモ'}else{el.classList.add('shape',o.type);el.style.width=o.width+'px';el.style.height=o.height+'px';el.style.setProperty('--rot',o.rotation+'deg');if(o.type==='gaze'){el.innerHTML=gazeMarkup(o.id)}if(o.type==='aoe'){let g=aoeGeometry(o);el.innerHTML='<svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><path d="'+g.path+'"/></svg>'}if(o.type==='targetcircle'){el.innerHTML=targetCircleMarkup(o);fitTargetCircleSelection(o,el)}if(['stack','linestack'].includes(o.type)){el.innerHTML=o.type==='linestack'?linearStackMarkup(o.id,o.color):stackMarkup(o.id,o.color);fitStackSelection(o,el)}if(['knockback','lineknockback'].includes(o.type)){el.innerHTML=o.type==='lineknockback'?linearKnockbackSvg(o.color,'kb-'+o.id):knockbackSvg(o.color,'kb-'+o.id)}applyShapeStyle(el,o)}
return el;
}

function renderSingle(){normalizeObjectSelection();updateHistoryButtons();normalizePageNames();const previousVisuals=new Map([...layer.children].map(node=>[node.dataset.id,node])),visualNodes=new Set();let visualPosition=0;const placeVisual=node=>{visualNodes.add(node);if(layer.children[visualPosition]!==node)layer.insertBefore(node,layer.children[visualPosition]||null);visualPosition++};controls.innerHTML='';let shape=activeBoardShape(),fieldMax=['image','image4'].includes(shape)?960:640;document.getElementById('fieldWidthRange').max=document.getElementById('fieldWidthSpin').max=document.getElementById('fieldHeightRange').max=document.getElementById('fieldHeightSpin').max=fieldMax;const stageClass='stage field-'+shape+(shape==='image4'?' field-image':'')+(gridVisible?'':' grid-hidden')+(fieldVisible?'':' field-hidden');if(stage.className!==stageClass)stage.className=stageClass;let fieldSize=data.pageFieldSizes[data.page]||{width:538,height:shape==='landscape'?320:538};stage.style.setProperty('--image4-tile-width',fieldSize.width+'px');stage.style.setProperty('--image4-tile-height',fieldSize.height+'px');stage.style.setProperty('--field-width',fieldSize.width/640*100+'%');stage.style.setProperty('--field-height',fieldSize.height/640*100+'%');updateObjectClip();stage.style.setProperty('--field-image',fieldImageSource()?'url('+String.fromCharCode(34)+fieldImageSource()+String.fromCharCode(34)+')':'none');renderImage4Fields();renderFieldImageAppearance();renderFieldGuides();document.getElementById('fieldWidthRange').value=document.getElementById('fieldWidthSpin').value=fieldSize.width;document.getElementById('fieldWidthValue').textContent=fieldSize.width;document.getElementById('fieldHeightRange').value=document.getElementById('fieldHeightSpin').value=fieldSize.height;document.getElementById('fieldHeightValue').textContent=fieldSize.height;$('#boardShapeInput').value=shape;stage.style.backgroundImage='none';stage.style.backgroundColor=activePageColor();let fieldBackground=activeFieldBackground();stage.style.setProperty('--field-bg',fieldBackground);for(const [id,kind,value] of [['layoutColorControl','layout',activePageColor()],['fieldBackgroundControl','fieldBackground',fieldBackground]]){const node=document.getElementById(id),markup=colorPickerMarkup(kind,value);if(node.innerHTML!==markup)node.innerHTML=markup}document.querySelector('#fieldBackgroundControl [data-color-trigger]').disabled=['image','image4'].includes(shape);
let legacyRoleCounts={TankRole:0,HealerRole:0,DPSRole:0};current().forEach((o,objectIndex)=>{if(hasAdditionalOpacity(o)&&!o.additionalOpacityInitialized){o.opacity=100;o.additionalOpacityInitialized=true}if(o.type==='targetcircle'){o.width=integerTargetCircleSize(o.width);o.height=integerTargetCircleSize(o.height)}if(o.type==='icon'&&o.iconName==='中ボス'&&o.src!=='assets/enemies/mid-boss.svg'){o.iconName='大ボス';o.src='assets/enemies/mini-boss.svg'}if(isBossObject(o)&&!o.bossColorInitialized){o.color=bossDefaultColor(o.iconName);o.bossColorInitialized=true}if(o.type==='icon'&&['大ボス','中ボス','小ボス'].includes(o.iconName)&&!o.bossOpacityInitialized){o.opacity=100;o.bossOpacityInitialized=true}if(o.type==='icon'&&o.iconName==='AoE 円範囲'&&!o.aoeOpacityInitialized){o.opacity=100;o.aoeOpacityInitialized=true}if(o.type==='icon'&&['距離減衰','フレア','ロックオン青','ターゲット青','ロックオン赤','ロックオン緑','ロックオン紫','ダイブボム','ターゲット赤','ターゲット紫'].includes(o.iconName)&&o.src==='assets/aoe/flare.png')o.src='assets/aoe/flare.svg';if(['stack','linestack'].includes(o.type)){o.width=integerTargetCircleSize(o.width);o.height=integerTargetCircleSize(o.height)}if(o.visible===false)return;if(o.type==='icon'&&!o.iconBadge&&Object.hasOwn(legacyRoleCounts,o.iconName)){let n=++legacyRoleCounts[o.iconName],max=o.iconName==='DPSRole'?4:2;if(n<=max){o.iconBadge=String(n);o.iconName=(o.iconName==='TankRole'?'タンク':o.iconName==='HealerRole'?'ヒーラー':'DPS')+n}}if(['circle','donut','aoe','line','gaze','segment'].includes(o.type)){o.width=o.width||o.size||(o.type==='line'?100:o.type==='gaze'?48:o.type==='segment'?100:110);o.height=o.height||o.size||(o.type==='line'?200:o.type==='gaze'?31:o.type==='segment'?4:110);o.opacity=Number.isFinite(o.opacity)?o.opacity:50;o.gradient=!!o.gradient;o.fillType=['solid','gradient-down','gradient-up','gradient-right-to-left','gradient-left-to-right','gradient-center-vertical','gradient-center-horizontal','gradient-radial','gradient-vertical-center','gradient-horizontal-center','gradient-radial-in'].includes(o.fillType)?o.fillType:(o.gradient?'gradient-down':'solid');o.gradient=o.fillType.startsWith('gradient');o.rotation=Number(o.rotation)||0}const reusable=!phaseComparisonRendering&&['circle','donut','aoe','line','segment'].includes(o.type),visualKey=reusable?JSON.stringify([o,objectIndex,selectedIds.includes(o.id),selectedIds.length>1,individualGroupSelectionActive(),boardReadOnly,phaseComparisonActive()]):null,previous=previousVisuals.get(o.id),cached=previous?._canvasVisual;
if(reusable&&cached?.owner===data&&cached.page===current()&&cached.object===o&&cached.key===visualKey&&cached.style===previous.getAttribute('style')&&cached.html===previous.innerHTML){placeVisual(previous);updateObjectTileClip(o,previous);renderObjectSelectionControls(o,previous);cached.style=previous.getAttribute('style');cached.html=previous.innerHTML;return}
let el=createCanvasObjectVisual(o,objectIndex);
el.addEventListener('pointerdown',e=>{e.stopPropagation();if(e.button===2)return;if(o.type==='text'&&el.isContentEditable)return;pendingLayerRevealId=o.id;if(e.shiftKey&&o.objectGroupId){selectIndividualGroupMember(o.id,true,true);return}if(!individualGroupSelectionActive()||!selectedIds.includes(o.id))individualGroupSelection=null;if(o.locked){if(e.pointerType==='mouse'&&e.shiftKey){selectedIds=toggleObjectGroup(o.id);selected=selectedIds[selectedIds.length-1]||null}else{selectedIds=[o.id];selected=o.id}renderSelectionOnly();return}if(o.type==='text'&&el.isContentEditable)return;if(e.shiftKey){selectedIds=toggleObjectGroup(o.id);selected=selectedIds[selectedIds.length-1]||null;if(!selectedIds.includes(o.id)){renderSelectionOnly();return}else selected=o.id}else{if(!selectedIds.includes(o.id)||selectedIds.length===1)selectedIds=[o.id];selected=o.id}normalizeObjectSelection();let beforeData=e.ctrlKey?JSON.stringify(data):null,originalIds=selectedIds.slice();if(originalIds.some(id=>current().find(o=>o.id===id)?.locked)){renderSelectionOnly();return}if(e.ctrlKey||e.pointerType==='mouse')originalIds=originalIds.filter(id=>{let item=current().find(source=>source.id===id);return item&&!item.locked});let dragIds=originalIds;if(e.ctrlKey){let copies=originalIds.map(id=>{let source=current().find(item=>item.id===id);let copy=JSON.parse(JSON.stringify(source));copy.id=createObjectId();return copy});remapCopiedObjectGroups(copies);current().push(...copies);dragIds=copies.map(item=>item.id);selectedIds=dragIds;selected=selectedIds[selectedIds.length-1]||null}if(e.pointerType==='touch')stage.setPointerCapture(e.pointerId);drag={mode:'move',pointerId:e.pointerId,pointerType:e.pointerType,ids:dragIds,startX:e.clientX,startY:e.clientY,starts:dragIds.map(id=>{let a=current().find(x=>x.id===id);return{id,x:a.x,y:a.y}}),startX:e.clientX,startY:e.clientY,lastX:e.clientX,lastY:e.clientY,moved:false,ctrlAtStart:e.ctrlKey,ctrlBroken:false,originalIds,beforeData};if(o.type==='text'&&!e.ctrlKey){renderSelectionOnly();if(selectedIds.length===1)showTextControl(o,el);if(e.detail>=2&&(!o.objectGroupId||individualGroupSelectionActive())){drag=null;editText(o,el)}}else{if(e.ctrlKey){render();save()}else renderSelectionOnly()}});el.addEventListener('contextmenu',e=>{if(allowNativeContextMenu(e.target))return;e.preventDefault();e.stopPropagation();openCanvasObjectContextMenu(o.id,e.clientX,e.clientY)});if(o.type==='text')el.addEventListener('dblclick',e=>{e.stopPropagation();if(!o.objectGroupId||individualGroupSelectionActive())editText(o,el)});placeVisual(el);updateObjectTileClip(o,el);renderObjectSelectionControls(o,el);if(reusable)el._canvasVisual={owner:data,page:current(),object:o,key:visualKey,style:el.getAttribute('style'),html:el.innerHTML}});for(const node of [...layer.children])if(!visualNodes.has(node))node.remove();renderObjectGroupControls();if(phaseComparisonRendering)return;renderPages();if(!window.Bolxiv?.pngPreview?.active){renderObjectList();renderInspector()}if($('#toggleInspector').getAttribute('aria-expanded')==='false'){let panel=$('#propertyPanel');panel.hidden=true;panel.style.display='none';panel.classList.add('hidden')}else{let panel=$('#propertyPanel');panel.hidden=false;panel.style.display='flex';panel.classList.remove('hidden')}{const items=committedLayerObjects(),total=items.length,hidden=items.filter(item=>item.visible===false).length,locked=items.filter(item=>item.locked).length;const heading=$('#toggleLayers');heading.firstElementChild.textContent='オブジェクトリスト';$('#count').textContent=' T'+String(total).padStart(2,'0')+' / H'+String(hidden).padStart(2,'0')+' / L'+String(locked).padStart(2,'0');heading.title=(!heading.disabled&&!document.querySelector('.layout').classList.contains('desktop-tools-two-columns')?'オブジェクトリストを開閉\n':'')+'総数：'+total+'\n非表示：'+hidden+'\nロック：'+locked;heading.setAttribute('aria-label','オブジェクトリスト、総数'+total+'、非表示'+hidden+'、ロック'+locked);}updateContentSelector()}

function objectTypeTitle(o){if(o.type==='icon'){let src=String(o.src||'');if(o.iconName==='大ボス'||o.iconName==='中ボス'||o.iconName==='小ボス')return o.iconName;if(src.includes('target-marker'))return 'ターゲットマーカー';if(src.includes('field-marker'))return 'フィールドマーカー';return 'ロール/ジョブ'}return o.type==='gaze'?'視線':o.type==='targetcircle'?'ターゲットサークル':o.type==='linestack'?'直線頭割り':o.type==='stack'?'頭割り':o.type==='knockback'?'円ノックバック':o.type==='lineknockback'?'直線ノックバック':o.type==='segment'?'線':'配置ツール'}

function showTextControl(o,el){controls.replaceChildren();renderObjectSelectionControls(o,el);renderObjectGroupControls()}

function editText(o,el){if(boardReadOnly)return;if(phaseComparisonActive())return;if(el.isContentEditable||o.locked)return;el.contentEditable='true';el.style.whiteSpace='pre-wrap';el.style.textAlign='left';el.focus();let range=document.createRange();range.selectNodeContents(el);let selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);el.onkeydown=e=>{if(e.isComposing||e.keyCode===229)return;if(e.key==='Escape'){e.preventDefault();el.textContent=o.label||'メモ';el.blur()}};el.onblur=()=>{let value=el.innerText.replace(/\\r/g,'').replace(/\\n$/,'');if(value!==(o.label||'メモ')){recordHistory();o.label=value;renderAndSave()}else{el.contentEditable='false';el.onkeydown=null;el.onblur=null}}}

function objectTitle(o){if(o.type==='image')return '画像';if(o.type==='segment')return ['start','end','both'].includes(o.arrowEnds)?'矢印':'線';if(o.type==='icon')return ({'ターゲット赤':'ロックオン赤','ターゲット紫':'ロックオン紫','ダイブボム':'ロックオン青','ターゲット青':'ロックオン青'})[o.iconName]||o.iconName||'アイコン';let paletteItem=document.querySelector('.left .tool[data-tool="'+CSS.escape(o.type)+'"]');if(paletteItem?.title)return paletteItem.title;return {text:'テキスト',segment:'線',circle:'円範囲',donut:'ドーナツ範囲',aoe:'扇範囲',line:'直線範囲',gaze:'視線',targetcircle:'ターゲットサークル',stack:'頭割り',linestack:'直線頭割り',knockback:'円ノックバック',lineknockback:'直線ノックバック',marker:'プレイヤー'}[o.type]||o.type}

function objectCategory(o){if(o.type==='targetcircle')return 'エネミー';if(o.type==='text'||o.type==='segment'||o.type==='image')return 'ツール';if(['circle','donut','aoe','line','gaze','stack','linestack','knockback','lineknockback'].includes(o.type))return 'AoE';if(o.type==='icon'){let src=String(o.src||'');if(src.includes('assets/aoe/'))return 'AoE';if(src.includes('assets/enemies/'))return 'エネミー';if(src.includes('target-marker'))return 'ターゲットマーカー';if(src.includes('field-marker'))return 'フィールドマーカー';return 'ロール/ジョブ'}if(o.type==='marker')return 'ロール/ジョブ';return objectTitle(o)}

function openCanvasObjectContextMenu(id,x,y){
 const changed=!selectedIds.includes(id);if(changed){selected=id;selectedIds=[id]}
 openObjectContextMenu(id,x,y);
 if(changed){const revision=++selectionPanelsRevision,board=data,ids=selectedIds.join('|');requestAnimationFrame(()=>requestAnimationFrame(()=>{if(revision!==selectionPanelsRevision||data!==board||selectedIds.join('|')!==ids)return;renderSelectionOnly()}))}
}
function openObjectContextMenu(id,x,y,opener=null){let menu=$('#objectContextMenu'),item=current().find(o=>o.id===id);if(!item)return;menu._opener=opener;menu._openerResolver=opener?()=>document.querySelector('#objectList .object-row[data-id="'+id+'"] .phone-row-actions'):null;if(!selectedIds.includes(id)){selected=id;selectedIds=[id]}normalizeObjectSelection();const groupMenu=document.getElementById('contextGroupMenu'),groupToggle=document.getElementById('contextGroupMenuToggle'),register=document.getElementById('contextRegisterPreset');if(groupMenu)groupMenu.hidden=true;if(groupToggle)groupToggle.setAttribute('aria-expanded','false');if(register){register.hidden=selectedIds.length<2;register.disabled=selectionHasImportedImages()||boardReadOnly||phaseComparisonActive()||!!window.Bolxiv?.pngPreview?.active||selectedIds.length<2}menu.dataset.id=id;menu.dataset.ids=JSON.stringify(selectedIds);syncObjectGroupMenu();document.getElementById('contextPaste').disabled=boardReadOnly||phaseComparisonActive()||!clipboardObjects.length;let items=current().filter(o=>selectedIds.includes(o.id)),sameType=items.every(o=>o.type===item.type);for(let [id,key,on,labelOn,labelOff] of [['contextVisibility','visible',items.every(o=>o.visible!==false),'表示にする','非表示にする'],['contextEditable','locked',items.every(o=>!o.locked),'編集可にする','編集不可にする']]){let button=$('#'+id);button.disabled=key!=='locked'&&!sameType&&!selectedObjectGroup().length;button.textContent=on?labelOff:labelOn;button.dataset.key=key;button.dataset.value=String(key==='locked'?on:!on)}$('#contextDelete').hidden=selectedObjectGroup().length>0;$('#contextDelete').disabled=!selectedIds.some(selectedId=>!current().find(o=>o.id===selectedId)?.locked);$("#contextSwapPosition").disabled=boardReadOnly||phaseComparisonActive()||selectedIds.length!==2||items.some(o=>o.locked);addPhoneMenuClose(menu,closeObjectContextMenu);menu.hidden=false;let width=menu.offsetWidth,height=menu.offsetHeight;menu.style.left=Math.max(4,Math.min(x,innerWidth-width-4))+'px';menu.style.top=Math.max(4,Math.min(y,innerHeight-height-4))+'px'}

function closeObjectContextMenu(){const groupMenu=document.getElementById('contextGroupMenu');if(groupMenu)groupMenu.hidden=true;document.getElementById('contextGroupMenuToggle')?.setAttribute('aria-expanded','false');let menu=$('#objectContextMenu');if(menu)menu.hidden=true;let layerMenu=$('#layerContextMenu');if(layerMenu)layerMenu.hidden=true}

function removeObject(id,individual=false){if(boardReadOnly||phaseComparisonActive())return;const ids=individual?[id]:objectGroupIds(id);if(current().some(o=>ids.includes(o.id)&&o.locked))return;recordHistory();data.pages[data.page]=current().filter(o=>!ids.includes(o.id));selectedIds=selectedIds.filter(x=>!ids.includes(x));selected=selectedIds[selectedIds.length-1]||null;renderAndSave()}

function layerObjectIcon(o){if(o.type==='icon')return isBossObject(o)?bossIconSource(o):isTowerObject(o)?towerIconSource(o):objectImageSource(o);const svg=document.querySelector('.left .tool[data-tool="'+o.type+'"] .glyph svg');let markup;if(svg){markup=svg.outerHTML;if(!markup.includes('xmlns='))markup=markup.replace('<svg','<svg xmlns="http://www.w3.org/2000/svg"')}else{const body=o.type==='text'?'<path d="M5 5H19M12 5V20" fill="none" stroke="#293c66" stroke-width="3"/>':o.type==='segment'?'<path d="M3 12H21" stroke="#293c66" stroke-width="3"/>':o.type==='marker'?'<circle cx="12" cy="12" r="9" fill="#ffb341" stroke="#293c66" stroke-width="2"/>':'<rect x="4" y="4" width="16" height="16" rx="3" fill="none" stroke="#293c66" stroke-width="2"/>';markup='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">'+body+'</svg>'}return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(markup)}

function committedLayerObjects(){const provisional=drag?.mode==='move'&&drag.ctrlAtStart?new Set(drag.ids):null;return provisional?current().filter(o=>!provisional.has(o.id)):current()}

function updateObjectGroupFrames(){
 const updates=[],heights=new Map();
 for(const row of document.querySelectorAll('#objectList .object-group-row')){const height=row.offsetHeight;heights.set(row,height);updates.push([row,'--object-group-header-height',height+'px'])}
 for(const row of document.querySelectorAll('#objectList .object-group-expanded')){
  let last=row,next=row.nextElementSibling;while(next?.classList.contains('object-group-member')){if(!next.hidden)last=next;next=next.nextElementSibling}
  const bounds=row.getBoundingClientRect(),scale=bounds.height/(heights.get(row)||1);if(scale>0)updates.push([row,'--object-group-frame-height',((last.getBoundingClientRect().bottom-bounds.top)/scale)+'px']);
 }
 for(const [row,key,value] of updates)if(row.style.getPropertyValue(key)!==value)row.style.setProperty(key,value);
}

function revealCanvasSelectionRow(id,list){
 if(!list.clientHeight)return;const group=selectedObjectGroup(),single=selectedIds.length===1&&selectedIds[0]===id;
 if(!single&&!group.some(o=>o.id===id)&&!(individualGroupSelectionActive()&&selectedIds.includes(id)))return;
 const rows=[...list.children],row=group.length?rows.find(node=>node.classList.contains('object-group-row')&&node.dataset.objectGroupId===group[0].objectGroupId):rows.find(node=>node.dataset.id===id&&(!individualGroupSelectionActive()||node.classList.contains('object-group-member')));
 if(!row||row.hidden)return;const bounds=list.getBoundingClientRect(),rect=row.getBoundingClientRect(),top=bounds.top+list.clientTop,bottom=top+list.clientHeight;
 if(rect.top<top)list.scrollTop+=rect.top-top;else if(rect.bottom>bottom)list.scrollTop+=rect.bottom-bottom;
}

function revealPendingObjectListRow(box){if(pendingLayerRevealId){const id=pendingLayerRevealId;pendingLayerRevealId=null;requestAnimationFrame(()=>revealCanvasSelectionRow(id,box))}}
function renderObjectList(){
 const box=document.getElementById('objectList'),scroll=box.scrollTop;
 const flatItems=committedLayerObjects(),flatKey=!data.activePhaseGroup&&!flatItems.some(o=>o.objectGroupId)?JSON.stringify([boardReadOnly,phaseComparisonActive(),flatItems.map(o=>[o.id,o.type,o.iconName,o.src,o.imageId,o.color,o.visible,o.locked,o.arrowEnds])]):null,cached=box._flatListCache;
 if(flatKey&&cached?.owner===data&&cached.page===current()&&cached.key===flatKey&&box.children.length===cached.rows.length&&cached.rows.every((row,i)=>box.children[i]===row)){
  for(const o of flatItems)cached.byId.get(o.id)?._refreshObject(o);
  const picked=new Set(selectedIds);for(const id of new Set([...cached.picked,...picked]))if(cached.picked.has(id)!==picked.has(id)){const row=cached.byId.get(id);if(row){row.classList.toggle('selected',picked.has(id));row.querySelector('.object-select-check').checked=picked.has(id)}}cached.picked=picked;revealPendingObjectListRow(box);return;
 }
 box._flatListCache=null;
 // Commit an inline group name before removing its row. Its blur handler may
 // render the list again, so taking the row snapshot first can remove it twice.
 if(box.contains(document.activeElement)&&document.activeElement.matches('.object-group-name-input'))document.activeElement.blur();
 if(data.activePhaseGroup){box.replaceChildren();return}
 if(!box._expandedObjectGroups)box._expandedObjectGroups=new Set();
 // Keep ordinary member nodes stable for property edits and selection updates.
 for(const row of [...box.querySelectorAll('.object-group-row')])row.remove();
 for(const row of box.querySelectorAll('.object-group-member'))row.hidden=false;
 renderFlatObjectList(false);
 const blocks=objectLayerBlocks(committedLayerObjects().slice().reverse()),rows=new Map([...box.children].map(row=>[row.dataset.id,row]));
 if(!blocks.some(items=>items[0].objectGroupId)){if(flatKey&&flatItems.length){const rows=[...box.children];box._flatListCache={owner:data,page:current(),key:flatKey,rows,byId:new Map(rows.map(row=>[row.dataset.id,row])),picked:new Set(selectedIds)}}box.scrollTop=scroll;return;}
 const fragment=document.createDocumentFragment(),individual=individualGroupSelectionActive(),selectedSet=new Set(selectedIds);let objectNumber=0;
 blocks.forEach((items,index)=>{
  const start=objectNumber+1;objectNumber+=items.length;const number=value=>String(value).padStart(2,'0');const item=items[0],source=rows.get(item.id);if(!source)return;
  if(!item.objectGroupId){source.querySelector('.object-index').textContent=number(start);fragment.append(source);return}
  const groupId=item.objectGroupId,expanded=box._expandedObjectGroups.has(groupId),ids=items.map(o=>o.id),name=objectGroupName(items),row=source.cloneNode(true);
  row.className='object-row object-group-row'+(expanded?' object-group-expanded':'')+(ids.every(id=>selectedIds.includes(id))?' selected':'');row.dataset.id=item.id;row.dataset.objectGroupId=groupId;row.draggable=!boardReadOnly&&!phaseComparisonActive();row.hidden=false;row.removeAttribute('aria-hidden');
  row.querySelectorAll('.phone-row-actions,.group-member-status').forEach(n=>n.remove());for(const control of row.querySelectorAll('button,input'))control.disabled=false;
  const label=row.querySelector('.object-name');label.hidden=false;label.replaceChildren();const text=document.createElement('span');text.textContent=name;label.append(text);label.title=name+'：クリックで全体を選択、メニューから名前変更';
  const symbol=document.createElement('span');symbol.className='object-group-symbol';symbol.setAttribute('aria-hidden','true');symbol.innerHTML='<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><rect x="2" y="2" width="11" height="11" rx="1.5"/><rect x="7" y="7" width="11" height="11" rx="1.5" fill="#f0f4fa"/></svg>';row.insertBefore(symbol,label);
  function select(extend=false){individualGroupSelection=null;selectedIds=extend?toggleObjectGroup(item.id):ids.slice();selected=selectedIds.includes(item.id)?item.id:selectedIds.at(-1)||null;renderSelectionOnly()}
  label.onclick=e=>selectObjectListItem(item.id,e);
  row.title=name+'：行をドラッグしてグループ全体のレイヤー順を変更';row.querySelector('.object-index').textContent='';
  const disclosure=document.createElement('button');disclosure.type='button';disclosure.className='object-group-disclosure';disclosure.innerHTML='<span class="group-disclosure-text">'+(expanded?'▾':'▸')+'</span><svg class="group-disclosure-arrow" viewBox="0 0 18 18" aria-hidden="true"><path d="'+(expanded?'M3 6h12l-6 7Z':'M6 3v12l7-6Z')+'"/></svg>';disclosure.setAttribute('aria-label',name+(expanded?'を折りたたむ':'を展開'));disclosure.setAttribute('aria-expanded',String(expanded));disclosure.title='クリック／タップで開閉、ドラッグ／長押しでグループ全体を並べ替え';disclosure.onclick=e=>{e.stopPropagation();if(expanded)box._expandedObjectGroups.delete(groupId);else box._expandedObjectGroups.add(groupId);renderObjectList()};row.insertBefore(disclosure,label);
  const check=row.querySelector('.object-select-check');check.checked=ids.every(id=>selectedIds.includes(id));check.indeterminate=!check.checked&&ids.some(id=>selectedIds.includes(id));check.disabled=phaseComparisonActive();check.setAttribute('aria-label',name+'全体を選択');check.onclick=e=>e.stopPropagation();check.onchange=()=>{individualGroupSelection=null;const picked=new Set(selectedIds);for(const id of ids){if(check.checked)picked.add(id);else picked.delete(id)}selectedIds=[...picked];selected=selectedIds.at(-1)||null;renderSelectionOnly()};
  const editing=row.querySelector('.object-lock-toggle');editing.title='グループ全体を'+(items.some(o=>o.locked)?'編集可にする':'編集不可にする');editing.setAttribute('aria-label',editing.title);editing.disabled=boardReadOnly||phaseComparisonActive();editing.onclick=e=>{e.stopPropagation();setObjectState(ids,'locked',!items.some(o=>o.locked))};
  const visibility=row.querySelector('.object-visibility-toggle');visibility.title='グループ全体を'+(items.every(o=>o.visible!==false)?'非表示にする':'表示する');visibility.setAttribute('aria-label',visibility.title);visibility.disabled=boardReadOnly||phaseComparisonActive();visibility.onclick=e=>{e.stopPropagation();if(boardReadOnly||phaseComparisonActive())return;recordHistory();const visible=!items.every(o=>o.visible!==false);for(const member of items)member.visible=visible;renderAndSave()};
  syncGroupStateButton(editing,items.map(o=>!o.locked),'編集可否');syncGroupStateButton(visibility,items.map(o=>o.visible!==false),'表示状態');const del=row.querySelector('.object-delete');del.disabled=boardReadOnly||phaseComparisonActive();del.title='グループ解除（オブジェクトは残します）';del.setAttribute('aria-label',name+'のグループ解除（オブジェクトは残します）');del.onclick=e=>{e.stopPropagation();ungroupObjectGroup(groupId)};
  row.oncontextmenu=e=>{if(allowNativeContextMenu(e.target))return;e.preventDefault();e.stopPropagation();if(!selectedIds.includes(item.id))select();openObjectContextMenu(item.id,e.clientX,e.clientY)};
  row.ondragstart=e=>{if(boardReadOnly||phaseComparisonActive()){e.preventDefault();return}e.dataTransfer.setData('application/x-tactica-layer',item.id);e.dataTransfer.effectAllowed='move'};
  row.ondragover=e=>{if(!Array.from(e.dataTransfer.types).includes('application/x-tactica-layer'))return;e.preventDefault();const after=e.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;row.classList.add('drag-over');row.classList.toggle('drop-after',after);row.classList.toggle('drop-before',!after)};
  row.ondragleave=()=>row.classList.remove('drag-over','drop-before','drop-after');
  row.ondrop=e=>{if(!Array.from(e.dataTransfer.types).includes('application/x-tactica-layer'))return;e.preventDefault();row.classList.remove('drag-over','drop-before','drop-after');moveObjectLayerBlock(e.dataTransfer.getData('application/x-tactica-layer'),item.id,e.clientY>row.getBoundingClientRect().top+row.offsetHeight/2)};
  fragment.append(row);
  for(const member of items){const child=rows.get(member.id);if(!child)continue;child.classList.add('object-group-member');child.classList.toggle('object-group-member-last',member===items[items.length-1]);child.classList.toggle('selected',individual&&selectedSet.has(member.id));child.hidden=!expanded;child.draggable=false;child.ondragstart=e=>e.preventDefault();child.ondragover=null;child.ondrop=null;child.querySelector('.object-index').textContent=number(start+items.indexOf(member));child.title=objectTitle(member)+'\n所属グループ：'+name+'\nクリック／タップでこのオブジェクトを個別編集';const memberName=child.querySelector('.object-name');memberName.title=child.title;for(const control of child.querySelectorAll('button,input'))control.disabled=true;memberName.disabled=phaseComparisonActive();memberName.onclick=e=>{e.stopPropagation();if(phaseComparisonActive())return;selectObjectListItem(member.id,e,true)};const memberCheck=child.querySelector('.object-select-check');memberCheck.disabled=phaseComparisonActive();memberCheck.checked=individual&&selectedSet.has(member.id);memberCheck.onchange=e=>{e.stopPropagation();selectIndividualGroupMember(member.id,true)};child.oncontextmenu=e=>{if(allowNativeContextMenu(e.target))return;e.preventDefault();e.stopPropagation();if(!individualGroupSelectionActive()||!selectedIds.includes(member.id))selectIndividualGroupMember(member.id);openObjectContextMenu(member.id,e.clientX,e.clientY)};const memberLock=child.querySelector('.object-lock-toggle'),memberVisibility=child.querySelector('.object-visibility-toggle');for(const button of [memberLock,memberVisibility])button.disabled=boardReadOnly||phaseComparisonActive();memberLock.title=member.locked?'このオブジェクトを編集可にする':'このオブジェクトを編集不可にする';memberLock.setAttribute('aria-label',memberLock.title);memberLock.onclick=e=>{e.stopPropagation();setObjectState([member.id],'locked',!member.locked)};memberVisibility.title=member.visible===false?'このオブジェクトを表示する':'このオブジェクトを非表示にする';memberVisibility.setAttribute('aria-label',memberVisibility.title);memberVisibility.onclick=e=>{e.stopPropagation();setObjectState([member.id],'visible',member.visible===false)};const memberDelete=child.querySelector('.object-delete');memberDelete.disabled=boardReadOnly||phaseComparisonActive()||!!member.locked;memberDelete.title='このオブジェクトを削除';memberDelete.setAttribute('aria-label',objectTitle(member)+'を削除');memberDelete.onclick=e=>{e.stopPropagation();if(matchMedia('(max-width:850px)').matches)confirmPhoneLayerDeletion(member.id,true);else removeObject(member.id,true)};bindGroupMemberReorder(child,member);fragment.append(child)}
 });
 if(blocks.length)box.append(fragment);box.scrollTop=scroll;
 requestAnimationFrame(updateObjectGroupFrames);
 if(!box._objectGroupFrameObserver){box._objectGroupFrameObserver=new ResizeObserver(()=>requestAnimationFrame(updateObjectGroupFrames));box._objectGroupFrameObserver.observe(box)}
}

function renderFlatObjectList(preserveScroll=true){const box=$('#objectList');let previousScrollTop=null;const rememberScroll=()=>{if(preserveScroll&&previousScrollTop===null)previousScrollTop=box.scrollTop};box.style.padding='0';box.style.borderRadius='7px';let ordered=committedLayerObjects().slice().reverse();const existing=new Map([...box.children].filter(row=>row.classList.contains('object-row')).map(row=>[row.dataset.id,row]));const ids=new Set(ordered.map(o=>o.id));for(const child of [...box.children]){if(!ids.has(child.dataset.id)){rememberScroll();child.remove()}}if(!ordered.length){box.innerHTML='<div class="object-empty">配置したオブジェクトはありません</div>';return}ordered.forEach((o,i)=>{
 const signature=JSON.stringify([objectTitle(o),o.type,o.iconName,o.src,o.imageId,o.color,o.visible,o.locked,o.objectGroupId]);
 const previous=existing.get(o.id);
 if(previous&&previous._objectRowSignature===signature){
  previous._refreshObject(o);previous.classList.toggle('selected',selectedIds.includes(o.id));
  const check=previous.querySelector('.object-select-check');check.checked=selectedIds.includes(o.id);check.disabled=phaseComparisonActive();
  previous.querySelector('.object-index').textContent=String(i+1).padStart(2,'0');
  if(box.children[i]!==previous){rememberScroll();box.insertBefore(previous,box.children[i]||null)}
  return;
 }
 let row=document.createElement('div');row._objectRowSignature=signature;row._refreshObject=next=>{o=next};row.className='object-row'+(selectedIds.includes(o.id)?' selected':'');row.draggable=true;row.dataset.id=o.id;let name=document.createElement('button');name.className='object-name';name.title=objectTitle(o)+'\nクリックで選択、Shift＋クリックで範囲選択、Ctrl＋クリックで追加・解除\n左ボタンでドラッグして並べ替え、右クリックで操作メニューを開く';row.title=name.title;let index=document.createElement('span');index.className='object-index';index.textContent=String(i+1).padStart(2,'0');{let img=document.createElement('img');img.className='object-name-icon';img.src=layerObjectIcon(o);img.alt='';name.appendChild(img)}let nameLabel=document.createElement('span');nameLabel.textContent=objectTitle(o);name.appendChild(nameLabel);name.onclick=e=>selectObjectListItem(o.id,e);row.oncontextmenu=e=>{if(allowNativeContextMenu(e.target))return;e.preventDefault();e.stopPropagation();openCanvasObjectContextMenu(o.id,e.clientX,e.clientY)};let del=document.createElement('button');del.className='object-delete';del.type='button';del.textContent='×';del.title='このオブジェクトを削除';del.disabled=!!o.locked;del.onclick=e=>{e.stopPropagation();if(matchMedia('(max-width:850px)').matches)confirmPhoneLayerDeletion(o.id);else removeObject(o.id)};let visibility=document.createElement('button');visibility.type='button';visibility.className='object-toggle object-visibility-toggle'+(o.visible===false?'':' active');visibility.innerHTML=o.visible===false?'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18M10.6 10.6a2 2 0 002.8 2.8M9.9 5.2A10.8 10.8 0 0112 5c6.5 0 10 7 10 7a13.7 13.7 0 01-3.2 3.9M6.2 6.2C3.5 8 2 12 2 12s3.5 7 10 7a10 10 0 004-.8"/></svg>':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';visibility.title=o.visible===false?'非表示中：クリックで表示する':'表示中：クリックで非表示にする';visibility.setAttribute('aria-label',visibility.title);visibility.setAttribute('aria-pressed',String(o.visible!==false));visibility.onclick=e=>{e.stopPropagation();recordHistory();o.visible=o.visible===false;renderAndSave()};let editing=document.createElement('button');editing.type='button';editing.className='object-toggle object-lock-toggle'+(o.locked?'':' active');editing.innerHTML=o.locked?'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/></svg>':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L8 18l-4 1 1-4Z"/></svg>';editing.title=o.locked?'編集不可：クリックで編集可にする':'編集可：クリックで編集不可にする';if(o.objectGroupId)editing.title='グループ全体：'+editing.title;editing.setAttribute('aria-label',editing.title);editing.setAttribute('aria-pressed',String(!o.locked));editing.onclick=e=>{e.stopPropagation();setObjectState([o.id],'locked',!o.locked)};let check=document.createElement('input');check.type='checkbox';check.className='object-select-check';check.checked=selectedIds.includes(o.id);check.disabled=phaseComparisonActive();check.setAttribute('aria-label',objectTitle(o)+'を選択');check.onclick=e=>e.stopPropagation();check.onchange=e=>{e.stopPropagation();if(phaseComparisonActive())return;if(check.checked){if(!selectedIds.includes(o.id))selectedIds=[...selectedIds,o.id];selected=o.id}else{selectedIds=selectedIds.filter(id=>!objectGroupIds(o.id).includes(id));if(selected===o.id)selected=selectedIds[selectedIds.length-1]||null}renderSelectionOnly()};row.append(index,check,visibility,editing,name,del);row.ondragstart=e=>{e.dataTransfer.setData('application/x-tactica-layer',o.id);e.dataTransfer.effectAllowed='move'};row.ondragover=e=>{if(!Array.from(e.dataTransfer.types).includes('application/x-tactica-layer')){row.classList.remove('drag-over','drop-before','drop-after');return}e.preventDefault();let after=e.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;row.classList.add('drag-over');row.classList.toggle('drop-after',after);row.classList.toggle('drop-before',!after);e.dataTransfer.dropEffect='move'};row.ondragleave=()=>row.classList.remove('drag-over','drop-before','drop-after');row.ondrop=e=>{if(!Array.from(e.dataTransfer.types).includes('application/x-tactica-layer')){row.classList.remove('drag-over','drop-before','drop-after');return}e.preventDefault();row.classList.remove('drag-over','drop-before','drop-after');let from=e.dataTransfer.getData('application/x-tactica-layer'),to=o.id;if(!from||from===to)return;moveObjectLayerBlock(from,to,e.clientY>row.getBoundingClientRect().top+row.offsetHeight/2)};rememberScroll();if(previous?.isConnected)previous.replaceWith(row);if(box.children[i]!==row)box.insertBefore(row,box.children[i]||null)});if(previousScrollTop!==null)box.scrollTop=previousScrollTop;revealPendingObjectListRow(box)}

function updateSelectionLabel(){
 const currentLabel=document.getElementById('selectionTitle'),caption='フェーズ：'+(data.pageNames[data.page]||'')+'（'+(data.title||'Untitled Strategy')+'）';if(currentLabel.textContent===caption&&currentLabel.querySelector('.selection-content-context'))return;
 const label=currentLabel,prefix=document.createElement('span'),phaseName=document.createElement('span'),context=document.createElement('span'),contentName=document.createElement('span');
 prefix.className='phase-label-prefix';prefix.textContent='フェーズ：';
 phaseName.className='selection-phase-name';phaseName.textContent=data.pageNames[data.page]||'';phaseName.title=phaseName.textContent;
 context.className='selection-content-context';contentName.className='selection-content-name';contentName.textContent=data.title||'Untitled Strategy';contentName.title=contentName.textContent;
 const opening=document.createElement('span'),closing=document.createElement('span');opening.textContent='（';closing.textContent='）';context.append(opening,contentName,closing);
 label.replaceChildren(prefix,phaseName,context);label.title=label.textContent;
}

function fieldImageTint(board,index){const value=board.pageFieldImageTints?.[index];return {color:/^#[0-9a-f]{6}$/i.test(value?.color)?value.color:"#000000",strength:typeof value?.strength==="number"&&Number.isFinite(value.strength)?Math.max(0,Math.min(100,value.strength)):0}}

function colorMix(hex,ratio,toward){let a=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)),b=[1,3,5].map(i=>parseInt(toward.slice(i,i+2),16));return '#'+a.map((v,i)=>Math.round(v*(1-ratio)+b[i]*ratio).toString(16).padStart(2,'0')).join('')}

function colorSwatchRow(colors){return `<div class="color-grid">${colors.map(c=>`<button type="button" class="color-swatch" data-color-value="${c}" title="${c}" aria-label="${c}" style="background-color:${c}"></button>`).join('')}</div>`}

function colorPaletteContents(){let shades=[.82,.64,.42].map(r=>colorSwatchRow(themeColors.map(c=>colorMix(c,r,'#FFFFFF')))).join('')+colorSwatchRow(themeColors.map(c=>colorMix(c,.25,'#000000')));return `<button type="button" class="color-custom-trigger"><span class="color-preview" aria-hidden="true"></span>任意の色を選択</button><div class="color-palette-title">テーマの色</div>${colorSwatchRow(themeColors)}${shades}<div class="color-palette-title">標準の色</div>${colorSwatchRow(standardColors)}`}

function colorPaletteMarkup(){return '<div class="color-popover" hidden></div>'}

function colorPickerMarkup(kind,value,id=""){let valueMarkup=`<span>${value}</span>`;return `<div class="color-picker" data-color-kind="${kind}" data-object-id="${id}"><button type="button" class="color-trigger" data-color-trigger aria-label="色を選択"><span class="color-preview" style="background-color:${value}"></span>${valueMarkup}</button><input type="color" class="native-color-picker" value="${value}" aria-label="任意の色を選択" title="任意の色を選択">${colorPaletteMarkup()}</div>`}

function closeColorPopovers(){document.querySelectorAll('.color-popover:not([hidden])').forEach(pop=>{pop.hidden=true;if(pop._colorPicker?.isConnected)pop._colorPicker.appendChild(pop);pop._colorPicker=null})}

// One disclosure projection for headers and bodies. Layout-specific sizing stays outside.
const panelScrollPositions=new WeakMap();
function setPanelExpanded(heading,body,expanded,{display='flex',manageDisplay=true,hiddenClass=true,scroll=body,frame=null,collapsedClass=null}={}){
 const open=!!expanded,wasOpen=heading.getAttribute('aria-expanded')==='true';
 if(wasOpen&&!open&&scroll)panelScrollPositions.set(body,{node:scroll,left:scroll.scrollLeft,top:scroll.scrollTop});
 if(frame&&collapsedClass)frame.classList.toggle(collapsedClass,!open);
 heading.setAttribute('aria-expanded',String(open));body.hidden=!open;
 if(hiddenClass)body.classList.toggle('hidden',!open);
 if(manageDisplay)body.style.display=open?display:'none';
 if(!wasOpen&&open){const saved=panelScrollPositions.get(body);if(saved&&body.contains(saved.node)){saved.node.scrollLeft=saved.left;saved.node.scrollTop=saved.top}}
}
// Shared phase/field list row structure; domain actions are bound by the caller.
function createPhaseListRow({name,number,active=false,selected=false}){
 const row=document.createElement('div');row.className='page-tab'+(active?' active':'')+(selected?' selected':'');row.setAttribute('role','button');row.tabIndex=0;
 const index=document.createElement('span');index.className='page-index';index.textContent=String(number).padStart(2,'0');
 const label=document.createElement('span');label.className='page-tab-name';label.textContent=name;
 const action=document.createElement('button');action.type='button';action.className='page-tab-x';action.textContent='×';row.append(index,label,action);return {row,index,label,action};
}

// List views receive commands from their domain adapters; they never mutate saved data.
function bindPropertyTextCommit(input,{onCommit,restoreOnEscape=null}){
 let committed=input.value;
 const focus=()=>{committed=input.value},change=event=>{if(input.value===committed)return;onCommit?.(input.value,event);committed=input.value},keydown=event=>{if(event.isComposing||event.keyCode===229)return;if(event.key==='Enter'){event.preventDefault();event.stopPropagation();input.dispatchEvent(new Event('change',{bubbles:true}))}else if(event.key==='Escape'){event.preventDefault();event.stopPropagation();input.value=restoreOnEscape?restoreOnEscape():committed;committed=input.value;input.blur()}};
 input.addEventListener('focus',focus);input.addEventListener('change',change);input.addEventListener('keydown',keydown);
 return ()=>{input.removeEventListener('focus',focus);input.removeEventListener('change',change);input.removeEventListener('keydown',keydown)};
}
function createPropertyTextField({id,label:caption,className='field',describedBy=null,value,maxLength,readOnly=false,disabled=false,onCommit,restoreOnEscape=null}){
 const field=document.createElement('div');field.className=className;const label=document.createElement('label');label.htmlFor=id;label.textContent=caption;const input=document.createElement('input');input.id=id;input.type='text';if(describedBy)input.setAttribute('aria-describedby',describedBy);if(value!==undefined)input.value=value;if(maxLength!==undefined)input.maxLength=maxLength;input.readOnly=readOnly;input.disabled=disabled;const dispose=bindPropertyTextCommit(input,{onCommit,restoreOnEscape});field.append(label,input);return {field,label,input,dispose};
}
// Render structure only. Limits, conversions, history and persistence belong to each adapter.
function propertyNumberFieldMarkup({label,rangeId,numberId,valueId,value,unit='',min,max,step=1,className='field',linkLabel=false,valueTag='span',rangeLabel=label,numberLabel=label}){
 const attr=(name,v)=>v===undefined?'':' '+name+'="'+esc(v)+'"',tag=valueTag==='output'?'output':'span',limits=attr('min',min)+attr('max',max)+attr('step',step)+attr('value',value);
 return '<div class="'+esc(className)+'"><label'+(linkLabel?attr('for',rangeId):'')+'>'+esc(label)+'：<'+tag+attr('id',valueId)+'>'+(value===undefined?'':esc(value))+'</'+tag+'>'+esc(unit)+'</label><div class="coordinate-control"><input'+attr('id',rangeId)+' type="range"'+limits+attr('aria-label',rangeLabel)+'><input'+attr('id',numberId)+' type="number"'+limits+attr('aria-label',numberLabel)+'></div></div>';
}
function createPropertyNumberField(options){
 const template=document.createElement('template');template.innerHTML=propertyNumberFieldMarkup(options);const field=template.content.firstElementChild;return {field,label:field.querySelector('label'),value:field.querySelector('label>:is(span,output)'),range:field.querySelector('[type=range]'),number:field.querySelector('[type=number]')};
}
function bindPropertyEditSession(inputs,{onInput,onFinish,onCancel=onFinish,keyboard=false}){
 const bindings=[],bind=(input,type,listener)=>{input.addEventListener(type,listener);bindings.push(()=>input.removeEventListener(type,listener))};
 for(const input of inputs){bind(input,'input',event=>onInput(input,event));for(const type of ['change','blur'])bind(input,type,()=>onFinish());bind(input,'pointercancel',()=>onCancel());if(keyboard)bind(input,'keydown',event=>{if(event.isComposing)return;if(event.key==='Escape'){event.preventDefault();event.stopPropagation();onCancel()}else if(event.key==='Enter'){event.preventDefault();onFinish()}})}
 return ()=>bindings.forEach(dispose=>dispose());
}
function createMenuAction({label,disabled=false,destructive=false,shortcut=null,onInvoke}){
 const button=document.createElement('button');button.type='button';button.textContent=label;button.setAttribute('role','menuitem');button.disabled=disabled;if(destructive)button.classList.add('context-delete');if(shortcut)button.dataset.shortcut=shortcut;if(onInvoke)button.onclick=event=>{if(!button.disabled)onInvoke(event)};return button;
}
function bindConfirmationActions({dialog,cancel,confirm,takeValue=()=>undefined,onConfirm,onCancel}){
 const cancelAction=()=>{const value=takeValue();dialog.close();onCancel?.(value)},confirmAction=()=>{const value=takeValue();dialog.close();onConfirm?.(value)};cancel.onclick=cancelAction;confirm.onclick=confirmAction;
 return {dispose(){if(cancel.onclick===cancelAction)cancel.onclick=null;if(confirm.onclick===confirmAction)confirm.onclick=null}};
}
function createConfirmationView({id,messageId=null,cancelId,confirmId,autofocus=false,captureEscape=false,onConfirm}){
 const dialog=document.createElement('dialog');dialog.id=id;dialog.className='confirm-dialog';const message=document.createElement('p');if(messageId){message.id=messageId;dialog.setAttribute('aria-labelledby',messageId)}
 const actions=document.createElement('div');actions.className='confirm-actions';const cancel=document.createElement('button');cancel.id=cancelId;cancel.type='button';cancel.className='btn';cancel.textContent='キャンセル';cancel.autofocus=autofocus;const confirm=document.createElement('button');confirm.id=confirmId;confirm.type='button';confirm.className='btn primary';confirm.textContent='削除';actions.append(cancel,confirm);dialog.append(message,actions);document.body.append(dialog);
 let pending=null;const close=()=>{pending=null;dialog.close()},escape=event=>{if(dialog.open&&event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();close()}},closed=()=>{if(!dialog.open)pending=null};const binding=bindConfirmationActions({dialog,cancel,confirm,takeValue(){const value=pending;pending=null;return value},onConfirm(value){if(value!==null)onConfirm(value)}});dialog.addEventListener('close',closed);if(captureEscape)window.addEventListener('keydown',escape,true);
 return {dialog,show(text,value){pending=value;message.textContent=text;if(!dialog.open)dialog.showModal()},close,dispose(){close();dialog.removeEventListener('close',closed);if(captureEscape)window.removeEventListener('keydown',escape,true);binding.dispose();dialog.remove()}};
}

function createListItemView({model,select,activate=select,action,context,ignoreSelect='',keyboardTargetOnly=false,stopActionPropagation=true,resolveRow=null}){
 const view=createPhaseListRow(model),{row}=view;
 function invoke(command,event){const focused=document.activeElement===row;command?.(event);if(focused&&!row.isConnected)resolveRow?.()?.focus({preventScroll:true})}
 row.onclick=event=>{if(!ignoreSelect||!event.target.closest(ignoreSelect))invoke(select,event)};
 row.onkeydown=event=>{if(event.isComposing||event.keyCode===229||keyboardTargetOnly&&event.target!==row||event.target!==row&&event.target.closest('button,input,select,textarea,[contenteditable="true"]'))return;if(event.key==='Enter'||event.key===' '){event.preventDefault();invoke(activate,event)}};
 if(action)view.action.onclick=event=>{if(stopActionPropagation)event.stopPropagation();action(event)};
 if(context)row.oncontextmenu=context;
 return view;
}
function createListGroupView({name:label,active=false,collapsed=false,onToggle,onSelect,onUngroup,ungroupTitle,ungroupLabel}){
 const row=document.createElement('div');row.className='phase-group-heading'+(active?' active':'');
 const leading=document.createElement('span');leading.className='phase-group-leading';
 const grip=document.createElement('button');grip.type='button';grip.className='phase-group-range phase-group-drag';grip.title='ドラッグでグループ全体を並べ替え';
 const toggle=document.createElement('button');toggle.type='button';toggle.className='phase-group-toggle';toggle.setAttribute('aria-expanded',String(!collapsed));toggle.setAttribute('aria-label',label+(collapsed?'を開く':'を閉じる'));toggle.innerHTML='<span class="phase-group-disclosure-text" aria-hidden="true">'+(collapsed?'▸':'▾')+'</span><svg class="phase-group-disclosure-arrow" viewBox="0 0 18 18" aria-hidden="true"><path d="'+(collapsed?'M6 3v12l7-6Z':'M3 6h12l-6 7Z')+'"/></svg>';toggle.onclick=onToggle;leading.append(grip,toggle);
 const name=document.createElement('button');name.type='button';name.className='phase-group-name';name.title=label;name.onclick=onSelect;const title=document.createElement('span');title.className='phase-group-title';title.textContent=label;name.append(title);
 const remove=document.createElement('button');remove.type='button';remove.className='phase-group-ungroup';remove.textContent='×';remove.title=ungroupTitle;remove.setAttribute('aria-label',ungroupLabel);remove.onclick=onUngroup;row.append(leading,name,remove);
 return {row,leading,grip,toggle,name,title,remove};
}

// Shared list-name editing mechanics. Callers own data, validation and history.
function beginListNameEdit({row,list,value,label,inputClass,addition=false,cancelButton=null,additionLabel=label,group=false,onFinish}){
 const input=document.createElement('textarea');input.rows=1;input.className=inputClass;input.value=value;input.draggable=false;input.setAttribute('aria-label',label);row.classList.add('renaming');row.draggable=false;row.append(input);
 let done=false,frame=0;const viewport=window.visualViewport,mobile=matchMedia('(max-width:850px)');
 const resize=()=>{input.style.height='auto';input.style.height=Math.max(group?32:23,input.scrollHeight)+input.offsetHeight-input.clientHeight+'px'};
 function cleanup(){viewport?.removeEventListener('resize',schedule);viewport?.removeEventListener('scroll',schedule);window.removeEventListener('resize',schedule);observer.disconnect();if(frame)cancelAnimationFrame(frame)}
 function reveal(){if(!input.isConnected){cleanup();return}revealMovedListItems(list,[input]);if(mobile.matches){input.scrollIntoView({block:'nearest',inline:'nearest'});if(viewport){const r=input.getBoundingClientRect(),bottom=viewport.offsetTop+viewport.height-8;if(r.bottom>bottom)list.scrollTop+=r.bottom-bottom;else if(r.top<viewport.offsetTop+8)list.scrollTop+=r.top-viewport.offsetTop-8}}}
 function schedule(){if(frame||done)return;frame=requestAnimationFrame(()=>{frame=0;if(!done)reveal()})}
 function finish(commit){if(done)return;done=true;cleanup();const name=input.value.replace(/[\r\n]+/g,' ').trim();input.remove();onFinish(commit,name)}
 const observer=new MutationObserver(()=>{if(!input.isConnected)cleanup()});observer.observe(list,{childList:true,subtree:true});
 input.onkeydown=e=>{e.stopPropagation();if(e.isComposing||e.keyCode===229)return;if(e.key==='Enter'){e.preventDefault();finish(true)}else if(e.key==='Escape'){e.preventDefault();finish(false)}};input.onblur=()=>finish(true);input.oninput=()=>{resize();reveal()};for(const type of ['pointerdown','click'])input.addEventListener(type,e=>e.stopPropagation());
 if(addition&&cancelButton){const confirm=document.createElement('button');confirm.type='button';confirm.className='addition-confirm';confirm.dataset.confirmAddition='true';confirm.textContent='✓';confirm.title=additionLabel+'追加を確定';confirm.setAttribute('aria-label',confirm.title);cancelButton.classList.remove('phone-row-actions');cancelButton.disabled=false;cancelButton.textContent='↶';cancelButton.title=additionLabel+'追加を取り消す';cancelButton.setAttribute('aria-label',cancelButton.title);if(group){cancelButton.dataset.cancelGroupAddition='true';cancelButton.style.setProperty('display','inline-flex','important')}for(const [button,commit]of [[confirm,true],[cancelButton,false]]){button.onpointerdown=e=>{e.preventDefault();e.stopPropagation()};button.onclick=e=>{e.preventDefault();e.stopPropagation();finish(commit)}}row.insertBefore(confirm,cancelButton)}
 viewport?.addEventListener('resize',schedule);viewport?.addEventListener('scroll',schedule);window.addEventListener('resize',schedule);input.focus({preventScroll:true});input.select();resize();reveal();schedule();return {input,finish};
}

function revealMovedListItems(list,items){
 const item=items[0];if(!list||!item)return;
 // Scroll only this list, preserving surrounding panes and the selection.
 if(list.clientHeight){
  const listRect=list.getBoundingClientRect(),itemRect=item.getBoundingClientRect(),top=listRect.top+list.clientTop,bottom=top+list.clientHeight;
  if(itemRect.height>list.clientHeight||itemRect.top<top)list.scrollTop+=itemRect.top-top;
  else if(itemRect.bottom>bottom)list.scrollTop+=itemRect.bottom-bottom;
 }
 for(const row of items){row.classList.add('item-just-moved');setTimeout(()=>row.classList.remove('item-just-moved'),1200)}
}

function revealMovedLayers(ids){
 const list=document.getElementById('objectList'),moved=new Set(expandObjectGroups(ids));
 if(list)list.querySelectorAll('.object-group-member.item-just-moved').forEach(row=>row.classList.remove('item-just-moved'));
 revealMovedListItems(list,list?Array.from(list.children).filter(row=>!row.classList.contains('object-group-member')&&moved.has(row.dataset.id)):[]);
}

function setObjectState(ids,key,value){if(boardReadOnly||phaseComparisonActive())return;let items=current().filter(item=>ids.includes(item.id));if(!items.length||items.every(item=>item[key]===value))return;recordHistory();for(let item of items)item[key]=value;renderAndSave()}

function normalizeObjectGroups(board){for(const page of board.pages){const compact=objectLayerBlocks(page.slice().reverse()).flat().reverse();if(compact.some((o,i)=>o!==page[i]))page.splice(0,page.length,...compact);}}
function syncGroupStateButton(button,states,label){const mixed=states.some(Boolean)&&!states.every(Boolean);button.classList.toggle('mixed-state',mixed);button.classList.toggle('active',states.every(Boolean));button.setAttribute('aria-pressed',mixed?'mixed':String(states.every(Boolean)));if(mixed)button.title=label+'が混在：'+button.title;button.setAttribute('aria-label',button.title)}
function renderMultiSwapButton(el,items){
 if(items.length!==2)return;const ids=items.map(o=>o.id),button=document.createElement('button');button.type='button';button.id='swapSelectedPositions';button.className='property-swap-button';button.title='位置入れ替え';button.setAttribute('aria-label','位置入れ替え');button.disabled=boardReadOnly||phaseComparisonActive()||items.some(o=>o.locked);
 button.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16m-4-4 4 4-4 4M20 17H4m4-4-4 4 4 4"/></svg>';
 button.onclick=()=>{if(selectedIds.length!==2||!ids.every(id=>selectedIds.includes(id)))return;swapObjectPositions(ids)};el.querySelector('.property-toggles').append(button);
}
function renderMultiStateToggles(el,items){
 if(el.querySelector('#bulkEditableInput'))return;
 let row=el.querySelector('.property-kind-row');if(!row){row=document.createElement('div');row.className='property-kind-row';const summary=el.firstElementChild;el.prepend(row);if(summary)row.append(summary)}
 row.insertAdjacentHTML('beforeend','<div class="field property-toggles"><label class="property-icon-toggle"><input id="bulkVisibleInput" type="checkbox"  aria-label="表示"><svg class="toggle-on" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg><svg class="toggle-off" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12ZM9 12a3 3 0 1 0 6 0 3 3 0 0 0-6 0M3 3l18 18"/></svg></label><label class="property-icon-toggle"><input id="bulkEditableInput" type="checkbox"  aria-label="編集可"><svg class="toggle-on" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L8 18l-4 1 1-4Z"/></svg><svg class="toggle-off" viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/></svg></label></div>');bindBulkStateToggles(el,items);
}
function objectGroupSpacingFactor(geometry,width){
 let low=0,high=20;for(let i=0;i<50;i++){const middle=(low+high)/2;if(groupWidthAtSpacing(geometry,middle)<width)low=middle;else high=middle}return (low+high)/2;
}
function objectGroupScaleLimits(items,geometry,spacing){
 const min=spacing?0:Math.max(...items.flatMap(o=>[8/o.width,8/o.height,o.type==='text'?6/(o.fontSize||12):0]));
 const widthLimit=Math.max(960,geometry.width),max=spacing?objectGroupSpacingFactor(geometry,widthLimit):Math.min(widthLimit/geometry.width,...items.flatMap(o=>[960/o.width,960/o.height]));
 return {min,max};
}
function applyObjectGroupScale(items,cx,cy,factor,spacing,geometry=objectGroupDimensions(items)){
 const {min,max}=objectGroupScaleLimits(items,geometry,spacing);factor=Math.max(min,Math.min(max,factor));
 for(const original of items){const item=current().find(o=>o.id===original.id);if(!item)continue;item.x=cx+(original.x-cx)*factor;item.y=cy+(original.y-cy)*factor;item.width=original.width*(spacing?1:factor);item.height=original.height*(spacing?1:factor);if(item.type==='text')item.fontSize=(original.fontSize||12)*(spacing?1:factor)}return factor;
}
function objectGroupDimensions(items){
 const r=layer.getBoundingClientRect(),w=layer.clientWidth||640,h=layer.clientHeight||640;
 const bounds=items.map(o=>{const node=layer.querySelector('[data-id="'+o.id+'"]'),b=node?.getBoundingClientRect();return {x:o.x/100*w,left:b&&b.width?(b.left-r.left)/r.width*w:o.x/100*w-o.width/2,right:b&&b.width?(b.right-r.left)/r.width*w:o.x/100*w+o.width/2,top:b&&b.height?(b.top-r.top)/r.height*h:o.y/100*h-o.height/2,bottom:b&&b.height?(b.bottom-r.top)/r.height*h:o.y/100*h+o.height/2}});
 const left=Math.min(...bounds.map(b=>b.left)),right=Math.max(...bounds.map(b=>b.right)),top=Math.min(...bounds.map(b=>b.top)),bottom=Math.max(...bounds.map(b=>b.bottom));return {bounds,width:right-left,height:bottom-top,cx:(left+right)/2/w*100,cy:(top+bottom)/2/h*100};
}
function groupWidthAtSpacing(geometry,factor){return Math.max(...geometry.bounds.map(b=>b.x*factor+b.right-b.x))-Math.min(...geometry.bounds.map(b=>b.x*factor+b.left-b.x))}

function objectGroupRotationCenter(items){return {cx:items.reduce((sum,o)=>sum+o.x,0)/items.length,cy:items.reduce((sum,o)=>sum+o.y,0)/items.length}}
function normalizedObjectRotation(degrees){const value=((degrees%360)+360)%360;return value>180?value-360:value}
function objectGroupRotationValue(items,orientationOnly=false){const item=items.find(o=>o.objectGroupRotationOwner===o.objectGroupId);return Number(item?.[orientationOnly?'objectGroupOrientationRotation':'objectGroupPlacementRotation'])||0}
function restoreObjectGroupRotationState(item,original){for(const key of ['x','y','rotation','objectGroupRotationOwner','objectGroupPlacementRotation','objectGroupOrientationRotation']){if(Object.hasOwn(original,key))item[key]=original[key];else delete item[key]}}
function applyObjectGroupRotation(originals,cx,cy,degrees,rotateContents,orientationOnly=false){
 const placement=objectGroupRotationValue(originals),orientation=objectGroupRotationValue(originals,true),angle=normalizedObjectRotation(degrees),radians=angle*Math.PI/180,c=Math.cos(radians),sn=Math.sin(radians),w=layer.clientWidth||640,h=layer.clientHeight||640;
 if(!angle){for(const original of originals){const item=current().find(o=>o.id===original.id);if(item)restoreObjectGroupRotationState(item,original)}return}
 for(const original of originals){const item=current().find(o=>o.id===original.id);if(!item)continue;const x=(original.x-cx)/100*w,y=(original.y-cy)/100*h;item.x=angle&&!orientationOnly?cx+(x*c-y*sn)/w*100:original.x;item.y=angle&&!orientationOnly?cy+(x*sn+y*c)/h*100:original.y;item.rotation=rotateContents&&angle?normalizedObjectRotation((original.rotation||0)+angle):original.rotation;item.objectGroupRotationOwner=item.objectGroupId;item.objectGroupPlacementRotation=normalizedObjectRotation(placement+(orientationOnly?0:angle));item.objectGroupOrientationRotation=normalizedObjectRotation(orientation+(rotateContents?angle:0))}
}
function refreshObjectGroupDimensions(section,items){
 const actual=objectGroupDimensions(items);for(const field of section.querySelectorAll('.group-width-property')){for(const input of field.querySelectorAll('input'))input.value=Math.round(actual.width);field.querySelector('label span').textContent=Math.round(actual.width);field.querySelector('.hint span').textContent=Math.round(actual.height)}
}
function renderGroupRotationProperty(section,items,orientationOnly=false){
 const field=document.createElement('section');field.className='object-group-rotation';const prefix=orientationOnly?'groupOrientation':'groupRotation',caption=orientationOnly?'回転（向き）':'回転（配置）';field.append(createPropertyNumberField({label:caption,rangeId:prefix+'Range',numberId:prefix+'Number',valueId:prefix+'Value',value:0,unit:'°',min:-180,max:180,linkLabel:true,numberLabel:caption+'（°）'}).field);section.append(field);
 const owner=data,page=current(),ids=items.map(o=>o.id),range=field.querySelector('[type=range]'),number=field.querySelector('[type=number]'),value=field.querySelector('label span');range.value=number.value=objectGroupRotationValue(items,orientationOnly);value.textContent=range.value;
 const blocked=()=>boardReadOnly||phaseComparisonActive()||owner!==data||page!==current()||items.some(o=>o.locked);for(const input of field.querySelectorAll('input,button'))input.disabled=blocked();let session=null;
 function valid(){return !blocked()&&selectedObjectGroup().length===items.length&&ids.every(id=>selectedIds.includes(id))}
 function finish(cancel=false){if(!session)return;const previous=session;session=null;if(data!==owner||current()!==page)return;if(cancel){for(const original of previous.items){const item=current().find(o=>o.id===original.id);if(item)restoreObjectGroupRotationState(item,original)}}else if(JSON.stringify(data)!==previous.before)recordHistory(previous.before);renderAndSave()}
 function apply(degrees){if(!valid()||!Number.isFinite(degrees))return;if(!session){const center=objectGroupRotationCenter(items);session={before:JSON.stringify(data),items:JSON.parse(JSON.stringify(items)),cx:center.cx,cy:center.cy,rotateContents:orientationOnly,startAngle:objectGroupRotationValue(items,orientationOnly)}}degrees=Math.max(-180,Math.min(180,Math.round(degrees)));applyObjectGroupRotation(session.items,session.cx,session.cy,degrees-session.startAngle,session.rotateContents,orientationOnly);for(const item of items)updateShapeFromData(item,false);renderObjectGroupControls();range.value=number.value=degrees;value.textContent=degrees;refreshObjectGroupDimensions(section,items)}
 bindPropertyEditSession([range,number],{onInput:input=>{if(input.value!=='')apply(Number(input.value))},onFinish:()=>finish(),onCancel:()=>finish(true),keyboard:true});
 if(!orientationOnly)renderGroupRotationProperty(section,items,true);
}
function renderGroupScaleProperty(section,items){renderGroupWidthProperty(section,items,false);renderGroupWidthProperty(section,items,true)}
function renderGroupWidthProperty(section,items,spacing){
 const geometry=objectGroupDimensions(items),limits=objectGroupScaleLimits(items,geometry,spacing),minimum=spacing?groupWidthAtSpacing(geometry,limits.min):geometry.width*limits.min,maximum=spacing?groupWidthAtSpacing(geometry,limits.max):geometry.width*limits.max;
 const prefix=spacing?'groupSpacing':'groupScale';const field=createPropertyNumberField({className:'field group-width-property',label:spacing?'サイズ(間隔)':'サイズ(幅)',rangeId:prefix+'Range',numberId:prefix+'Number',valueId:prefix+'Value',unit:' px',linkLabel:true,numberLabel:(spacing?'サイズ(間隔)':'サイズ(幅)')+'（px）'}).field;const hint=document.createElement('div');hint.className='hint';hint.innerHTML='全体の高さ：<span id="'+(spacing?'groupSpacingHeightValue':'groupHeightValue')+'"></span> px';field.append(hint);
 section.append(field);const range=field.querySelector('[type=range]'),number=field.querySelector('[type=number]'),value=field.querySelector(spacing?'#groupSpacingValue':'#groupScaleValue'),height=field.querySelector(spacing?'#groupSpacingHeightValue':'#groupHeightValue'),owner=data,page=current();const blocked=()=>boardReadOnly||phaseComparisonActive()||items.some(o=>o.locked)||data!==owner||current()!==page;for(const control of [range,number])control.disabled=blocked();for(const control of [range,number]){control.min=Math.ceil(minimum-0.000001);control.max=Math.max(Math.ceil(minimum-0.000001),Math.floor(maximum+0.000001));control.value=Math.round(geometry.width)}value.textContent=Math.round(geometry.width);height.textContent=Math.round(geometry.height);let session=null;
 function valid(){return !blocked()&&selectedObjectGroup().length===items.length&&items.every(o=>selectedIds.includes(o.id))}
 function finish(cancel=false){if(!session)return;const previous=session;session=null;if(data!==owner||current()!==page)return;if(cancel){for(const original of previous.items){const item=current().find(o=>o.id===original.id);if(item)Object.assign(item,original)}}else if(JSON.stringify(data)!==previous.before)recordHistory(previous.before);renderAndSave()}
 function apply(input){if(!valid()||input.value==='')return;if(!session)session={before:JSON.stringify(data),items:JSON.parse(JSON.stringify(items)),geometry:objectGroupDimensions(items)};
 const desired=Math.max(minimum,Math.min(maximum,Number(input.value)||minimum)),g=session.geometry;let factor=desired/g.width;
 if(spacing)factor=objectGroupSpacingFactor(g,desired);
 applyObjectGroupScale(session.items,g.cx,g.cy,factor,spacing,g);for(const item of items)updateShapeFromData(item,false);renderObjectGroupControls();let actual=objectGroupDimensions(items);const dx=g.cx-actual.cx,dy=g.cy-actual.cy;for(const item of items){item.x+=dx;item.y+=dy;updateShapeFromData(item,false)}renderObjectGroupControls();actual=objectGroupDimensions(items);for(const panel of section.querySelectorAll('.group-width-property')){for(const control of panel.querySelectorAll('input'))control.value=Math.round(actual.width);panel.querySelector('label span').textContent=Math.round(actual.width);panel.querySelector('.hint span').textContent=Math.round(actual.height)}
 }
 bindPropertyEditSession([range,number],{onInput:apply,onFinish:()=>finish(),onCancel:()=>finish(true),keyboard:true});

}
function renderObjectGroupNameProperty(el){
 const items=selectedObjectGroup();if(!items.length)return;
 const owner=data,page=current(),groupId=items[0].objectGroupId,original=objectGroupName(items);
 const {field,input}=createPropertyTextField({id:'objectGroupNameInput',label:'グループ名',value:original,maxLength:80,disabled:boardReadOnly||phaseComparisonActive(),restoreOnEscape:()=>original,onCommit(raw){const value=raw.trim();if(!value){input.value=original;return}if(value===original||boardReadOnly||phaseComparisonActive()||data!==owner||current()!==page)return;const members=current().filter(o=>o.objectGroupId===groupId);if(!members.length)return;recordHistory();for(const member of members)member.objectGroupName=value;renderAndSave()}});
 const section=document.createElement('section');section.className='object-group-properties';section.id='objectGroupProperties';section.append(field);renderMultiStateToggles(section,items);renderGroupScaleProperty(section,items);renderGroupRotationProperty(section,items);el.append(section);
}

function updateStateToggleTooltip(input,kind){
 const visibility=kind==='visible',state=input.indeterminate?'状態が混在':visibility?(input.checked?'表示中':'非表示中'):(input.checked?'編集可':'編集不可');
 const action=visibility?(input.checked?'非表示にする':'表示する'):(input.checked?'編集不可にする':'編集可にする');
 const text=state+'：'+(input.id.startsWith('bulk')?'選択中のすべてを':'')+action;
 input.title=text;input.closest('.property-icon-toggle').title=text;input.setAttribute('aria-label',text);
}

function bindBulkStateToggles(el,items){for(let [id,key,isOn] of [['bulkVisibleInput','visible',item=>item.visible!==false],['bulkEditableInput','locked',item=>!item.locked]]){let input=el.querySelector('#'+id),count=items.filter(isOn).length;input.checked=count===items.length;input.indeterminate=count>0&&count<items.length;updateStateToggleTooltip(input,key);input.onchange=()=>setObjectState(items.map(item=>item.id),key,key==='locked'?!input.checked:input.checked)}}

function renderCategoryRotation(el,items){const editable=items.filter(o=>!o.locked),category=objectCategory(items[0]);el.innerHTML='<div class="field"><label>選択中</label><div>'+items.length+' 個の'+esc(category)+'</div></div>'+propertyNumberFieldMarkup({label:'傾き',rangeId:'categoryRotation',numberId:'categoryRotationSpin',valueId:'categoryRotationValue',value:Math.round(items[0].rotation||0),unit:'°',min:-180,max:180})+'';const range=el.querySelector('#categoryRotation'),spin=el.querySelector('#categoryRotationSpin');for(const input of [range,spin]){input.disabled=!editable.length;input.addEventListener('focus',()=>{recordHistory()});input.addEventListener('input',()=>{const v=Math.max(-180,Math.min(180,Math.round(Number(input.value)||0)));range.value=spin.value=v;el.querySelector('#categoryRotationValue').textContent=v;for(const o of editable){o.rotation=v;const node=layer.querySelector('[data-id="'+o.id+'"]');if(node){node.style.setProperty('--rot',v+'deg');node.style.transform='translate(-50%,-50%) rotate('+v+'deg)'}}save()})}}

function proportionalSizeType(type){return ['image','circle','donut','knockback','lineknockback','targetcircle','stack','linestack','gaze','icon'].includes(type)}

function proportionalDimensions(o,value){
 const min=o.type==='image'?Math.min(1,o.width,o.height):o.type==='icon'?24:20,max=o.type==='icon'?640:960,width=Number(o.width)||110,height=Number(o.height)||width;
 const factor=Math.max(Math.max(min/width,min/height),Math.min(Math.min(max/width,max/height),(Number(value)||min)/width));return o.type==='image'?{width:width*factor,height:height*factor}:{width:Math.round(width*factor),height:Math.round(height*factor)}
}

function unifyProportionalSize(el,o){
 if(!proportionalSizeType(o.type)||o.type==='icon'||o.type==='image')return;
 const range=el.querySelector('#widthInput'),spin=el.querySelector('#widthSpin'),height=el.querySelector('#heightInput');if(!range||!spin)return;
 height?.closest('.field').remove();const label=range.closest('.field').querySelector('label');label.innerHTML='サイズ：<span id="widthValue">'+Math.round(o.width)+'</span> px';range.setAttribute('aria-label','サイズ');spin.setAttribute('aria-label','サイズ');
 const ratio=o.height/o.width,min=Math.ceil(Math.max(20,20/ratio)),max=Math.floor(Math.min(960,960/ratio));range.min=spin.min=min;range.max=spin.max=max;
 const apply=event=>{if(boardReadOnly||o.locked)return;const size=proportionalDimensions(o,event.target.value);o.width=size.width;o.height=size.height;range.value=spin.value=size.width;el.querySelector('#widthValue').textContent=size.width;updateShapeFromData(o)};range.oninput=apply;spin.oninput=apply;spin.onfocus=()=>recordHistory();
}

// Bulk properties must be editable in every member's individual inspector.
function objectSupportsBulkProperty(o,key){if(o.type==='image')return ['opacity','rotation','width'].includes(key);
 const shape=['circle','donut','aoe','line','gaze','segment','targetcircle','stack','linestack','knockback','lineknockback'].includes(o.type);
 const fixedColor=['gaze','stack','linestack','knockback','lineknockback'].includes(o.type);
 if(key==='color')return o.type==='icon'?isBossObject(o)||isTowerObject(o):!fixedColor;
 if(key==='strokeColor')return ['circle','donut','aoe','line','segment'].includes(o.type);
 if(key==='opacity')return o.type==='icon'?isBossObject(o)||hasAdditionalOpacity(o)||o.iconName==='AoE 円範囲':shape&&o.type!=='targetcircle';
 if(key==='rotation')return o.type==='icon'?isBossObject(o)||['距離減衰','フレア','ロックオン青','ターゲット青','ロックオン赤','ロックオン緑','ロックオン紫','ダイブボム','ターゲット赤','ターゲット紫'].includes(o.iconName):shape;
 if(key==='width')return shape||o.type==='icon'||o.type==='image'||o.type==='text';
 if(key==='height')return shape&&o.type!=='segment'&&!proportionalSizeType(o.type);
 if(key==='innerSize')return o.type==='donut';
 if(key==='label'||key==='fontSize')return o.type==='text';
 return false;
}
function renderMultiInspector(el,items){let type=items[0].type;if(!items.every(item=>item.type===type)){if(items.every(item=>objectCategory(item)===objectCategory(items[0])&&objectSupportsBulkProperty(item,'rotation'))){renderCategoryRotation(el,items);return}el.innerHTML=`<div class="field"><label>選択中</label><div style="font-size:12px">${items.length} 個のオブジェクト</div></div>${selectedObjectGroup().length?'':'<p class="hint">同じカテゴリーのオブジェクトを選択すると、向きをまとめて変更できます。</p>'}`;return}let first=items[0],editableItems=items.filter(item=>!item.locked),fields=[];if('color'in first&&!['gaze','stack','linestack','knockback','lineknockback'].includes(type))fields.push({key:'color',label:type==='text'?'文字色':['circle','donut','aoe','line'].includes(type)?'塗りつぶし色':'色',kind:'color'});if(['circle','donut','aoe','line','segment'].includes(type))fields.push({key:'strokeColor',label:'枠色',kind:'color'});if('opacity'in first&&type!=='targetcircle'&&!items.every(isTowerObject))fields.push({key:'opacity',label:'透過率',kind:'range',min:0,max:100,unit:'%'});if('width'in first)fields.push({key:'width',label:type==='segment'?'長さ':proportionalSizeType(type)?'サイズ':'幅',kind:'range',min:type==='icon'?24:20,max:type==='icon'?640:960,unit:'px'});if('height'in first&&!['segment','icon','text'].includes(type)&&!proportionalSizeType(type))fields.push({key:'height',label:'高さ',kind:'range',min:20,max:960,unit:'px'});if(type==='donut')fields.push({key:'innerSize',label:'内円の直径',kind:'range',min:0,max:Math.min(...items.map(donutMaxInnerDiameter)),unit:'px'});if('rotation'in first)fields.push({key:'rotation',label:'傾き',kind:'range',min:-180,max:180,unit:'°'});if(type==='text'){fields.push({key:'label',label:'テキスト',kind:'text'});fields.push({key:'fontSize',label:'文字サイズ',kind:'range',min:8,max:640,unit:'px'})}fields=fields.filter(field=>items.every(item=>objectSupportsBulkProperty(item,field.key)));fields.sort((a,b)=>({label:2,width:20,height:21,innerSize:25,fontSize:26,rotation:30,color:40,strokeColor:41,fillType:50,opacity:60}[a.key]??70)-({label:2,width:20,height:21,innerSize:25,fontSize:26,rotation:30,color:40,strokeColor:41,fillType:50,opacity:60}[b.key]??70));let valueOf=(item,key)=>key==='innerSize'?Math.round(donutInnerDiameter(item)):key==='opacity'?Number.isFinite(item[key])?item[key]:100:key==='width'?item[key]||(type==='text'?180:44):key==='height'?item[key]||44:key==='rotation'?item[key]||0:key==='fontSize'?item[key]||12:key==='label'?item[key]||'':key==='strokeColor'?item.strokeColor||item.color||'#ffffff':item[key]||'#ffffff';el.innerHTML=`<div class="property-kind-row"><div class="field"><label>選択中</label><div style="font-size:12px">${items.length} 個の${objectTitle(first)}</div></div><div class="field property-toggles"><label class="property-icon-toggle"><input id="bulkVisibleInput" type="checkbox"  aria-label="表示"><svg class="toggle-on" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg><svg class="toggle-off" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12ZM9 12a3 3 0 1 0 6 0 3 3 0 0 0-6 0M3 3l18 18"/></svg></label><label class="property-icon-toggle"><input id="bulkEditableInput" type="checkbox"  aria-label="編集可"><svg class="toggle-on" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L8 18l-4 1 1-4Z"/></svg><svg class="toggle-off" viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/></svg></label></div></div><p class="hint">変更したプロパティを選択中の${items.length}個すべてに適用します。</p>${fields.map((field,index)=>{let value=valueOf(first,field.key),id='bulkProperty'+index;if(field.kind==='range')value=Math.round(value);if(field.kind==='text')return `<div class="field"><label>${field.label}</label><textarea id="${id}" rows="3">${esc(value)}</textarea></div>`;if(field.kind==='color')return `<div class="field"><label>${field.label}</label>${colorPickerMarkup(field.key==='strokeColor'?'bulkStrokeColor':'bulkColor',value)}</div>`;return propertyNumberFieldMarkup({label:field.label,rangeId:id,numberId:id+'Spin',valueId:id+'Value',value,unit:' '+(field.unit||''),min:field.min,max:field.max})}).join('')}`;const fillField=el.querySelector('[data-color-kind=bulkColor]')?.closest('.field'),strokeField=el.querySelector('[data-color-kind=bulkStrokeColor]')?.closest('.field');if(fillField&&strokeField){const row=document.createElement('div');row.className='property-color-fill-row';fillField.before(row);row.append(fillField,strokeField)}bindBulkStateToggles(el,items);bindSegmentSettings(el,items);fields.forEach((field,index)=>{if(field.kind==='color')return;let id='bulkProperty'+index,inputs=field.kind==='range'?[el.querySelector('#'+id),el.querySelector('#'+id+'Spin')]:[el.querySelector('#'+id)];let pushHistory=input=>{if(input.dataset.historyPushed||!editableItems.length)return;recordHistory();input.dataset.historyPushed='true'};let apply=input=>{if(!editableItems.length)return;let value=field.kind==='range'?Math.max(field.min,Math.min(field.max,Math.round(Number(input.value)||0))):input.value;if(field.kind==='range'){inputs.forEach(control=>control.value=value);let display=el.querySelector('#'+id+'Value');if(display)display.textContent=value}if(field.kind==='range'&&editableItems.every(item=>Math.round(Number(valueOf(item,field.key)))===value))return;pushHistory(input);for(let item of editableItems){if(field.key==='innerSize')setDonutInnerDiameter(item,value);else if(field.key==='width'&&proportionalSizeType(type)){const size=proportionalDimensions(item,value);item.width=size.width;item.height=size.height}else item[field.key]=value;if(field.key==='fillType')item.gradient=String(value).startsWith('gradient');let node=layer.querySelector('[data-id="'+item.id+'"]');if(['circle','donut','aoe','line','gaze','segment','targetcircle','stack','linestack','knockback','lineknockback'].includes(type))updateShapeFromData(item,false);else if(type==='icon'&&node){if(field.key==='width'){node.style.width=value+'px';node.style.height=value+'px';node.style.setProperty('--icon-size',value+'px');const badge=node.querySelector('.role-badge');if(badge){badge.style.setProperty('font-size',Math.max(8,value*.36)+'px','important');badge.style.right=(value*.06)+'px';badge.style.bottom=(value*.06)+'px';badge.style.webkitTextStroke=(value*.03)+'px #111'}}else if(field.key==='opacity'){let image=node.querySelector('img');if(image)image.style.opacity=String(value/100)}else if(field.key==='rotation')node.style.transform='translate(-50%,-50%) rotate('+value+'deg)'}else if(type==='text'&&node){if(field.key==='width'||field.key==='fontSize')resizeTextFromData(item);if(field.key==='label')node.textContent=value;if(field.key==='color')node.style.color=value;if(field.key==='width')node.style.width=value+'px';if(field.key==='fontSize')node.style.fontSize=value+'px';if(field.key==='rotation')node.style.transform='translate(-50%,-50%) rotate('+value+'deg)'}else if(type==='marker'&&node){if(field.key==='color')node.style.background=value;if(field.key==='rotation')node.style.transform='translate(-50%,-50%) rotate('+value+'deg)'}}save()};for(let input of inputs){input.disabled=!editableItems.length;if(field.kind==='range'){ input.addEventListener('pointerdown',()=>pushHistory(input));input.addEventListener('focus',()=>pushHistory(input))}else input.addEventListener('focus',()=>pushHistory(input));input.addEventListener('input',()=>apply(input));input.addEventListener('change',()=>{
 for(const control of inputs)delete control.dataset.historyPushed;
 if(field.kind!=='range'){renderAndSave();return}
 const reference=editableItems[0];if(!reference)return;
 fields.forEach((related,relatedIndex)=>{if(related.kind!=='range')return;
  const relatedId='bulkProperty'+relatedIndex,value=Math.round(valueOf(reference,related.key));
  if(related.key==='innerSize')related.max=Math.min(...editableItems.map(donutMaxInnerDiameter));
  for(const suffix of ['', 'Spin']){const control=el.querySelector('#'+relatedId+suffix);if(control){control.max=related.max;control.value=value}}
  const label=el.querySelector('#'+relatedId+'Value');if(label)label.textContent=value;
 });
})}})}

function organizeInspectorFields(el){
 // Move existing nodes so IDs, values, listeners and disabled states survive.
 const text=el.querySelector('#textContentInput');
 if(text){const field=text.closest('.field'),width=field.querySelector('#textWidthInput');if(width){const widthField=document.createElement('div');widthField.className='field';const control=width.closest('.coordinate-control'),label=control.previousElementSibling;widthField.append(label,control);field.after(widthField)}}
 for(const group of el.querySelectorAll('.property-color-fill-row')){
  for(const field of Array.from(group.children)){
   const opacity=field.querySelector('#opacityInput');
   const fill=field.querySelector('#fillInput');
   if(opacity||fill&&!group.classList.contains('segment-properties'))group.after(field);
  }
 }
 const rank=field=>{
  if(field.classList.contains('property-kind-row'))return 0;
  if(field.classList.contains('hint'))return 1;
  if(field.querySelector('#textContentInput'))return 2;
  if(field.classList.contains('coordinate-fields'))return 10;
  if(field.querySelector('#textWidthInput,#iconSizeInput,#widthInput'))return 20;
  if(field.querySelector('#heightInput'))return 21;
  if(field.querySelector('#donutInnerInput'))return 25;
  if(field.querySelector('#textSizeInput'))return 26;
  if(field.querySelector('#rotationInput,#bossRotationInput,#specialIconRotationInput'))return 30;
  if(field.querySelector('.color-picker'))return 40;
  if(field.querySelector('#fillInput'))return 50;
  if(field.querySelector('#opacityInput,#bossOpacityInput,#aoeIconOpacityRange,#specialIconOpacityInput'))return 60;
  return 70;
 };
 const ordered=Array.from(el.children).sort((a,b)=>rank(a)-rank(b));
 let previousSection=null;
 for(const field of ordered){
  const order=rank(field),section=order<2?'status':order<10?'text':order<20?'position':order<30?'geometry':order<40?'rotation':order<70?'appearance':'other';
  field.classList.toggle('inspector-section-start',previousSection!==null&&section!==previousSection&&section!=='status');
  if(!field.classList.contains('hint'))previousSection=section;
  el.appendChild(field);
 }
}

function hideUnusedObjectSettings(el,o){if(o.type==='image'){for(const picker of el.querySelectorAll('.color-picker'))picker.closest('.property-color-fill-row,.field')?.remove();el.querySelector('#fillInput')?.closest('.field').remove();for(const axis of ['width','height'])for(const suffix of ['Input','Spin']){const input=el.querySelector('#'+axis+suffix);if(input){input.min=String(Math.min(1,o[axis]));input.step='0.01';input.value=o[axis]}}return}
 if(o.type==='targetcircle'){
  el.querySelector('#fillInput')?.closest('.field').remove();
  el.querySelector('#opacityInput')?.closest('.field').remove();
  return;
 }
 if(!['gaze','stack','linestack','knockback','lineknockback'].includes(o.type))return;
 for(const picker of el.querySelectorAll('.color-picker'))picker.closest('.field')?.remove();
 el.querySelector('#fillInput')?.closest('.field').remove();
}

function bindObjectNumberProperty(o,{range,number,output,key,min,max}){
 function history(input){if(boardReadOnly||o.locked||input.dataset.historyPushed)return;recordHistory();input.dataset.historyPushed='true'}
 const bindings=[],bind=(input,type,handler)=>{input.addEventListener(type,handler);bindings.push(()=>input.removeEventListener(type,handler))};
 for(const input of [range,number]){input.disabled=boardReadOnly||!!o.locked;for(const event of ['pointerdown','focus'])bind(input,event,()=>history(input));bind(input,'input',()=>{if(boardReadOnly||o.locked||input.value==='')return;history(input);const value=Math.max(min,Math.min(max,Math.round(Number(input.value)||0)));o[key]=value;range.value=number.value=value;output.textContent=value;updateShapeFromData(o)});for(const event of ['change','blur'])bind(input,event,()=>{delete input.dataset.historyPushed})}
 return ()=>bindings.forEach(dispose=>dispose());
}

function addObjectRotationSetting(el,o){
 if(el.querySelector('#rotationInput,#bossRotationInput'))return;
 const field=createPropertyNumberField({label:'回転',rangeId:'specialIconRotationInput',numberId:'specialIconRotationSpin',valueId:'specialIconRotationValue',value:Math.round(o.rotation||0),unit:'°',min:-180,max:180,className:'field'}).field;el.append(field);
 const range=field.querySelector('#specialIconRotationInput'),spin=field.querySelector('#specialIconRotationSpin'),label=field.querySelector('#specialIconRotationValue');
 bindObjectNumberProperty(o,{range,number:spin,output:label,key:'rotation',min:-180,max:180});
}

function hasAdditionalOpacity(o){return o.type==='gaze'||o.type==='icon'&&['距離減衰','フレア','ロックオン青','ターゲット青','ロックオン赤','ロックオン緑','ロックオン紫','ダイブボム','ターゲット赤','ターゲット紫'].includes(o.iconName)}

function additionalOpacityValue(o){return Math.max(0,Math.min(100,Number.isFinite(o.opacity)?o.opacity:100))}

function addSpecialIconOpacitySetting(el,o){
 if(o.type!=='icon'||!hasAdditionalOpacity(o))return;
 const value=additionalOpacityValue(o);const field=createPropertyNumberField({label:'透過率',rangeId:'specialIconOpacityInput',numberId:'specialIconOpacitySpin',valueId:'specialIconOpacityValue',value:value,unit:'%',min:0,max:100,className:'field opacity-control'}).field;el.append(field);
 const range=field.querySelector('#specialIconOpacityInput'),spin=field.querySelector('#specialIconOpacitySpin'),label=field.querySelector('#specialIconOpacityValue');
 bindObjectNumberProperty(o,{range,number:spin,output:label,key:'opacity',min:0,max:100});
}

function renderInspector(){let el=$('#inspector'),items=current().filter(x=>selectedIds.includes(x.id)),title=$('#toggleInspector');el.classList.toggle('segment-inspector',items.length===1&&items[0].type==='segment');title.textContent='オブジェクトプロパティ';title.title='オブジェクトプロパティを開閉';if(!items.length){el.className='inspector-empty';el.textContent='キャンバス上のオブジェクトを選択すると、詳細を編集できます。';return}el.className='';if(items.length>1){
 if(selectedObjectGroup().length){el.replaceChildren();renderObjectGroupNameProperty(el);return}
 renderMultiInspector(el,items);renderMultiStateToggles(el,items);renderMultiSwapButton(el,items);showLockedSelectionHint(el,items);return
}let o=items[0],isShape=['image','circle','donut','aoe','line','gaze','segment','targetcircle','stack','linestack','knockback','lineknockback'].includes(o.type),isIcon=o.type==='icon',isBossIcon=isIcon&&['大ボス','中ボス','小ボス'].includes(o.iconName),isAoeIcon=isIcon&&o.iconName==='AoE 円範囲';el.innerHTML=`<div class="property-kind-row"><div class="field"><label>カテゴリ</label><div style="font-size:12px">${objectCategory(o)}</div></div><div class="field property-toggles"><label class="property-icon-toggle"><input id="visibleInput" type="checkbox" ${o.visible===false?"":"checked"} aria-label="表示"><svg class="toggle-on" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg><svg class="toggle-off" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12ZM9 12a3 3 0 1 0 6 0 3 3 0 0 0-6 0M3 3l18 18"/></svg></label><label class="property-icon-toggle"><input id="editableInput" type="checkbox" ${o.locked?"":"checked"} aria-label="編集可"><svg class="toggle-on" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L8 18l-4 1 1-4Z"/></svg><svg class="toggle-off" viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/></svg></label></div></div>${!isIcon?(['aoe','circle','donut','line','gaze','segment'].includes(o.type)?`<div class="property-color-fill-row area-shape-color-fill-row${o.type==='segment'?' segment-properties':''}"><div class="field"><label>${o.type==='segment'?'色':'塗りつぶし色'}</label>${colorPickerMarkup('object',o.color,o.id)}</div>${o.type==='segment'?`<div class="field opacity-control"><label>透過率：<span id="opacityValue">${Math.round(o.opacity)}</span>%</label><div class="coordinate-control"><input id="opacityInput" type="range" step="1" min="0" max="100" value="${Math.round(o.opacity)}"><input id="opacitySpin" type="number" min="0" max="100" step="1" value="${Math.round(o.opacity)}" aria-label="透過率"></div></div>`:''}<div class="field"><label>枠色</label>${colorPickerMarkup('aoeStroke',o.strokeColor||o.color,o.id)}</div><div class="field"><label>塗りつぶし効果</label><select id="fillInput"><option value="solid" ${o.fillType==='solid'?'selected':''}>単色</option><option value="gradient-down" ${o.fillType==='gradient-down'?'selected':''}>グラデーション(上から下へ)</option><option value="gradient-up" ${o.fillType==='gradient-up'?'selected':''}>グラデーション(下から上へ)</option><option value="gradient-right-to-left" ${o.fillType==='gradient-right-to-left'?'selected':''}>グラデーション(右から左へ)</option><option value="gradient-left-to-right" ${o.fillType==='gradient-left-to-right'?'selected':''}>グラデーション(左から右へ)</option><option value="gradient-center-vertical" ${o.fillType==='gradient-center-vertical'?'selected':''}>グラデーション(中央から上下へ)</option><option value="gradient-center-horizontal" ${o.fillType==='gradient-center-horizontal'?'selected':''}>グラデーション(中央から左右へ)</option><option value="gradient-radial" ${o.fillType==='gradient-radial'?'selected':''}>グラデーション(中央から上下左右へ)</option><option value="gradient-vertical-center" ${o.fillType==='gradient-vertical-center'?'selected':''}>グラデーション(上下から中央へ)</option><option value="gradient-horizontal-center" ${o.fillType==='gradient-horizontal-center'?'selected':''}>グラデーション(左右から中央へ)</option><option value="gradient-radial-in" ${o.fillType==='gradient-radial-in'?'selected':''}>グラデーション(上下左右から中央へ)</option></select></div>${o.type!=='segment'?`<div class="field opacity-control"><label>透過率：<span id="opacityValue">${Math.round(o.opacity)}</span>%</label><div class="coordinate-control"><input id="opacityInput" type="range" step="1" min="0" max="100" value="${Math.round(o.opacity)}"><input id="opacitySpin" type="number" min="0" max="100" step="1" value="${Math.round(o.opacity)}" aria-label="透過率"></div></div>`:''}</div>`:`<div class="property-color-fill-row"><div class="field"><label>カラー</label>${colorPickerMarkup('object',o.color,o.id)}</div></div>`):''}<div class="field coordinate-fields"><div><label for="objectX">X座標：<span id="objectXValue">${Math.round(o.x/100*(stage.clientWidth||640))}</span> px</label><div class="coordinate-control"><input id="objectX" type="range" min="0" max="${stage.clientWidth||640}" step="1" value="${Math.round(o.x/100*(stage.clientWidth||640))}"><input id="objectXSpin" type="number" min="0" max="${stage.clientWidth||640}" step="1" value="${Math.round(o.x/100*(stage.clientWidth||640))}" aria-label="X座標"></div></div><div><label for="objectY">Y座標：<span id="objectYValue">${Math.round(o.y/100*(stage.clientHeight||640))}</span> px</label><div class="coordinate-control"><input id="objectY" type="range" min="0" max="${stage.clientHeight||640}" step="1" value="${Math.round(o.y/100*(stage.clientHeight||640))}"><input id="objectYSpin" type="number" min="0" max="${stage.clientHeight||640}" step="1" value="${Math.round(o.y/100*(stage.clientHeight||640))}" aria-label="Y座標"></div></div></div>${o.type==='text'?`<div class="field"><label>テキスト</label><textarea id="textContentInput" rows="3" placeholder="テキストを入力">${esc(o.label||'')}</textarea><label>幅：<span id="textWidthValue">${Math.round(o.width||180)}</span> px</label><div class="coordinate-control"><input id="textWidthInput" type="range" step="1" min="20" max="960" value="${Math.round(o.width||180)}"><input id="textWidthSpin" type="number" min="20" max="960" step="1" value="${Math.round(o.width||180)}" aria-label="テキスト幅"></div></div>${propertyNumberFieldMarkup({label:"文字サイズ",rangeId:"textSizeInput",numberId:"textSizeSpin",valueId:"textSizeValue",value:Math.round(o.fontSize||12),unit:" px",min:"8",max:"640",step:"1",numberLabel:"文字サイズ"})}`:''}${isIcon?`${propertyNumberFieldMarkup({label:"サイズ",rangeId:"iconSizeInput",numberId:"iconSizeSpin",valueId:"iconSizeValue",value:Math.round(o.width),unit:" px",min:"24",max:"640",step:"1",numberLabel:"アイコンサイズ"})}`:''}${isBossIcon?`<div class="field"><label>色</label>${colorPickerMarkup('object',o.color,o.id)}</div><div class="field opacity-control"><label>透過率：<span id="bossOpacityValue">${Math.round(o.opacity)}</span>%</label><div class="coordinate-control"><input id="bossOpacityInput" type="range" step="1" min="0" max="100" value="${Math.round(o.opacity)}"><input id="bossOpacitySpin" type="number" min="0" max="100" step="1" value="${Math.round(o.opacity)}" aria-label="透過率"></div></div>${propertyNumberFieldMarkup({label:"回転",rangeId:"bossRotationInput",numberId:"bossRotationSpin",valueId:"bossRotationValue",value:Math.round(o.rotation||0),unit:"°",min:"-180",max:"180",step:"1",numberLabel:"回転"})}`:''}${o.type==='donut'?`${propertyNumberFieldMarkup({label:"内円の直径",rangeId:"donutInnerInput",numberId:"donutInnerSpin",valueId:"donutInnerValue",value:Math.round(donutInnerDiameter(o)),unit:" px",min:"0",max:donutMaxInnerDiameter(o),step:"1",numberLabel:"内円の直径"})}`:''}${isShape?`${propertyNumberFieldMarkup({label:o.type==='segment'?'長さ':'X軸方向の幅',rangeId:"widthInput",numberId:"widthSpin",valueId:"widthValue",value:Math.round(o.width),unit:" px",min:minimumShapeDimension(o,'width'),max:"960",step:"1",numberLabel:o.type==='segment'?'長さ':'X軸方向の幅'})}${o.type!=='segment'?`${propertyNumberFieldMarkup({label:"Y軸方向の高さ",rangeId:"heightInput",numberId:"heightSpin",valueId:"heightValue",value:Math.round(o.height),unit:" px",min:"20",max:"960",step:"1",numberLabel:"Y軸方向の高さ"})}`:''}${!['aoe','circle','donut','line','gaze','segment'].includes(o.type)?`${propertyNumberFieldMarkup({label:"透過率",rangeId:"opacityInput",numberId:"opacitySpin",valueId:"opacityValue",value:Math.round(o.opacity),unit:"%",min:"0",max:"100",step:"1",numberLabel:"透過率"})}`:''}${!['aoe','circle','donut','line','gaze','segment'].includes(o.type)?`<div class="field"><label>塗りつぶし効果</label><select id="fillInput"><option value="solid" ${o.gradient?'':'selected'}>単色</option><option value="gradient" ${o.gradient?'selected':''}>グラデーション</option></select></div>`:''}<div class="field"><label>傾き：<span id="rotationValue">${Math.round(o.rotation)}</span>°</label><div class="coordinate-control"><input id="rotationInput" type="range" step="1" min="-180" max="180" value="${Math.round(o.rotation)}"><input id="rotationSpin" type="number" min="-180" max="180" step="1" value="${Math.round(o.rotation)}" aria-label="傾き"></div></div>`:''}`;if(isAoeIcon){let field=document.createElement('div');field.className='field';let label=document.createElement('label');label.textContent='透過率：';let value=document.createElement('span');value.id='aoeIconOpacityValue';value.textContent=String(Number.isFinite(o.opacity)?o.opacity:100);label.append(value,document.createTextNode('%'));field.appendChild(label);let controls=document.createElement('div');controls.className='coordinate-control';let range=document.createElement('input'),spin=document.createElement('input');range.id='aoeIconOpacityRange';range.type='range';range.min='0';range.max='100';range.value=value.textContent;range.setAttribute('aria-label','AoE円範囲アイコンの透過率');spin.id='aoeIconOpacitySpin';spin.type='number';spin.min='0';spin.max='100';spin.step='1';spin.value=value.textContent;spin.setAttribute('aria-label','AoE円範囲アイコンの透過率');controls.append(range,spin);field.appendChild(controls);let anchor=el.querySelector('.coordinate-fields');el.insertBefore(field,anchor);let setOpacity=e=>{let v=Math.max(0,Math.min(100,Math.round(Number(e.target.value)||0)));o.opacity=v;o.aoeOpacityInitialized=true;range.value=spin.value=v;value.textContent=v;let image=layer.querySelector('[data-id='+String.fromCharCode(34)+o.id+String.fromCharCode(34)+'] img');if(image)image.style.opacity=String(v/100);save()};range.addEventListener('pointerdown',()=>{recordHistory()});range.addEventListener('input',setOpacity);spin.addEventListener('input',setOpacity)}$("#objectX").oninput=e=>{if(!e.target.dataset.historyPushed){recordHistory();e.target.dataset.historyPushed="true"}let size=stage.clientWidth||640,px=Number(e.target.value);o.x=px/size*100;$("#objectXValue").textContent=px;$("#objectXSpin").value=px;let obj=Array.from(layer.children).find(node=>node.dataset.id===o.id);if(obj)obj.style.left=o.x+"%";let box=controls.querySelector(".controlbox");if(box)box.style.left=o.x+"%";save()};$("#objectX").onchange=e=>delete e.target.dataset.historyPushed;$("#objectY").oninput=e=>{if(!e.target.dataset.historyPushed){recordHistory();e.target.dataset.historyPushed="true"}let size=stage.clientHeight||640,px=Number(e.target.value);o.y=px/size*100;$("#objectYValue").textContent=px;$("#objectYSpin").value=px;let obj=Array.from(layer.children).find(node=>node.dataset.id===o.id);if(obj)obj.style.top=o.y+"%";let box=controls.querySelector(".controlbox");if(box)box.style.top=o.y+"%";save()};$("#objectY").onchange=e=>delete e.target.dataset.historyPushed;$("#objectXSpin").oninput=e=>{if(!e.target.dataset.historyPushed){recordHistory();e.target.dataset.historyPushed="true"}let size=stage.clientWidth||640,px=Math.max(0,Math.min(size,Math.round(Number(e.target.value)||0)));e.target.value=px;$("#objectX").value=px;$("#objectXValue").textContent=px;o.x=px/size*100;let obj=Array.from(layer.children).find(node=>node.dataset.id===o.id);if(obj)obj.style.left=o.x+"%";let box=controls.querySelector(".controlbox");if(box)box.style.left=o.x+"%";save()};$("#objectXSpin").onchange=e=>delete e.target.dataset.historyPushed;$("#objectYSpin").oninput=e=>{if(!e.target.dataset.historyPushed){recordHistory();e.target.dataset.historyPushed="true"}let size=stage.clientHeight||640,px=Math.max(0,Math.min(size,Math.round(Number(e.target.value)||0)));e.target.value=px;$("#objectY").value=px;$("#objectYValue").textContent=px;o.y=px/size*100;let obj=Array.from(layer.children).find(node=>node.dataset.id===o.id);if(obj)obj.style.top=o.y+"%";let box=controls.querySelector(".controlbox");if(box)box.style.top=o.y+"%";save()};$("#objectYSpin").onchange=e=>delete e.target.dataset.historyPushed;updateStateToggleTooltip($("#visibleInput"),"visible");updateStateToggleTooltip($("#editableInput"),"locked");$("#visibleInput").onchange=e=>{recordHistory();o.visible=e.target.checked;renderAndSave()};$("#editableInput").onchange=e=>{setObjectState([o.id],'locked',!e.target.checked)};if(o.locked){el.querySelectorAll("input:not(#visibleInput):not(#editableInput),select,button[data-color-trigger]").forEach(control=>control.disabled=true)}if(o.type==='text'){$('#textContentInput').onchange=e=>{recordHistory();o.label=e.target.value;renderAndSave()};let textWidth=$('#textWidthInput'),textWidthSpin=$('#textWidthSpin'),textWidthBox=controls.querySelector('.controlbox');let saveWidth=()=>{let width=Math.max(20,Math.min(960,Math.round(Number(textWidth.value)||180)));o.width=width;resizeTextFromData(o);textWidth.value=textWidthSpin.value=width;$('#textWidthValue').textContent=width;let textEl=layer.querySelector(`[data-id="${o.id}"]`);if(textEl){textEl.style.width=width+'px';if(textWidthBox)textWidthBox.style.height=textEl.offsetHeight+'px'}if(textWidthBox)textWidthBox.style.width=width+'px';save()};textWidth.onpointerdown=()=>{recordHistory()};textWidthSpin.onfocus=()=>{recordHistory()};textWidth.oninput=saveWidth;textWidthSpin.onchange=()=>{textWidth.value=textWidthSpin.value;saveWidth()};$('#textSizeInput').onpointerdown=()=>recordHistory();$('#textSizeInput').oninput=e=>{o.fontSize=Math.round(Number(e.target.value));resizeTextFromData(o);$('#textSizeValue').textContent=Math.round(o.fontSize);let textEl=layer.querySelector(`[data-id="${o.id}"]`);if(textEl)textEl.style.fontSize=o.fontSize+'px';save()}}if(isIcon){
 const range=$('#iconSizeInput'),spin=$('#iconSizeSpin');
 range.onpointerdown=()=>recordHistory();
 range.oninput=e=>{
  if(boardReadOnly||o.locked)return;
  const value=Math.round(Number(e.target.value));range.value=spin.value=value;$('#iconSizeValue').textContent=value;
  if(o.width===value&&o.height===value)return;
  o.width=o.height=value;updateShapeFromData(o);
 };
}if(isBossIcon){for(let [input,key,value] of [['bossOpacityInput','opacity','bossOpacityValue'],['bossRotationInput','rotation','bossRotationValue']]){let range=$('#'+input),spin=$('#'+input.replace('Input','Spin'));let applyBossValue=()=>{let v=Math.round(Number(range.value));o[key]=v;spin.value=v;$('#'+value).textContent=v;let iconEl=layer.querySelector(`[data-id="${o.id}"]`),img=iconEl?.querySelector('img');if(key==='opacity'&&img)img.style.opacity=String(v/100);if(key==='rotation')updateShapeFromData(o,false);save()};range.onpointerdown=()=>{recordHistory()};spin.onfocus=()=>{recordHistory()};range.oninput=applyBossValue;spin.onchange=()=>{range.value=spin.value;applyBossValue()}}}if(o.type==='donut'){const range=$('#donutInnerInput'),spin=$('#donutInnerSpin');const apply=e=>{setDonutInnerDiameter(o,e.target.value);syncDonutInnerInputs(o);updateShapeFromData(o)};for(const input of [range,spin]){input.onfocus=()=>{recordHistory()};input.oninput=apply}}if(isShape){for(let [input,key,value] of [['widthInput','width','widthValue'],['heightInput','height','heightValue'],['opacityInput','opacity','opacityValue'],['rotationInput','rotation','rotationValue']]){if(input==='heightInput'&&o.type==='segment')continue;$('#'+input).onpointerdown=()=>recordHistory();$('#'+input).oninput=e=>{let v=o.type==='image'?Number(e.target.value):Math.round(Number(e.target.value));if(o.type==='image'&&(key==='width'||key==='height')){const size=proportionalDimensions(o,key==='width'?v:v*o.width/o.height);Object.assign(o,size);for(const axis of ['width','height']){$('#'+axis+'Input').value=$('#'+axis+'Spin').value=o[axis];$('#'+axis+'Value').textContent=Math.round(o[axis]*100)/100}}else if((o.type==='targetcircle'||['stack','linestack'].includes(o.type))&&(key==='width'||key==='height')){const factor=Math.max(Math.max(20/o.width,20/o.height),Math.min(Math.min(960/o.width,960/o.height),v/o[key]));o.width=integerTargetCircleSize(o.width*factor);o.height=integerTargetCircleSize(o.height*factor);for(const axis of ['width','height']){$('#'+axis+'Input').value=o[axis];$('#'+axis+'Spin').value=o[axis];$('#'+axis+'Value').textContent=o[axis]}}else if(['circle','donut','knockback','lineknockback'].includes(o.type)&&(key==='width'||key==='height')){o.width=o.height=v;$('#widthInput').value=v;$('#heightInput').value=v;$('#widthValue').textContent=v;$('#heightValue').textContent=v;$('#widthSpin').value=v;$('#heightSpin').value=v}else o[key]=v;$('#'+value).textContent=Math.round(o[key]);updateShapeFromData(o)}}if(['circle','donut','aoe','line','gaze','segment'].includes(o.type))$('#fillInput').onchange=e=>{recordHistory();o.fillType=e.target.value;o.gradient=o.fillType.startsWith('gradient');updateShapeFromData(o)}}addTowerColorSetting(el,o);addSpecialIconOpacitySetting(el,o);addObjectRotationSetting(el,o);hideUnusedObjectSettings(el,o);unifyProportionalSize(el,o);showLockedSelectionHint(el,[o]);bindSegmentSettings(el,[o]);organizeInspectorFields(el)}

function stackControlBounds(o){const side=Math.min(o.width,o.height);return {left:(o.width-side)/2+side*.06,top:(o.height-side)/2+side*.06,width:side*.88,height:side*.88}}

function fitStackSelection(o,el){const b=stackControlBounds(o);for(const key of ['left','top','width','height'])el.style.setProperty('--stack-selection-'+key,b[key]+'px')}

function fitStackControl(o,box){const frame=box.querySelector('.stack-control-frame');if(!frame)return;const b=stackControlBounds(o);for(const key of ['left','top','width','height'])frame.style[key]=b[key]+'px'}

function linearStackMarkup(id,color='#ff6a00'){const original=Array.from({length:4},(_,i)=>'<path d="M38 12L50 20L62 12M38 23L50 32L62 23" transform="rotate('+i*90+' 50 50)"/>').join(''),arrows=[22,50,78].map(y=>'<path d="M12 '+(y-10)+'L20 '+y+'L12 '+(y+10)+'M23 '+(y-10)+'L31 '+y+'L23 '+(y+10)+'M88 '+(y-10)+'L80 '+y+'L88 '+(y+10)+'M77 '+(y-10)+'L69 '+y+'L77 '+(y+10)+'"/>').join('');return stackMarkup('linear-'+id,color).split(original).join(arrows)}

function stackMarkup(id,color='#ff6a00'){const k='stack-'+String(id).replace(/[^a-zA-Z0-9_-]/g,'');const arrows=Array.from({length:4},(_,i)=>'<path d="M38 12L50 20L62 12M38 23L50 32L62 23" transform="rotate('+i*90+' 50 50)"/>').join('');return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" aria-hidden="true"><defs><filter id="'+k+'" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="2.8"/></filter></defs><g fill="none" stroke-linejoin="miter" stroke-linecap="square"><g stroke="'+color+'" stroke-width="11" filter="url(#'+k+')">'+arrows+'</g><g stroke="'+color+'" stroke-width="8">'+arrows+'</g><g stroke="#fff4bf" stroke-width="3.5">'+arrows+'</g></g><path d="M43 45L50 49L57 45L50 58Z" fill="'+color+'" stroke="'+color+'" stroke-width="4" filter="url(#'+k+')"/><path d="M43 45L50 49L57 45L50 58Z" fill="#ffd33e" stroke="#ff8b0c" stroke-width="1.5"/><path d="M43 45L50 50L57 45M46 50L50 55L54 50" fill="none" stroke="#fff7be" stroke-width="1.5"/></svg>'}

function gazeMarkup(id){const k='gaze-'+String(id).replace(/[^a-zA-Z0-9_-]/g,'');const rays=Array.from({length:18},(_,i)=>{const a=i*Math.PI*2/18,c=Math.cos(a),sn=Math.sin(a),r=i%3===0?64:54,cx=100,cy=65,x=cx+c*38,y=cy+sn*23;return '<path class="gaze-hit" d="M'+(x-sn*2.4)+' '+(y+c*2.4)+'L'+(cx+c*r*1.45)+' '+(cy+sn*r)+'L'+(x+sn*2.4)+' '+(y-c*2.4)+'Z"/>'}).join('');return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 130" preserveAspectRatio="none" aria-hidden="true"><defs><radialGradient id="'+k+'-aura"><stop stop-color="#f81b76" stop-opacity=".85"/><stop offset=".6" stop-color="#ef4198" stop-opacity=".45"/><stop offset="1" stop-color="#ec489a" stop-opacity="0"/></radialGradient><radialGradient id="'+k+'-eye"><stop stop-color="#dd251e"/><stop offset=".38" stop-color="#7b080b"/><stop offset="1" stop-color="#150007"/></radialGradient><filter id="'+k+'-glow" x="-50%" y="-100%" width="200%" height="300%"><feGaussianBlur stdDeviation="4"/></filter></defs><ellipse cx="100" cy="65" rx="76" ry="62" fill="url(#'+k+'-aura)"/><g fill="#df338b" opacity=".75">'+rays+'</g><path d="M42 65Q100 10 158 65Q100 117 42 65Z" fill="#ed0755" filter="url(#'+k+'-glow)"/><path class="gaze-hit" d="M42 65Q100 12 158 65Q100 115 42 65Z" fill="url(#'+k+'-eye)" stroke="#ac0731" stroke-width="4"/><ellipse cx="100" cy="64" rx="14" ry="16" fill="#ff4025" filter="url(#'+k+'-glow)"/><ellipse cx="100" cy="64" rx="11" ry="13" fill="#ffffed"/></svg>'}

function circleOutsideFraction(cx,cy,radius,width,height){if(radius<=0)return 0;if(cx-radius>=0&&cx+radius<=width&&cy-radius>=0&&cy+radius<=height)return 0;let left=Math.max(-radius,-cx),right=Math.min(radius,width-cx);if(right<=left)return 1;let slices=256,step=(right-left)/slices,area=0;for(let i=0;i<slices;i++){let x=left+(i+.5)*step,half=Math.sqrt(Math.max(0,radius*radius-x*x));area+=Math.max(0,Math.min(height,cy+half)-Math.max(0,cy-half))*step}return Math.max(0,Math.min(1,1-area/(Math.PI*radius*radius)))}

function targetCircleOuterBounds(o,width,height){
 const side=Math.min(o.width||110,o.height||110),a=(o.rotation||0)*Math.PI/180,cy=82-Math.sqrt(37*37-25*25),offset=(cy-50)/100*side,cx=o.x/100*width-offset*Math.sin(a),centerY=o.y/100*height+offset*Math.cos(a),radius=side*.37,padding=side*.02;
 const end=Math.atan2(82-cy,25),angles=[end,Math.PI-end];for(const cardinal of [0,Math.PI/2,Math.PI,Math.PI*1.5]){const local=((cardinal-a)%(2*Math.PI)+2*Math.PI)%(2*Math.PI);if(local<=end||local>=Math.PI-end)angles.push(local)}
 const points=angles.map(theta=>({x:cx+radius*Math.cos(theta+a),y:centerY+radius*Math.sin(theta+a)}));return {left:Math.min(...points.map(p=>p.x))-padding,right:Math.max(...points.map(p=>p.x))+padding,top:Math.min(...points.map(p=>p.y))-padding,bottom:Math.max(...points.map(p=>p.y))+padding};
}

function targetCircleTriangleInside(o){
 const width=layer.clientWidth||stage.clientWidth||640,height=layer.clientHeight||stage.clientHeight||640,shape=activeBoardShape(),b=targetCircleOuterBounds(o,width,height);
 if(shape==='none')return b.left<-.000001||b.top<-.000001||b.right>width+.000001||b.bottom>height+.000001;
 const size=data.pageFieldSizes?.[data.page]||{width:538,height:shape==='landscape'?320:538},fw=size.width/640*width,fh=size.height/640*height,left=(width-fw)/2,top=(height-fh)/2;
 if(shape!=='circle')return b.left<left-.000001||b.top<top-.000001||b.right>left+fw+.000001||b.bottom>top+fh+.000001;
 const side=Math.min(o.width||110,o.height||110),rotation=(o.rotation||0)*Math.PI/180,cy=82-Math.sqrt(37*37-25*25),offset=(cy-50)/100*side,cx=o.x/100*width-offset*Math.sin(rotation),centerY=o.y/100*height+offset*Math.cos(rotation),radius=side*.37,padding=side*.02,end=Math.atan2(82-cy,25),rx=fw/2,ry=fh/2;
 // Test the visible arc, excluding its open bottom, against the round field.
 for(let i=0;i<=128;i++){const angle=Math.PI-end+(Math.PI+2*end)*i/128+rotation,dx=(cx+radius*Math.cos(angle)-width/2)/rx,dy=(centerY+radius*Math.sin(angle)-height/2)/ry;if(Math.hypot(dx,dy)+padding/Math.min(rx,ry)>1.000001)return true}
 return false
}

function refreshTargetCircleTriangle(o,el){let inside=targetCircleTriangleInside(o);if(el.dataset.triangleInside!==String(inside)){el.innerHTML=targetCircleMarkup(o,inside);el.dataset.triangleInside=String(inside)}fitTargetCircleSelection(o,el);let box=controls.querySelector('.targetcircle-control');if(selected===o.id&&box)fitTargetCircleControl(o,box)}

function targetCircleTriangleSize(width,height){let size=Math.max(110,Math.min(width||110,height||110));return 10*Math.pow(110/size,0.35)}

function targetCircleControlBounds(width,height,inside=false){let scale=Math.min(width,height)/100,top=82-Math.sqrt(37*37-25*25)-37-(inside?2:1+targetCircleTriangleSize(width,height)),padding=2;return {left:(width-scale*100)/2+11*scale-padding,top:(height-scale*100)/2+top*scale-padding,width:78*scale+padding*2,height:(84-top)*scale+padding*2}}

function fitTargetCircleSelection(o,el){
 if(!el.classList.contains('selected-many'))return;
 let box=Array.from(controls.querySelectorAll('.targetcircle-multi-control')).find(node=>node.dataset.objectId===o.id);
 if(!box){box=document.createElement('div');box.className='targetcircle-multi-control';box.dataset.objectId=o.id;box.setAttribute('aria-hidden','true');box.style.border='0';box.style.pointerEvents='none';const frame=document.createElement('div');frame.className='targetcircle-selection-frame';box.appendChild(frame);controls.appendChild(box)}
 box.style.left=o.x+'%';box.style.top=o.y+'%';box.style.width=(o.width||110)+'px';box.style.height=(o.height||110)+'px';box.style.setProperty('--rot',(o.rotation||0)+'deg');
 box.classList.toggle('group-member-selection',!!o.objectGroupId&&!individualGroupSelectionActive());const frame=box.querySelector('.targetcircle-selection-frame'),bounds=targetCircleControlBounds(o.width||110,o.height||110,targetCircleTriangleInside(o));for(const key of ['left','top','width','height'])frame.style[key]=bounds[key]+'px';
}

function fitTargetCircleControl(o,box){let frame=box.querySelector('.targetcircle-control-frame');if(!frame)return;let bounds=targetCircleControlBounds(o.width||110,o.height||110,targetCircleTriangleInside(o));for(let key of ['left','top','width','height'])frame.style[key]=bounds[key]+'px'}

function targetCircleMarkup(o,inside=targetCircleTriangleInside(o)){let triangleSize=targetCircleTriangleSize(o.width,o.height),outerRadius=37,innerRadius=33,centerY=82-Math.sqrt(outerRadius*outerRadius-25*25),triangleBase=centerY-outerRadius+(inside?triangleSize+1:-1),innerX=25*innerRadius/outerRadius,innerY=centerY+(82-centerY)*innerRadius/outerRadius;return '<svg viewBox="0 0 100 100" aria-hidden="true"><circle class="targetcircle-hit" cx="50" cy="'+centerY+'" r="39" fill="transparent"/><path d="M25 82 A37 37 0 1 1 75 82" fill="none" stroke="'+o.color+'" stroke-width="4"/><path d="M'+(50-innerX)+' '+innerY+' A'+innerRadius+' '+innerRadius+' 0 1 1 '+(50+innerX)+' '+innerY+'" fill="none" stroke="'+o.color+'" stroke-width="2"/><path d="M50 '+(triangleBase-triangleSize)+' L'+(50-triangleSize/2)+' '+triangleBase+' L'+(50+triangleSize/2)+' '+triangleBase+' Z" fill="'+o.color+'"/></svg>'}

function segmentGeometry(o){
 const width=Math.max(20,Number(o.width)||100),thickness=Math.max(1,Number(o.height)||4),y=thickness/2;
 const path='M0 '+y+' L'+width+' '+y;
 const head=Math.min(14,width/3),half=head*.5,arrows=[];
 function arrow(x,angle){const dx=Math.cos(angle),dy=Math.sin(angle),bx=x-head*dx,by=y-head*dy;arrows.push([[x,y],[bx-half*dy,by+half*dx],[bx+half*dy,by-half*dx]].map(p=>p.join(',')).join(' '))}
 if(o.arrowEnds==='end'||o.arrowEnds==='both')arrow(width,0);
 if(o.arrowEnds==='start'||o.arrowEnds==='both')arrow(0,Math.PI);
 return {width,thickness,path,arrows}
}

function renderSegmentVisual(visual,o){
 const legacy=o.lineStyle!=='dashed'&&!['start','end','both'].includes(o.arrowEnds);
 visual.style.background=legacy?o.color:'transparent';visual.style.overflow='visible';visual.replaceChildren();
 if(legacy)return;
 const ns='http://www.w3.org/2000/svg',g=segmentGeometry(o),svg=document.createElementNS(ns,'svg');
 svg.setAttribute('viewBox','0 0 '+g.width+' '+g.thickness);svg.setAttribute('width',g.width);svg.setAttribute('height',g.thickness);svg.style.cssText='display:block;width:100%;height:100%;overflow:visible;pointer-events:none';
 const path=document.createElementNS(ns,'path');path.setAttribute('d',g.path);path.setAttribute('fill','none');path.setAttribute('stroke',o.color);path.setAttribute('stroke-width',g.thickness);path.setAttribute('stroke-linecap','butt');path.style.pointerEvents='stroke';
 if(o.lineStyle==='dashed')path.setAttribute('stroke-dasharray',(g.thickness*3)+' '+(g.thickness*2));svg.append(path);
 for(const points of g.arrows){const polygon=document.createElementNS(ns,'polygon');polygon.setAttribute('points',points);polygon.setAttribute('fill',o.color);polygon.style.pointerEvents='visiblePainted';svg.append(polygon)}visual.append(svg)
}

function bindSegmentSettings(el,items){
 if(!items.length||!items.every(o=>o.type==='segment'))return;
 const editable=items.filter(o=>!o.locked),first=items[0];
 function field(label){const row=document.createElement('div');row.className='field';const title=document.createElement('label');title.textContent=label;row.append(title);el.append(row);return row}
 function apply(key,value){if(boardReadOnly||!editable.length)return;recordHistory();for(const o of editable){o[key]=value;updateShapeFromData(o)}save()}
 for(const [key,label,options,fallback] of [
  ['lineStyle','線の種類',[['solid','実線'],['dashed','破線']],'solid'],
  ['arrowEnds','矢印',[['none','なし'],['start','始点'],['end','終点'],['both','両端']],'none']
 ]){const row=field(label),select=document.createElement('select');select.id='segment-'+key;select.setAttribute('aria-label',label);for(const [value,text] of options){const option=document.createElement('option');option.value=value;option.textContent=text;select.append(option)}const mixed=items.some(o=>(o[key]||fallback)!==(first[key]||fallback));if(mixed){const option=document.createElement('option');option.value='';option.textContent='複数の値';select.prepend(option)}select.value=mixed?'':first[key]||fallback;select.disabled=boardReadOnly||!editable.length;select.onchange=()=>{if(!select.value)return;apply(key,select.value)};row.append(select)}
}

function applyShapeStyle(el,o){if(o.type==='image'){const image=el.querySelector('img');if(image)image.style.opacity=String(Math.max(0,Math.min(100,o.opacity??100))/100);return}if(o.type==='gaze'){el.style.background='transparent';el.style.backgroundImage='none';el.style.border='0';el.style.opacity='1';const svg=el.querySelector('svg');if(svg)svg.style.opacity=String(additionalOpacityValue(o)/100);return}if(o.type==='donut'){let visual=el.querySelector('.donut-visual');if(!visual){visual=document.createElement('div');visual.className='donut-visual';el.appendChild(visual)}applyShapeStyle(visual,{...o,type:'circle'});const inner=donutInnerRadius(o)/(Math.hypot(o.width,o.height)/2)*100;visual.style.maskImage=visual.style.webkitMaskImage='radial-gradient(circle, transparent 0 '+inner+'%, black '+(inner+.5)+'%)';let innerBorder=el.querySelector('.donut-inner-border');if(!innerBorder){innerBorder=document.createElement('div');innerBorder.className='donut-inner-border';el.appendChild(innerBorder)}const diameter=donutInnerDiameter(o),opacity=Math.max(0,Math.min(100,Number.isFinite(Number(o.opacity))?Number(o.opacity):30));innerBorder.style.display=diameter>0?'block':'none';innerBorder.style.width=innerBorder.style.height=(diameter+6)+'px';innerBorder.style.borderColor='color-mix(in srgb, '+(o.strokeColor||o.color)+' '+opacity+'%, transparent)';let outerBorder=el.querySelector('.donut-outer-border');if(!outerBorder){outerBorder=document.createElement('div');outerBorder.className='donut-outer-border';el.appendChild(outerBorder)}outerBorder.style.borderColor=innerBorder.style.borderColor;el.style.maskImage=el.style.webkitMaskImage='none';el.style.background='transparent';el.style.backgroundImage='none';el.style.borderColor='transparent';el.style.opacity='1';return}if((['knockback','lineknockback'].includes(o.type))||['stack','linestack'].includes(o.type)){el.style.background='transparent';el.style.backgroundImage='none';el.style.border='0';el.style.opacity='1';const visual=el.querySelector('svg');if(visual)visual.style.opacity=String(Math.max(0,Math.min(100,Number.isFinite(Number(o.opacity))?Number(o.opacity):100))/100);return}if(o.type==='segment'){let visual=el.querySelector('.segment-visual');if(!visual){visual=document.createElement('div');visual.className='segment-visual';el.appendChild(visual)}renderSegmentVisual(visual,o);visual.style.opacity=String(Math.max(0,Math.min(100,Number.isFinite(Number(o.opacity))?Number(o.opacity):50))/100);el.style.border='0';el.style.background='transparent';el.style.backgroundImage='none';el.style.opacity='1';return}let opacity=Math.max(0,Math.min(100,Number.isFinite(Number(o.opacity))?Number(o.opacity):30)),fillType=o.fillType||(o.gradient?'gradient':'solid'),fillColor=`color-mix(in srgb, ${o.color} ${opacity}%, transparent)`,angle=fillType==='gradient-down'?'180deg':fillType==='gradient-up'?'0deg':fillType==='gradient-right-to-left'?'270deg':(fillType==='gradient-center-vertical'||fillType==='gradient-vertical-center')?'180deg':'90deg';el.style.opacity='1';el.style.borderColor=fillColor;el.style.backgroundImage='none';el.style.backgroundSize='';el.style.background=fillType==='gradient-radial'?`radial-gradient(ellipse, ${fillColor}, transparent)`:fillType==='gradient-radial-in'?`radial-gradient(ellipse, transparent, ${fillColor})`:fillType==='gradient-vertical-center'?`linear-gradient(${angle}, ${fillColor}, transparent 50%, ${fillColor})`:fillType==='gradient-horizontal-center'?`linear-gradient(${angle}, ${fillColor}, transparent 50%, ${fillColor})`:fillType==='gradient-center-vertical'||fillType==='gradient-center-horizontal'?`linear-gradient(${angle}, transparent, ${fillColor} 50%, transparent)`:fillType.startsWith('gradient')?`linear-gradient(${angle}, ${fillColor}, transparent)`:fillColor;el.style.backgroundClip=(o.type==='line'||o.type==='circle'&&!el.classList.contains('donut-visual'))?'border-box':'padding-box';if(['circle','donut','line'].includes(o.type))el.style.borderColor=`color-mix(in srgb, ${o.strokeColor||o.color} ${opacity}%, transparent)`;if(o.type==='donut'){el.style.maskImage='radial-gradient(circle, transparent 0 28%, black 29%)';el.style.webkitMaskImage='radial-gradient(circle, transparent 0 28%, black 29%)'}if(o.type==='aoe'){el.style.borderColor='transparent';el.style.background='transparent';let svg=el.querySelector('svg'),p=el.querySelector('path');if(svg&&p){let ns='http://www.w3.org/2000/svg',defs=svg.querySelector('defs');if(!defs){defs=document.createElementNS(ns,'defs');svg.insertBefore(defs,svg.firstChild)}defs.innerHTML='';let id='fill-'+String(o.id).replace(/[^a-zA-Z0-9_-]/g,''),alpha=opacity/100;if(fillType.startsWith('gradient')){let radial=fillType==='gradient-radial'||fillType==='gradient-radial-in',g=document.createElementNS(ns,radial?'radialGradient':'linearGradient');g.id=id;if(!radial){let coords=fillType==='gradient-down'||fillType==='gradient-center-vertical'||fillType==='gradient-vertical-center'?['0%','0%','0%','100%']:fillType==='gradient-up'?['0%','100%','0%','0%']:fillType==='gradient-right-to-left'?['100%','0%','0%','0%']:['0%','0%','100%','0%'];['x1','y1','x2','y2'].forEach((key,i)=>g.setAttribute(key,coords[i]))}for(let [offset,op] of (fillType==='gradient-center-vertical'||fillType==='gradient-center-horizontal'?[['0%',0],['50%',alpha],['100%',0]]:fillType==='gradient-vertical-center'||fillType==='gradient-horizontal-center'?[['0%',alpha],['50%',0],['100%',alpha]]:fillType==='gradient-radial-in'?[['0%',0],['100%',alpha]]:[['0%',alpha],['100%',0]])){let stop=document.createElementNS(ns,'stop');stop.setAttribute('offset',offset);stop.setAttribute('stop-color',o.color);stop.setAttribute('stop-opacity',String(op));g.appendChild(stop)}defs.appendChild(g);p.style.fill=`url(#${id})`;p.style.fillOpacity='1'}else{p.style.fill=o.color;p.style.fillOpacity=String(fillType==='none'?0:alpha)}p.style.stroke=o.strokeColor||o.color;p.style.strokeOpacity=String(alpha)}}}

function aoeControlBounds(o){const g=aoeGeometry(o),extent=90*Math.sin(Math.min(g.rad,Math.PI/2));return {left:(50-extent)/100,top:Math.min(5,g.endY)/100,right:(50+extent)/100,bottom:.95}}

function fitAoeControl(o,box){const frame=box.querySelector('.aoe-control-frame');if(!frame)return;const b=aoeControlBounds(o),pad=3;frame.style.left=(b.left*o.width-pad)+'px';frame.style.top=(b.top*o.height-pad)+'px';frame.style.width=((b.right-b.left)*o.width+2*pad)+'px';frame.style.height=((b.bottom-b.top)*o.height+2*pad)+'px';const move=box.querySelector('.move-handle');if(move){move.style.left='calc('+((b.left+b.right)/2*o.width)+'px - 16px)';move.style.top='calc('+(b.bottom*o.height+pad)+'px + var(--rotation-handle-distance,70px) - 32px)'}const rotate=box.querySelector('.handle.rotate');if(rotate){rotate.style.left='calc('+((b.left+b.right)/2*o.width)+'px - var(--rotation-handle-size,12px)/2)';rotate.style.top='calc('+(b.top*o.height-pad)+'px - var(--rotation-handle-distance,40px))'}}

function minimumShapeDimension(o,key){return o.type==='line'&&key==='width'?10:20}

function integerTargetCircleSize(value){return Math.max(20,Math.min(960,Math.round(Number(value)||110)))}

function resizedAoeBox(start,dx,dy){
 const a=start.rotation*Math.PI/180,c=Math.cos(a),sn=Math.sin(a),lx=dx*c+dy*sn,ly=-dx*sn+dy*c;let width=start.width,height=start.height;const b=start.bounds||{left:0,top:0,right:1,bottom:1},spanX=b.right-b.left,spanY=b.bottom-b.top,visibleWidth=width*spanX,visibleHeight=height*spanY;
 if(start.sx&&start.sy){let factor=1+(lx*start.sx*visibleWidth+ly*start.sy*visibleHeight)/(visibleWidth*visibleWidth+visibleHeight*visibleHeight);factor=Math.max(Math.max((start.minSize||20)/width,(start.minSize||20)/height),Math.min(Math.min((start.maxSize||960)/width,(start.maxSize||960)/height),factor));width*=factor;height*=factor}
 else if(start.sx)width=Math.max(20,Math.min(960,start.width+start.sx*lx/spanX));else height=Math.max(20,Math.min(960,start.height+start.sy*ly/spanY));
 if(start.integerSize){width=integerTargetCircleSize(width);height=integerTargetCircleSize(height)}
 const shiftX=start.sx?-(start.sx>0?b.left-.5:b.right-.5)*(width-start.width):0,shiftY=start.sy?-(start.sy>0?b.top-.5:b.bottom-.5)*(height-start.height):0;return {width,height,dx:shiftX*c-shiftY*sn,dy:shiftX*sn+shiftY*c};
}

function resizeTextFromData(o){if(o.type!=='text')return;const el=layer.querySelector('[data-id="'+o.id+'"]');if(!el)return;const before=el.getBoundingClientRect();el.style.width=(o.width||180)+'px';el.style.fontSize=(o.fontSize||12)+'px';const after=el.getBoundingClientRect(),board=stage.getBoundingClientRect();if(board.width&&board.height){o.x+=(before.left-after.left)/board.width*100;o.y+=(before.top-after.top)/board.height*100;el.style.left=o.x+'%';el.style.top=o.y+'%'}const box=controls.querySelector('.controlbox');if(box){box.style.left=o.x+'%';box.style.top=o.y+'%';box.style.width=(o.width||180)+'px';box.style.height=el.offsetHeight+'px'}}

function updateShapeFromData(o,saveAfter=true){if(o.type==='text')resizeTextFromData(o);let el=layer.querySelector(`[data-id="${o.id}"]`),box=Array.from(controls.querySelectorAll('.controlbox')).find(node=>node.dataset.id===o.id);if(el){if(['stack','linestack'].includes(o.type))fitStackSelection(o,el);if(o.type==='targetcircle'){el.innerHTML=targetCircleMarkup(o);fitTargetCircleSelection(o,el)}el.style.left=o.x+'%';el.style.top=o.y+'%';el.style.width=o.width+'px';el.style.height=o.type==='text'?'auto':o.height+'px';if(o.type==='icon'){if(hasAdditionalOpacity(o)){const img=el.querySelector('img');if(img)img.style.opacity=String(additionalOpacityValue(o)/100)}el.style.setProperty('--icon-size',o.width+'px');const badge=el.querySelector('.role-badge');if(badge){badge.style.setProperty('font-size',Math.max(8,o.width*.36)+'px','important');badge.style.right=(o.width*.06)+'px';badge.style.bottom=(o.height*.06)+'px';badge.style.webkitTextStroke=(o.width*.03)+'px #111'}}el.style.setProperty('--rot',(o.rotation||0)+'deg');el.style.transform='translate(-50%,-50%) rotate('+(o.rotation||0)+'deg)';if(o.type!=='icon'&&o.type!=='text'){el.style.setProperty('--rot',o.rotation+'deg');el.style.transform='translate(-50%,-50%) rotate('+(o.rotation||0)+'deg)';applyShapeStyle(el,o)}}if(box){box.style.left=o.x+'%';box.style.top=o.y+'%';box.style.width=o.width+'px';box.style.height=o.type==='text'?el.offsetHeight+'px':o.height+'px';box.style.setProperty('--rot',(o.rotation||0)+'deg');if(o.type==='targetcircle')fitTargetCircleControl(o,box);if(['stack','linestack'].includes(o.type))fitStackControl(o,box)}if(o.type==='donut'){if(box)placeDonutInnerHandles(o,box);syncDonutInnerInputs(o);}if(o.type==='aoe'){let p=el?.querySelector('path');if(p)p.setAttribute('d',aoeGeometry(o).path);if(box){placeAoeAngleHandles(o,box);fitAoeControl(o,box)}}if(el)updateObjectTileClip(o,el);if(saveAfter)save()}

function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

function createPlacementObject(payload,x,y){if(payload.type==='image'){const native=payload.nativeSize||boardImageLibrary.dimensions(payload.imageId),scale=Math.min(1,640/Math.max(native.width,native.height));return {id:createObjectId(),type:'image',x,y,width:native.width*scale,height:native.height*scale,rotation:0,opacity:100,imageId:payload.imageId}}let type=payload.type,label="";let initialIconSize=payload.name==='大ボス'?72:payload.name==='中ボス'?60:payload.name==='小ボス'?48:['ロックオン赤','ロックオン緑','ロックオン紫','ロックオン青','ターゲット青'].includes(payload.name)?48:['距離減衰','フレア'].includes(payload.name)?128:payload.name==='AoE 円範囲'?48:32;let o={id:createObjectId(),type,x,y,color:['circle','donut','aoe','line','gaze','segment'].includes(type)?'#f39c12':(type==='targetcircle'||['stack','linestack'].includes(type)||(['knockback','lineknockback'].includes(type)))?'#ff6a00':color,label,width:type==='icon'?initialIconSize:110,height:type==='icon'?initialIconSize:110,opacity:(type==='targetcircle'||['stack','linestack'].includes(type)||(['knockback','lineknockback'].includes(type))||(type==='icon'&&['大ボス','中ボス','小ボス'].includes(payload.name)))?100:50,gradient:false,fillType:'solid',rotation:0,bossOpacityInitialized:['大ボス','中ボス','小ボス'].includes(payload.name)};if(type==='line'){o.width=100;o.height=200}if(type==='segment'){o.width=100;o.height=4}if(type==='text'){o.width=180;o.height=40}if(type==='gaze'){o.width=96;o.height=62}if(type==='icon'){o.iconName=payload.name;if(payload.imageId){boardImageLibrary.requireImage(payload.imageId);o.imageId=payload.imageId}else if(typeof payload.src==='string'&&payload.src.startsWith('data:image/'))o.imageId=boardImageLibrary.register(payload.src);else o.src=payload.src;o.iconBadge=payload.badge||'';if(payload.name==='距離減衰')o.opacity=100;if(payload.name==='AoE 円範囲'){o.opacity=50;o.aoeOpacityInitialized=true}}if(isBossObject(o)){o.color=bossDefaultColor(o.iconName);o.bossColorInitialized=true}if(isTowerObject(o)){o.color='#f39c12';o.width=o.height=96}return o}

function placeObject(payload,clientX,clientY){if(boardReadOnly)return;if(phaseComparisonActive())return;let r=stage.getBoundingClientRect(),x=(clientX-r.left)/r.width*100,y=(clientY-r.top)/r.height*100,type=payload.type;if(payload.userPresetId){userPresetLibrary.place(payload.userPresetId,x,y);return}if(payload.presetId==='field-markers'){placeBuiltinFieldMarkers(x,y);return}if(payload.presetId==='group-artwork'){placeBuiltinGroupArtwork(x,y);return}if(!['image','icon','circle','donut','aoe','line','gaze','segment','targetcircle','stack','linestack','knockback','lineknockback','text'].includes(type))return;if(type==='image'){if(!payload.imageId){if(!payload.originalSource)return;payload={...payload,imageId:boardImageLibrary.register(payload.originalSource,payload.nativeSize)};if(payload.previewSource){const value={...payload.nativeSize,preview:payload.previewSource};importedImageCache.set(payload.originalSource,{value,promise:Promise.resolve(value)})}}}let label='';snapshot();let o=createPlacementObject(payload,x,y);let placement=placementAlignment(payload,clientX,clientY,placementShiftDisabled,false);o.x=placement.x;o.y=placement.y;current().push(o);selected=o.id;selectedIds=[o.id];renderAndSave();if(type==='text'){let textElement=layer.querySelector('[data-id=\"'+o.id+'\"]');if(textElement)editText(o,textElement)}}

function showTouchPlacementPreview(payload,x,y,offsetY=96){
 hideTouchPlacementPreview();const preview=document.createElement('div');preview.className='touch-placement-preview';
 if(payload.userPresetId){const thumb=userPresetLibrary.thumbnail(payload.userPresetId);if(thumb)preview.append(thumb)}else if(payload.presetId==='group-artwork'){preview.append(createPresetArtworkThumbnail(phaseGroupArtworkData.objects))}else if(payload.presetId==='field-markers'){const thumb=document.querySelector('#builtinFieldMarkers .preset-thumbnail');if(thumb){const copy=thumb.cloneNode(true);copy.style.cssText='display:block;position:relative;width:32px;height:32px';for(const img of copy.querySelectorAll('img'))img.style.cssText+=';position:absolute;width:10px;height:10px;transform:translate(-50%,-50%)';preview.append(copy)}}else if(payload.type==='image'){const img=document.createElement('img');img.src=payload.previewSource||importedImageCache.get(boardImageLibrary.get(payload.imageId))?.value?.preview||emptyImportedImage;img.alt='';preview.append(img)}else if(payload.type==='icon'){const img=document.createElement('img');img.src=isTowerObject({type:'icon',iconName:payload.name})?towerIconSource({type:'icon',iconName:payload.name}):['大ボス','中ボス','小ボス'].includes(payload.name)?bossIconSource({iconName:payload.name,src:payload.src,color:bossDefaultColor(payload.name)}):objectImageSource(payload);img.alt='';preview.append(img)}else{const glyph=document.querySelector('.left .tool[data-tool="'+payload.type+'"] .glyph');if(glyph)preview.append(glyph.cloneNode(true))}
 document.body.append(preview);touchPlacementPreview=preview;moveTouchPlacementPreview(x,y,offsetY);
}

function moveTouchPlacementPreview(x,y,offsetY=96){if(touchPlacementPreview){touchPlacementPreview.style.left=x+'px';touchPlacementPreview.style.top=(y-offsetY)+'px'}}

function hideTouchPlacementPreview(){touchPlacementPreview?.remove();touchPlacementPreview=null}

function touchPlacementPoint(x,y){return {x,y:y-96}}

function finishTapPlacement(e){
 if(!tapPlacementGesture||tapPlacementGesture.id!==e.pointerId)return;
 const gesture=tapPlacementGesture;tapPlacementGesture=null;hideTouchPlacementPreview();e.preventDefault();e.stopImmediatePropagation();if(stage.hasPointerCapture(e.pointerId))stage.releasePointerCapture(e.pointerId);
 if(e.type==='pointercancel'||!gesture.touch&&Math.hypot(e.clientX-gesture.x,e.clientY-gesture.y)>10)return;const rect=stage.getBoundingClientRect();if(e.clientX<rect.left||e.clientX>rect.right||e.clientY<rect.top||e.clientY>rect.bottom)return;
 const payload=placementToolPayload();placementShiftDisabled=e.shiftKey;const point={x:e.clientX,y:e.clientY};placeObject(payload,point.x,point.y);setTapPlacementArmed(false);selectPlacementTool('select');placementShiftDisabled=false;
}

function closePaletteAfterPlacement(){const pane=document.querySelector('.left');if(pane.classList.contains('pinned'))return;pane.classList.remove('palette-opening-neutral');if(pane.contains(document.activeElement))document.activeElement.blur()}

let placementGuideFrame=null,placementGuidePoint=null,placementBoundsCache=null;
function cancelPlacementGuideFrame(){if(placementGuideFrame!==null)cancelAnimationFrame(placementGuideFrame);placementGuideFrame=null;placementGuidePoint=null}
function queuePlacementGuides(payload,x,y,disabled){placementGuidePoint={payload,x,y,disabled};if(placementGuideFrame!==null)return;placementGuideFrame=requestAnimationFrame(()=>{placementGuideFrame=null;const point=placementGuidePoint;placementGuidePoint=null;if(!point||placementDragPayload!==point.payload)return;const placement=placementAlignment(point.payload,point.x,point.y,point.disabled);clearAlignmentGuides();drawAlignmentGuides(placement.guides,stage.clientWidth,stage.clientHeight)})}
function placementAlignmentSnapshot(rect,width,height){if(!placementDragPayload)return alignmentSnapshot();const cached=placementBoundsCache;if(cached&&cached.board===data&&cached.page===current()&&cached.count===current().length&&cached.left===rect.left&&cached.top===rect.top&&cached.rectWidth===rect.width&&cached.rectHeight===rect.height&&cached.width===width&&cached.height===height)return cached.items;const items=alignmentSnapshot();placementBoundsCache={board:data,page:current(),count:current().length,left:rect.left,top:rect.top,rectWidth:rect.width,rectHeight:rect.height,width,height,items};return items}

function endPlacementGuides(){cancelPlacementGuideFrame();placementBoundsCache=null;placementDragPayload=null;placementShiftDisabled=false;stage.classList.remove('drag-over');clearAlignmentGuides()}

function movementAlignmentItems(items,movingIds){
 const moving=new Set(movingIds),groups=new Map(),consumed=new Set(),result=[];
 for(const item of items)if(item.objectGroupId){if(!groups.has(item.objectGroupId))groups.set(item.objectGroupId,[]);groups.get(item.objectGroupId).push(item)}
 for(const item of items){const members=groups.get(item.objectGroupId);if(!members||!members.every(o=>moving.has(o.id))){result.push(item);continue}if(consumed.has(item.objectGroupId))continue;consumed.add(item.objectGroupId);
  const bounds=members.map(o=>o.bounds).filter(Boolean);if(!bounds.length)continue;
  result.push({...item,visible:members.some(o=>o.visible!==false),bounds:{left:Math.min(...bounds.map(b=>b.left)),right:Math.max(...bounds.map(b=>b.right)),top:Math.min(...bounds.map(b=>b.top)),bottom:Math.max(...bounds.map(b=>b.bottom))}});
 }
 return result;
}

function objectAlignmentGuides(items,movingIds){
 items=movementAlignmentItems(items,movingIds);const moving=new Set(movingIds),guides=[],seen=new Set();
 const add=guide=>{const key=JSON.stringify(guide);if(!seen.has(key)){seen.add(key);guides.push(guide)}};
 for(const item of items){
  if(!moving.has(item.id)||item.visible===false||!item.bounds)continue;
  const bounds=item.bounds,cx=(bounds.left+bounds.right)/2,cy=(bounds.top+bounds.bottom)/2,nearest={x:null,y:null};
  for(const other of items){
   if(moving.has(other.id)||other.visible===false||!other.bounds)continue;
   const target=other.bounds,tx=(target.left+target.right)/2,ty=(target.top+target.bottom)/2;
   for(const axis of ['x','y']){
    const centered=Math.abs(axis==='x'?cx-tx:cy-ty)<=.05;
    if(centered){const distance=Math.abs(axis==='x'?cy-ty:cx-tx);if(!nearest[axis]||distance<nearest[axis].distance)nearest[axis]={distance,guide:{axis,centerMatch:true,x:axis==='x'?cx:Math.min(cx,tx),y:axis==='x'?Math.min(cy,ty):cy,length:distance}};continue}
    for(const edge of axis==='x'?['left','right']:['top','bottom'])for(const targetEdge of axis==='x'?['left','right']:['top','bottom']){
     if(Math.abs(bounds[edge]-target[targetEdge])>.000001)continue;
     add(axis==='x'?{axis,edge,x:target[targetEdge],y:Math.min(bounds.top,target.top),length:Math.max(bounds.bottom,target.bottom)-Math.min(bounds.top,target.top)}:{axis,edge,x:Math.min(bounds.left,target.left),y:target[targetEdge],length:Math.max(bounds.right,target.right)-Math.min(bounds.left,target.left)});
    }
   }
  }
  for(const axis of ['x','y'])if(nearest[axis])add(nearest[axis].guide);
 }
 return guides;
}

function clearAlignmentGuides(){controls.querySelectorAll('.alignment-guide').forEach(node=>node.remove());if(stage.classList.contains('center-align-x')||stage.classList.contains('center-align-y'))stage.classList.remove('center-align-x','center-align-y')}

function renderedBoardBounds(bounds,boardRect,scaleX,scaleY,borderLeft,borderTop){return {left:(bounds.left-boardRect.left)/scaleX-borderLeft,right:(bounds.right-boardRect.left)/scaleX-borderLeft,top:(bounds.top-boardRect.top)/scaleY-borderTop,bottom:(bounds.bottom-boardRect.top)/scaleY-borderTop}}

function alignmentSnapshot(){let boardRect=stage.getBoundingClientRect(),scaleX=boardRect.width/stage.offsetWidth,scaleY=boardRect.height/stage.offsetHeight;if(!scaleX||!scaleY)return [];let nodes=new Map(Array.from(layer.children).map(node=>[node.dataset.id,node]));return current().map(item=>{let node=nodes.get(item.id);return node?{...item,bounds:renderedBoardBounds(node.getBoundingClientRect(),boardRect,scaleX,scaleY,stage.clientLeft,stage.clientTop)}:item})}

// Gesture-owned geometry: stationary objects cannot change during an ordinary move.
// Moving objects still use their actual rendered bounds (text, rotation and clipping).
function objectMoveAlignmentSnapshot(){
 if(drag?.mode!=='move')return alignmentSnapshot();
 const page=current(),rect=stage.getBoundingClientRect(),width=stage.offsetWidth,height=stage.offsetHeight;
 const nodes=Array.from(layer.children),ids=drag.ids.join('\0'),signature=[rect.left,rect.top,rect.width,rect.height,width,height,stage.clientLeft,stage.clientTop,stage.className].join('|');
 let cache=drag.stationaryAlignment;
 if(!cache||cache.page!==page||cache.count!==page.length||cache.ids!==ids||cache.signature!==signature||cache.nodes.length!==nodes.length||nodes.some((node,index)=>node!==cache.nodes[index])){
  const items=alignmentSnapshot();
  drag.stationaryAlignment={page,count:page.length,ids,signature,nodes,items,nodeById:new Map(nodes.map(node=>[node.dataset.id,node]))};
  return items;
 }
 const moving=new Set(drag.ids),scaleX=rect.width/width,scaleY=rect.height/height;
 if(!scaleX||!scaleY)return [];
 return page.map((item,index)=>{
  if(!moving.has(item.id))return cache.items[index];
  const node=cache.nodeById.get(item.id);
  return node?{...item,bounds:renderedBoardBounds(node.getBoundingClientRect(),rect,scaleX,scaleY,stage.clientLeft,stage.clientTop)}:item;
 });
}

function boardCenterGuides(items,movingIds,previous,width,height){items=movementAlignmentItems(items,movingIds);let moving=new Set(movingIds),before=new Map(previous.map(item=>[item.id,item])),vertical=false,horizontal=false;let crossed=(value,oldValue,target)=>Math.abs(value-target)<=0.000001;for(let item of items){if(!moving.has(item.id)||item.visible===false||!item.bounds)continue;let bounds=item.bounds,old=before.get(item.id)?.bounds;for(let key of ['left','centerX','right']){let value=key==='centerX'?(bounds.left+bounds.right)/2:bounds[key],oldValue=old?(key==='centerX'?(old.left+old.right)/2:old[key]):undefined;if(crossed(value,oldValue,width/2))vertical=true}for(let key of ['top','centerY','bottom']){let value=key==='centerY'?(bounds.top+bounds.bottom)/2:bounds[key],oldValue=old?(key==='centerY'?(old.top+old.bottom)/2:old[key]):undefined;if(crossed(value,oldValue,height/2))horizontal=true}}let guides=[];if(vertical)guides.push({axis:'x',x:width/2,y:0,length:height});if(horizontal)guides.push({axis:'y',x:0,y:height/2,length:width});return guides}

function updateAlignmentGuides(ids){if(drag?.shiftGuidesDisabled){clearAlignmentGuides();return}let width=stage.clientWidth,height=stage.clientHeight;if(!width||!height){clearAlignmentGuides();return}let items=objectMoveAlignmentSnapshot(),previous=drag?.alignmentPrevious||[],guides=objectAlignmentGuides(items,ids,previous);if(drag?.mode==='move')guides.push(...boardCenterGuides(items,ids,previous,width,height).map(guide=>({...guide,centerLine:true})));if(drag)drag.alignmentPrevious=items;drawAlignmentGuides(guides,width,height)}

function mergedAlignmentGuides(guides){const lines=new Map(),centers=[];for(const guide of guides){if(guide.centerLine||guide.centerMatch){centers.push(guide);continue}if(!guide.length)continue;const key=guide.axis+':'+(guide.axis==='x'?guide.x:guide.y),previous=lines.get(key);if(!previous){lines.set(key,{...guide});continue}const start=guide.axis==='x'?'y':'x',end=Math.max(previous[start]+previous.length,guide[start]+guide.length);previous[start]=Math.min(previous[start],guide[start]);previous.length=end-previous[start]}return [...lines.values(),...centers]}

function syncSvgAlignmentScale(svg){const width=parseFloat(getComputedStyle(svg).width),scale=width?svg.getBoundingClientRect().width/width:1;svg.style.setProperty('--alignment-svg-transform-scale',String(scale||1))}

function drawAlignmentGuides(guides,width,height){
 const existing=Array.from(controls.querySelectorAll('.alignment-guide'));let index=0;const centers=new Set();
 for(const guide of mergedAlignmentGuides(guides)){
  if(guide.centerLine){centers.add(guide.axis);continue}
  if(!guide.length&&!guide.centerMatch)continue;
  const node=existing[index]||document.createElement('div'),className='alignment-guide alignment-guide-'+guide.axis+(guide.centerMatch?' alignment-guide-center':'');index++;
  if(node.className!==className)node.className=className;
  const style='left: '+guide.x/width*100+'%; top: '+guide.y/height*100+'%; '+(guide.axis==='x'?'height':'width')+': '+guide.length/(guide.axis==='x'?height:width)*100+'%;';
  if(node.style.cssText!==style)node.style.cssText=style;
  if(!node.parentNode)controls.appendChild(node);
 }
 for(const node of existing.slice(index))node.remove();
 for(const axis of ['x','y'])if(stage.classList.contains('center-align-'+axis)!==centers.has(axis))stage.classList.toggle('center-align-'+axis,centers.has(axis));
}

function snappedObjectMove(items,starts,dx,dy,width,height,minX,maxX,minY,maxY){
 items=movementAlignmentItems(items,starts.map(o=>o.id));const moving=new Map(starts.map(item=>[item.id,item])),best={x:{distance:Infinity,rank:Infinity,value:dx},y:{distance:Infinity,rank:Infinity,value:dy}};
 const consider=(axis,correction,rank)=>{const distance=Math.abs(correction),candidate=(axis==='x'?dx:dy)+correction,previous=best[axis],min=axis==='x'?minX:minY,max=axis==='x'?maxX:maxY;
  if(distance<=3&&candidate>=min&&candidate<=max&&(distance<previous.distance-.000001||Math.abs(distance-previous.distance)<=.000001&&rank<previous.rank))best[axis]={distance,rank,value:candidate};
 };
 for(const item of items){
  const start=moving.get(item.id);if(!start||!item.bounds||item.visible===false)continue;
  const bounds=item.bounds,shiftX=dx-(item.x-start.x)/100*width,shiftY=dy-(item.y-start.y)/100*height,cx=(bounds.left+bounds.right)/2,cy=(bounds.top+bounds.bottom)/2;
  consider('x',width/2-(cx+shiftX),0);consider('y',height/2-(cy+shiftY),0);
  for(const edge of [bounds.left,bounds.right])consider('x',width/2-(edge+shiftX),2);
  for(const edge of [bounds.top,bounds.bottom])consider('y',height/2-(edge+shiftY),2);
  for(const other of items){
   if(moving.has(other.id)||other.visible===false||!other.bounds)continue;const target=other.bounds;
   consider('x',(target.left+target.right)/2-(cx+shiftX),1);consider('y',(target.top+target.bottom)/2-(cy+shiftY),1);
   for(const edge of ['left','right'])for(const targetEdge of ['left','right'])consider('x',target[targetEdge]-(bounds[edge]+shiftX),3);
   for(const edge of ['top','bottom'])for(const targetEdge of ['top','bottom'])consider('y',target[targetEdge]-(bounds[edge]+shiftY),3);
  }
 }
 return {dx:best.x.value,dy:best.y.value};
}

function placementAlignment(payload,clientX,clientY,disabled=false,includeGuides=true){const rect=stage.getBoundingClientRect(),width=stage.clientWidth,height=stage.clientHeight,x=(clientX-rect.left)/rect.width*100,y=(clientY-rect.top)/rect.height*100;if(disabled||!width||!height)return {x,y,guides:[]};const item=createPlacementObject(payload,x,y),cx=x/100*width,cy=y/100*height;item.id='placement-preview';item.bounds={left:cx-item.width/2,right:cx+item.width/2,top:cy-item.height/2,bottom:cy+item.height/2};const items=[...placementAlignmentSnapshot(rect,width,height),item],snap=snappedObjectMove(items,[item],0,0,width,height,-Infinity,Infinity,-Infinity,Infinity);item.x+=snap.dx/width*100;item.y+=snap.dy/height*100;item.bounds={left:item.bounds.left+snap.dx,right:item.bounds.right+snap.dx,top:item.bounds.top+snap.dy,bottom:item.bounds.bottom+snap.dy};return {x:item.x,y:item.y,guides:includeGuides?[...objectAlignmentGuides(items,[item.id]),...boardCenterGuides(items,[item.id],[],width,height).map(guide=>({...guide,centerLine:true}))]:[]}}

function setShiftAlignmentOverride(pressed){if(!drag||(drag.mode!=='move'&&!drag.mode.startsWith('resize-')))return;drag.shiftGuidesDisabled=pressed;if(pressed)clearAlignmentGuides();else updateAlignmentGuides(drag.mode==='move'?drag.ids:[drag.id])}

function steppedObjectMove(delta,min,max){return Math.max(Math.ceil(min),Math.min(Math.floor(max),Math.round(delta)))}

function extents(o,r){if(['circle','donut','aoe','line','gaze','segment','targetcircle'].includes(o.type)){let a=o.rotation*Math.PI/180,w=o.width||o.size||110,h=o.height||o.size||110;return{w:(Math.abs(w*Math.cos(a))+Math.abs(h*Math.sin(a)))/2,h:(Math.abs(w*Math.sin(a))+Math.abs(h*Math.cos(a)))/2}}if(['image','icon','marker','text'].includes(o.type)){const node=layer.querySelector('[data-id="'+o.id+'"]'),w=node?.offsetWidth||o.width||34,h=node?.offsetHeight||o.height||34,a=(o.rotation||0)*Math.PI/180;return{w:(Math.abs(w*Math.cos(a))+Math.abs(h*Math.sin(a)))/2,h:(Math.abs(w*Math.sin(a))+Math.abs(h*Math.cos(a)))/2}}return{w:Math.max(22,String(o.label||'メモ').length*7)/2+8,h:15}}

function setMoveCopyMode(enabled){if(drag?.mode!=='move'||!!drag.ctrlAtStart===enabled)return;if(enabled){const before=JSON.parse(drag.beforeData).pages.flat(),originals=drag.ids.map(id=>current().find(o=>o.id===id)).filter(o=>o&&!o.locked);if(!originals.length)return;const starts=new Map(drag.starts.map(p=>[p.id,p]));const copies=originals.map(o=>{const copy=JSON.parse(JSON.stringify(o));copy.id=createObjectId();return copy});for(const o of originals){const saved=before.find(p=>p.id===o.id);if(saved){o.x=saved.x;o.y=saved.y}}remapCopiedObjectGroups(copies);current().push(...copies);drag.originalIds=originals.map(o=>o.id);drag.ids=copies.map(o=>o.id);drag.starts=copies.map((o,i)=>({id:o.id,x:starts.get(originals[i].id).x,y:starts.get(originals[i].id).y}));drag.ctrlAtStart=true}else{const copies=drag.ids.map(id=>current().find(o=>o.id===id));copies.forEach((copy,i)=>{const original=current().find(o=>o.id===drag.originalIds[i]);if(copy&&original){original.x=copy.x;original.y=copy.y}});current().splice(0,current().length,...current().filter(o=>!drag.ids.includes(o.id)));drag.ids=drag.originalIds.slice();drag.starts=drag.ids.map(id=>{const o=current().find(p=>p.id===id);return{id,x:o.x,y:o.y}});drag.startX=drag.lastX;drag.startY=drag.lastY;drag.ctrlAtStart=false}selectedIds=drag.ids.slice();selected=selectedIds[selectedIds.length-1]||null;stage.classList.toggle('ctrl-copy',enabled);clearAlignmentGuides();renderAndSave()}

function marqueeContainsVisibleObject(bounds,selection,board,viewport){let visible={left:Math.max(bounds.left,board.left,viewport.left),top:Math.max(bounds.top,board.top,viewport.top),right:Math.min(bounds.right,board.right,viewport.right),bottom:Math.min(bounds.bottom,board.bottom,viewport.bottom)};return visible.right>visible.left&&visible.bottom>visible.top&&visible.left>=selection.left&&visible.right<=selection.right&&visible.top>=selection.top&&visible.bottom<=selection.bottom}

function paintKeyboardNudge(){
 keyboardNudgeFrame=null;const session=keyboardNudgeSession;
 if(!session||session.board!==data||session.page!==current())return;
 for(const item of session.items){const node=session.nodes.get(item.id);if(node){node.style.left=item.x+'%';node.style.top=item.y+'%';if(item.type==='targetcircle')refreshTargetCircleTriangle(item,node)}const box=session.boxes.get(item.id);if(box){box.style.left=item.x+'%';box.style.top=item.y+'%'}}
 const item=session.items.find(o=>o.id===selected);
 if(item&&selectedIds.length===1){for(const [axis,size] of [['X',session.width],['Y',session.height]]){const value=Math.round(item[axis.toLowerCase()]/100*size);for(const suffix of ['', 'Spin']){const input=document.getElementById('object'+axis+suffix);if(input)input.value=value}const label=document.getElementById('object'+axis+'Value');if(label)label.textContent=value}}
}

function finishKeyboardNudge(){
 const session=keyboardNudgeSession;if(!session)return;
 if(keyboardNudgeFrame!==null){cancelAnimationFrame(keyboardNudgeFrame);keyboardNudgeFrame=null;paintKeyboardNudge()}
 keyboardNudgeSession=null;
 if(session.board===data&&session.page===current()){updateHistoryButtons();renderInspector()}
}

function nudgeSelectedObjects(key,repeat=false,step=1){
 if(boardReadOnly||phaseComparisonActive()||drag)return false;if(!individualGroupSelectionActive()&&current().some(o=>selectedIds.includes(o.id)&&o.objectGroupId&&o.locked))return false;
 const direction={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[key];if(!direction)return false;
 const selection=JSON.stringify(selectedIds);let session=keyboardNudgeSession;
 if(!session||session.board!==data||session.page!==current()||session.selection!==selection||!repeat){
  finishKeyboardNudge();const selectedSet=new Set(selectedIds),items=current().filter(o=>selectedSet.has(o.id)&&!o.locked);if(!items.length)return false;
  session={board:data,page:current(),selection,items,width:stage.clientWidth||640,height:stage.clientHeight||640,nodes:new Map([...layer.children].map(node=>[node.dataset.id,node])),boxes:new Map([...controls.querySelectorAll('.controlbox')].map(node=>[node.dataset.id,node])),started:false};keyboardNudgeSession=session;
 }
 const items=session.items;let dx=direction[0]*step*100/session.width,dy=direction[1]*step*100/session.height;
 dx=Math.max(-Math.min(...items.map(o=>o.x)),Math.min(100-Math.max(...items.map(o=>o.x)),dx));dy=Math.max(-Math.min(...items.map(o=>o.y)),Math.min(100-Math.max(...items.map(o=>o.y)),dy));if(!dx&&!dy)return true;
 if(!session.started){recordHistory();session.started=true;clearAlignmentGuides()}
 for(const item of items){item.x+=dx;item.y+=dy}
 if(keyboardNudgeFrame===null)keyboardNudgeFrame=requestAnimationFrame(paintKeyboardNudge);
 scheduleObjectPropertySave();return true;
}

function selectAllObjects(){if(boardReadOnly||phaseComparisonActive()||window.Bolxiv?.pngPreview?.active||window.Bolxiv?.fieldGuideEditor?.active)return;selectedIds=current().map(item=>item.id);selected=selectedIds.at(-1)||null;normalizeObjectSelection();renderSelectionOnly()}
function duplicateObjects(ids){if(boardReadOnly||phaseComparisonActive()||window.Bolxiv?.pngPreview?.active||window.Bolxiv?.fieldGuideEditor?.active)return;const sources=current().filter(o=>ids.includes(o.id));if(!sources.length)return;recordHistory();const copies=sources.map(source=>{const copy=JSON.parse(JSON.stringify(source));copy.id=createObjectId();return copy});remapCopiedObjectGroups(copies);current().push(...copies);selectedIds=copies.map(o=>o.id);selected=selectedIds.at(-1)||null;renderAndSave();revealMovedLayers(selectedIds)}
function changeObjectGrouping(ids,ungroup=false){
 if(boardReadOnly||phaseComparisonActive()||window.Bolxiv?.pngPreview?.active||window.Bolxiv?.fieldGuideEditor?.active||individualGroupSelectionActive())return;
 const expanded=expandObjectGroups(ids),items=current().filter(o=>expanded.includes(o.id));
 if(ungroup?!items.some(o=>o.objectGroupId):items.length<2||selectedObjectGroup().length>0)return;
 recordHistory();const groupId=createObjectId();for(const item of items){if(ungroup){delete item.objectGroupId;delete item.objectGroupName}else{item.objectGroupId=groupId;item.objectGroupName='グループ'}}
 selectedIds=expanded;selected=expanded.at(-1)||null;renderAndSave();if(!ungroup)revealCreatedObjectGroup(groupId);
}

function copyObjectsToClipboard(ids){const selectedSet=new Set(expandObjectGroups(ids)),sources=current().filter(o=>selectedSet.has(o.id));if(!sources.length)return;clipboardObjects=sources.map(o=>JSON.parse(JSON.stringify(o)));clipboardSourcePage=current();notify(sources.length+'個のオブジェクトをコピーしました')}
function pasteClipboardObjects(){if(boardReadOnly||phaseComparisonActive()||!clipboardObjects.length)return;recordHistory();let samePage=current()===clipboardSourcePage,copies=clipboardObjects.map(source=>{let copy=JSON.parse(JSON.stringify(source));copy.id=createObjectId();if(samePage){copy.x=Math.max(0,Math.min(100,copy.x+2));copy.y=Math.max(0,Math.min(100,copy.y+2))}return copy});remapCopiedObjectGroups(copies);current().push(...copies);selectedIds=copies.map(o=>o.id);selected=selectedIds[selectedIds.length-1]||null;renderAndSave();revealMovedLayers(selectedIds)}

function deleteSelected(){if(boardReadOnly)return;if(phaseComparisonActive())return;let deletable=selectedIds.filter(id=>!current().find(o=>o.id===id)?.locked);if(!deletable.length)return;snapshot();data.pages[data.page]=current().filter(o=>!deletable.includes(o.id));selectedIds=selectedIds.filter(id=>!deletable.includes(id));selected=selectedIds[selectedIds.length-1]||null;renderAndSave()}

function updateObjectTileClip(o,el){
 if(activeBoardShape()!=='image4'){if(el.dataset.image4Clip){el.style.removeProperty('clip-path');delete el.dataset.image4Clip}return}
 const size=data.pageFieldSizes?.[data.page]||{width:538,height:538},cx=o.x>=50?480:160,cy=o.y>=50?480:160;
 const halfWidth=Math.min((size.width||538)/2,160),halfHeight=Math.min((size.height||538)/2,160);
 const width=parseFloat(el.style.width)||o.width||110,height=o.type==='text'?el.offsetHeight:parseFloat(el.style.height)||o.height||110;
 const angle=(o.rotation||0)*Math.PI/180,c=Math.cos(angle),s=Math.sin(angle),ox=o.x*6.4,oy=o.y*6.4;
 const points=[[cx-halfWidth,cy-halfHeight],[cx+halfWidth,cy-halfHeight],[cx+halfWidth,cy+halfHeight],[cx-halfWidth,cy+halfHeight]].map(([x,y])=>{const dx=x-ox,dy=y-oy;return (dx*c+dy*s+width/2)+'px '+(-dx*s+dy*c+height/2)+'px'});
 el.style.clipPath='polygon('+points.join(',')+')';el.dataset.image4Clip='true';
}

function updateObjectClip(){
 const objects=new Map(current().map(o=>[o.id,o]));for(const el of layer.children){const o=objects.get(el.dataset.id);if(o)updateObjectTileClip(o,el)}
 const shape=activeBoardShape(),fw=data.pageFieldSizes?.[data.page]?.width||538,fh=data.pageFieldSizes?.[data.page]?.height||(shape==='landscape'?320:538);
 if(!fieldClipEnabled||shape==='none'){objectClip.style.clipPath='none';return}
 if(shape==='image4'){const paths=[[160,160],[480,160],[160,480],[480,480]].map(([x,y])=>{const left=x-Math.min(fw/2,160),right=x+Math.min(fw/2,160),top=y-Math.min(fh/2,160),bottom=y+Math.min(fh/2,160);return 'M'+left+' '+top+'H'+right+'V'+bottom+'H'+left+'Z'});objectClip.style.clipPath='path("'+paths.join(' ')+'")';return}
 objectClip.style.clipPath=shape==='circle'?'ellipse('+fw/2/640*100+'% '+fh/2/640*100+'% at 50% 50%)':'inset('+(640-fh)/2/640*100+'% '+(640-fw)/2/640*100+'%)';
}

function updateClipToggle(){let b=$('#clipToggle');if(!b)return;b.setAttribute('aria-pressed',String(fieldClipEnabled));b.title=fieldClipEnabled?'フィールド外の部分を表示':'フィールド外の部分を非表示';b.setAttribute('aria-label',b.title);b.innerHTML=fieldClipEnabled?'<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="2" y="2" width="12" height="12" rx="1"/><path d="M8 8h6v6H8z"/><path d="M14 8h3v9H8v-3" stroke-dasharray="2 2" opacity=".35"/></svg>':'<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="2" y="2" width="12" height="12" rx="1"/><path d="M9 8h8v9H8v-3M8 8v6M8 8h6"/><path d="M14 8h3v9H8v-3" stroke-dasharray="2 2"/></svg>'}

function updateFieldToggle(){let button=$('#fieldToggle');button.setAttribute('aria-pressed',String(fieldVisible));button.title=fieldVisible?'フィールドを非表示':'フィールドを表示';button.setAttribute('aria-label',button.title);button.innerHTML=fieldVisible?'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M2 10s3-5 8-5 8 5 8 5-3 5-8 5-8-5-8-5Z"/><circle cx="10" cy="10" r="2.2"/></svg>':'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M2 10s3-5 8-5 8 5 8 5-3 5-8 5-8-5-8-5Z"/><circle cx="10" cy="10" r="2.2"/><path d="m3 3 14 14"/></svg>'}

function updateGridToggle(){let button=$('#gridToggle');if(!button)return;button.setAttribute('aria-pressed',String(gridVisible));button.title=gridVisible?'グリッド線を非表示':'グリッド線を表示';button.setAttribute('aria-label',button.title);button.innerHTML=gridVisible?'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3 3h14v14H3zM8 3v14M13 3v14M3 8h14M3 13h14"/></svg>':'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3 3h14v14H3zM8 3v14M13 3v14M3 8h14M3 13h14M2 18 18 2"/></svg>'}

function bindFieldDimensionSpin(spin,axis){
 function restore(){spin.value=String(data.pageFieldSizes[data.page]?.[axis]||538)}
 function commit(){const value=spin.value.trim();if(!value||!Number.isFinite(Number(value))){restore();return}if(Number(value)!==data.pageFieldSizes[data.page]?.[axis]){recordHistory();setFieldDimension(axis,value)}else restore()}
 spin.addEventListener("change",commit);
 spin.addEventListener("blur",commit);

}

function setFieldDimension(axis,value){let size=data.pageFieldSizes[data.page]||{width:538,height:538},baseWidth=size.width,baseHeight=size.height,maxSize=activeBoardShape()==='image'?960:640,requested=Math.max(64,Math.min(maxSize,Math.round(Number(value)||64))),factor=requested/(axis==='width'?baseWidth:baseHeight),minFactor=Math.max(64/baseWidth,64/baseHeight),maxFactor=Math.min(maxSize/baseWidth,maxSize/baseHeight);factor=Math.max(minFactor,Math.min(maxFactor,factor));size.width=Math.round(baseWidth*factor);size.height=Math.round(baseHeight*factor);data.pageFieldSizes[data.page]=size;for(let [key,dimension] of [['width',size.width],['height',size.height]]){let cap=key==='width'?'Width':'Height';document.getElementById('field'+cap+'Range').value=document.getElementById('field'+cap+'Spin').value=dimension;document.getElementById('field'+cap+'Value').textContent=dimension;stage.style.setProperty('--field-'+key,dimension/640*100+'%');stage.style.setProperty('--image4-tile-'+key,dimension+'px')}updateObjectClip();renderFieldGuides();save()}

function fitBoardDisplayZoom(remember=true){const space=document.getElementById('boardZoomSpace'),viewport=space.parentElement,comparison=document.querySelector('.phase-comparison-grid');const width=comparison?comparison.offsetWidth:640,height=comparison?comparison.offsetHeight:640;const preview=matchMedia('(max-width:850px)').matches&&document.querySelector('.layout').classList.contains('phone-content-open'),margin=preview?8:40;const availableWidth=Math.max(0,viewport.clientWidth-margin),availableHeight=Math.max(0,viewport.clientHeight-margin);const step=preview?1:5,zoom=Math.floor(Math.min(availableWidth/width,availableHeight/height)*100/step)*step;setBoardDisplayZoom(Math.max(5,Math.min(200,zoom)),remember!==false);if(preview){viewport.scrollTop=0;viewport.scrollLeft=0}}

function setBoardDisplayZoom(value,remember=true,recenter=true){const preview=matchMedia('(max-width:850px)').matches&&document.querySelector('.layout').classList.contains('phone-content-open'),step=preview?1:5;boardDisplayZoom=Math.max(5,Math.min(200,Math.round((Number(value)||0)/step)*step));stage.style.setProperty('--board-display-scale',String(boardDisplayZoom/100));document.getElementById('boardZoomSpace').style.setProperty('--board-display-scale',String(boardDisplayZoom/100));const comparison=document.querySelector('.phase-comparison-grid');if(comparison)comparison.style.transform='translate(-50%,-50%) scale('+boardDisplayZoom/100+')';let space=document.getElementById('boardZoomSpace'),viewport=space.parentElement;const width=((comparison?comparison.offsetWidth:640)*boardDisplayZoom/100+40)+'px',height=((comparison?comparison.offsetHeight:640)*boardDisplayZoom/100+40)+'px',sizeChanged=space.style.width!==width||space.style.height!==height;space.style.width=width;space.style.height=height;if(recenter||sizeChanged){viewport.scrollLeft=Math.max(0,(viewport.scrollWidth-viewport.clientWidth)/2);viewport.scrollTop=Math.max(0,(viewport.scrollHeight-viewport.clientHeight)/2);}document.getElementById('boardZoomValue').textContent=boardDisplayZoom;document.getElementById('zoomOut').disabled=boardDisplayZoom===5;document.getElementById('zoomIn').disabled=boardDisplayZoom===200;if(remember)rememberViewSetting('boardDisplayZoom',boardDisplayZoom)}

;
// Hover is restricted to a desktop mouse; touch and keyboard retain explicit activation.
function bindSubmenuHover(toggle,submenu,open,close){
 const root=toggle.closest('[role="menu"]');
 if(!root._submenuHover){
  const state={items:[],openTimer:null,closeTimer:null,origin:null};root._submenuHover=state;
  const desktop=()=>matchMedia('(min-width:851px) and (hover:hover) and (pointer:fine)').matches;
  const cancel=()=>{clearTimeout(state.openTimer);clearTimeout(state.closeTimer);state.openTimer=state.closeTimer=null};root._cancelSubmenuHover=cancel;
  const closeAll=()=>state.items.forEach(item=>item.close());
  const laterClose=(delay=450)=>{cancel();state.closeTimer=setTimeout(()=>{state.closeTimer=null;closeAll()},delay)};state.cancel=cancel;state.laterClose=laterClose;state.desktop=desktop;
  // Protect diagonal travel into an offset child without delaying unrelated rows.
  const movingToChild=event=>{
   const origin=state.origin;if(!origin||performance.now()-origin.time>700)return false;
   const active=state.items.find(item=>!item.submenu.hidden&&item.toggle===origin.toggle);if(!active)return false;
   const rect=active.submenu.getBoundingClientRect(),edge=rect.right<=origin.x?rect.right:rect.left;
   if(Math.abs(event.clientX-edge)>Math.abs(origin.x-edge)+2)return false;
   const a={x:origin.x,y:origin.y},b={x:edge,y:rect.top-8},c={x:edge,y:rect.bottom+8},p={x:event.clientX,y:event.clientY};
   const cross=(u,v,w)=>(u.x-w.x)*(v.y-w.y)-(v.x-w.x)*(u.y-w.y);
   const signs=[cross(p,a,b),cross(p,b,c),cross(p,c,a)];return !(signs.some(n=>n<0)&&signs.some(n=>n>0));
  };
  root.addEventListener('pointermove',event=>{if(event.pointerType!=='mouse'||!desktop())return;const item=state.items.find(item=>item.toggle.contains(event.target)&&!item.submenu.hidden);if(item)state.origin={x:event.clientX,y:event.clientY,time:performance.now(),toggle:item.toggle}});
  root.addEventListener('pointerover',event=>{
   if(event.pointerType!=='mouse'||!desktop()||root.hidden)return;
   const child=state.items.find(item=>item.submenu.contains(event.target));
   if(child){cancel();return}
   const item=state.items.find(item=>item.toggle.contains(event.target));
   const protect=movingToChild(event);
   if(root.id==='headerActions'){state.activeToggle=item?.toggle||null;if(!protect)state.items.filter(other=>other!==item).forEach(other=>other.close())}
   if(!item){laterClose(protect?600:450);return}
   cancel();if(item.toggle.disabled)return;
   state.openTimer=setTimeout(()=>{state.openTimer=null;if(root.hidden||!desktop()||!item.toggle.getClientRects().length)return;state.items.filter(other=>other!==item).forEach(other=>other.close());const wasHidden=item.submenu.hidden;item.open(true);if(wasHidden&&!item.submenu.hidden)item.submenu._openedByHover=true},protect?600:140);
  });
  root.addEventListener('pointerout',event=>{if(event.pointerType==='mouse'&&desktop()&&!root.contains(event.relatedTarget))laterClose()});
  root.addEventListener('pointerdown',cancel,true);
  new MutationObserver(()=>{if(root.hidden)cancel()}).observe(root,{attributes:true,attributeFilter:['hidden']});
  window.addEventListener('blur',cancel);window.addEventListener('resize',()=>{cancel();if(!desktop())closeAll()});
 }
 toggle.addEventListener('click',event=>{
  if(event.detail>0&&matchMedia('(min-width:851px) and (hover:hover) and (pointer:fine)').matches&&submenu._openedByHover&&!submenu.hidden){
   submenu._openedByHover=false;root._cancelSubmenuHover();event.preventDefault();event.stopImmediatePropagation();submenu.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
  }
 },true);
 if(!root.contains(submenu)){
  submenu.addEventListener('pointerover',event=>{if(event.pointerType==='mouse'&&root._submenuHover.desktop())root._submenuHover.cancel()});
  submenu.addEventListener('pointerout',event=>{if(event.pointerType==='mouse'&&root._submenuHover.desktop()&&!submenu.contains(event.relatedTarget)&&!root.contains(event.relatedTarget))root._submenuHover.laterClose()});
 }
 root._submenuHover.items.push({toggle,submenu,open,close});
}

// Track popup cleanup on every device; add the mobile close row before measuring.
let menuKeyboardOrder=0;
function addPhoneMenuClose(menu,close){
 // Keep each popup's own cleanup, including private selection/gesture state.
 menu._keyboardClose=close;menu._keyboardOrder=++menuKeyboardOrder;
 if(!menu.contains(document.activeElement))menu._keyboardOrigin=document.activeElement;
 if(!matchMedia('(max-width:850px)').matches)return;
 let button=menu.querySelector('[data-phone-menu-close]');
 if(!button){
  const separator=document.createElement('div');separator.className='phone-menu-close-separator';separator.setAttribute('role','separator');
  button=document.createElement('button');button.type='button';button.className='phone-menu-close';button.dataset.phoneMenuClose='true';button.setAttribute('role','menuitem');button.textContent='閉じる';menu.append(separator,button);
 }
 button.onclick=event=>{event.preventDefault();event.stopPropagation();close()};
}


// Keep the phone movement grip inside the visible canvas when its usual position is clipped.
(()=>{
 const root=document.getElementById('objectControls');let frame=0;
 function schedule(){if(!frame)frame=requestAnimationFrame(update)}
 const observer=new MutationObserver(schedule);
 function observe(){observer.observe(root,{childList:true,subtree:true,attributes:true,attributeFilter:['style']})}
 function update(){
  frame=0;observer.disconnect();
  try{for(const handle of root.querySelectorAll('.move-handle')){
   handle.style.removeProperty('transform');delete handle.dataset.edgePlacement;
   if(!matchMedia('(max-width:850px)').matches)continue;
   const view=visualViewport,bounds={left:view?.offsetLeft||0,top:view?.offsetTop||0,right:(view?.offsetLeft||0)+(view?.width||innerWidth),bottom:(view?.offsetTop||0)+(view?.height||innerHeight)};
   for(let parent=handle.parentElement;parent;parent=parent.parentElement){const style=getComputedStyle(parent),rect=parent.getBoundingClientRect();if(/hidden|clip|auto|scroll/.test(style.overflowX)){bounds.left=Math.max(bounds.left,rect.left);bounds.right=Math.min(bounds.right,rect.right)}if(/hidden|clip|auto|scroll/.test(style.overflowY)){bounds.top=Math.max(bounds.top,rect.top);bounds.bottom=Math.min(bounds.bottom,rect.bottom)}}
   const r=handle.getBoundingClientRect(),pad=4;
   if(!r.width||!r.height||r.bottom<=bounds.bottom-pad&&r.top>=bounds.top+pad&&r.left>=bounds.left+pad&&r.right<=bounds.right-pad)continue;
   const box=handle.closest('.controlbox').getBoundingClientRect(),halfX=r.width/2,halfY=r.height/2;
   if(bounds.right-bounds.left<r.width+pad*2||bounds.bottom-bounds.top<r.height+pad*2)continue;
   const clamp=(v,min,max)=>Math.max(min,Math.min(max,v)),y=clamp((box.top+box.bottom)/2,bounds.top+halfY+pad,bounds.bottom-halfY-pad);
   const gap=22,left=box.left-gap-halfX,right=box.right+gap+halfX,leftFits=left-halfX>=bounds.left+pad,rightFits=right+halfX<=bounds.right-pad;
   const side=leftFits&&(!rightFits||box.left-bounds.left>=bounds.right-box.right)?'left':'right';
   const x=clamp(side==='left'?left:right,bounds.left+halfX+pad,bounds.right-halfX-pad);
   let matrix=new DOMMatrix();for(let parent=handle.parentElement;parent;parent=parent.parentElement){const transform=getComputedStyle(parent).transform;if(transform!=='none')matrix=new DOMMatrix(transform).multiply(matrix)}
   const inverse=matrix.inverse(),vector=(dx,dy)=>({x:inverse.a*dx+inverse.c*dy,y:inverse.b*dx+inverse.d*dy});
   const delta=vector(x-(r.left+r.right)/2,y-(r.top+r.bottom)/2);if(!Number.isFinite(delta.x)||!Number.isFinite(delta.y))continue;
   handle.style.transform='translate('+delta.x+'px,'+delta.y+'px)';handle.dataset.edgePlacement=side;
   const connection=vector((side==='left'?box.left:box.right)-x,clamp(y,box.top,box.bottom)-y),length=Math.hypot(connection.x,connection.y),start=16;
   handle.style.setProperty('--move-connector-x',(length?connection.x/length*start:0)+'px');handle.style.setProperty('--move-connector-y',(length?connection.y/length*start:0)+'px');handle.style.setProperty('--move-connector-length',Math.max(0,length-start)+'px');handle.style.setProperty('--move-connector-angle',Math.atan2(-connection.x,connection.y)+'rad');
  }}finally{observe()}
 }
 observe();window.addEventListener('resize',schedule);window.addEventListener('scroll',schedule,true);visualViewport?.addEventListener('resize',schedule);visualViewport?.addEventListener('scroll',schedule);
 for(const node of [stage,document.getElementById('boardZoomSpace')])if(node)new MutationObserver(schedule).observe(node,{attributes:true,attributeFilter:['style','class']});
})();
