// Ordered application entry. These same files are edited and distributed.
window.BolxivApplicationFiles = [
  "js/canvas.js",
  "js/data-io.js",
  "js/embedded-images.js",
  "js/editor.js",
  "js/phase-masters.js",
  "js/interface.js",
  "js/png-preview.js",
  "js/panels.js",
  "js/phase-tools.js",
  "js/workspace-background.js",
  "js/drive-sync.js"
];
