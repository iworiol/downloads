// ===== Features =====
// Object groups are stored on each member so JSON, history and phase copies retain them.
(function setupObjectGroups(){
 const beforeGroupInspector=renderInspector;renderInspector=function(){beforeGroupInspector();renderIndividualGroupHint(document.getElementById('inspector'))};
 const menu=document.getElementById('objectContextMenu');
 // Capture member-row selection before individual child handlers or reused rows.
 document.getElementById('objectList').addEventListener('click',event=>{
  const row=event.target.closest('.object-group-member');
  if(!row||event.target.closest('input,button:not(.object-name),textarea')||phaseComparisonActive())return;
  event.preventDefault();event.stopImmediatePropagation();selectObjectListItem(row.dataset.id,event,true);
 },true);
 const membershipList=document.getElementById('objectList');for(const type of ['dragover','drop'])membershipList.addEventListener(type,handleObjectMembershipDrop,true);
 const clearMembershipGuide=()=>membershipList.querySelectorAll('.drag-over,.drop-before,.drop-after').forEach(n=>n.classList.remove('drag-over','drop-before','drop-after'));membershipList.addEventListener('dragleave',event=>{if(!membershipList.contains(event.relatedTarget))clearMembershipGuide()});document.addEventListener('dragend',clearMembershipGuide);
 const groupToggle=document.createElement('button');groupToggle.id='contextGroupMenuToggle';groupToggle.type='button';groupToggle.textContent='グループ ▸';groupToggle.setAttribute('role','menuitem');groupToggle.setAttribute('aria-haspopup','menu');groupToggle.setAttribute('aria-expanded','false');groupToggle.setAttribute('aria-controls','contextGroupMenu');menu.insertBefore(groupToggle,document.getElementById('contextCopy'));
 const groupMenu=document.createElement('div');groupMenu.id='contextGroupMenu';groupMenu.className='object-context-menu';groupMenu.hidden=true;groupMenu.setAttribute('role','menu');groupMenu.setAttribute('aria-label','グループ');menu.append(groupMenu);
 const closeGroupMenu=()=>{groupMenu._openedByHover=false;groupMenu.hidden=true;groupToggle.setAttribute('aria-expanded','false')};
 function openGroupMenu(fromHover=false){if(!groupMenu.hidden){if(fromHover!==true)closeGroupMenu();return}addPhoneMenuClose(groupMenu,closeGroupMenu);groupMenu.hidden=false;groupToggle.setAttribute('aria-expanded','true');const r=groupToggle.getBoundingClientRect(),width=groupMenu.offsetWidth,height=groupMenu.offsetHeight;groupMenu.style.left=Math.max(4,Math.min(r.right+4+width>innerWidth?r.left-width-4:r.right+4,innerWidth-width-4))+'px';groupMenu.style.top=Math.max(4,Math.min(r.top,innerHeight-height-4))+'px'}
 bindSubmenuHover(groupToggle,groupMenu,openGroupMenu,closeGroupMenu);
 groupToggle.onclick=openGroupMenu;groupToggle.onkeydown=event=>{if(event.key==='ArrowRight'){event.preventDefault();if(groupMenu.hidden)openGroupMenu();groupMenu.querySelector('button:not(:disabled)')?.focus()}};
 groupMenu.addEventListener('keydown',event=>{if(event.key==='Escape'||event.key==='ArrowLeft'){event.preventDefault();event.stopPropagation();closeGroupMenu();groupToggle.focus()}});
 const groupStart=document.createElement('div');groupStart.className='context-separator';groupStart.setAttribute('role','separator');menu.insertBefore(groupStart,groupToggle);
 for(const [id,label] of [['contextGroup','グループ化'],['contextSelectAllGroupMembers','グループ内を全選択'],['contextUngroup','グループ解除'],['contextDetachGroupMembers','グループから外す'],['contextRenameObjectGroup','グループ名を変更']]){
  const button=createMenuAction({label});button.id=id;
  groupMenu.append(button);
  button.onclick=()=>{
   if(button.disabled)return;
   if(id==='contextSelectAllGroupMembers'){const objectId=menu.dataset.id;closeObjectContextMenu();selectAllObjectGroupMembers(objectId);return}
   if(id==='contextDetachGroupMembers'){const ids=JSON.parse(menu.dataset.ids||'[]');closeObjectContextMenu();detachObjectGroupMembers(ids);return}
   const ids=expandObjectGroups(JSON.parse(menu.dataset.ids||'[]')),items=current().filter(o=>ids.includes(o.id));closeObjectContextMenu();
   if(id==='contextRenameObjectGroup'){if(selectedObjectGroup().length)beginObjectGroupRename(items[0].objectGroupId);return}
   changeObjectGrouping(ids,id==='contextUngroup');
  };
 }
 const groupEnd=document.createElement('div');groupEnd.className='context-separator';groupEnd.setAttribute('role','separator');menu.insertBefore(groupEnd,document.getElementById('contextCopy'));
 const presetToggle=createMenuAction({label:'プリセット ▸'});
 presetToggle.id='contextPresetToggle';
 presetToggle.setAttribute('aria-haspopup','menu');
 presetToggle.setAttribute('aria-controls','contextPresetMenu');
 presetToggle.setAttribute('aria-expanded','false');
 menu.insertBefore(presetToggle,document.getElementById('contextCopy'));
 const presetSeparator=document.createElement('div');
 presetSeparator.id='contextPresetSeparator';presetSeparator.className='context-separator';
 presetSeparator.setAttribute('role','separator');
 presetToggle.after(presetSeparator);
 const presetMenu=document.createElement('div');
 presetMenu.id='contextPresetMenu';presetMenu.className='object-context-menu';presetMenu.hidden=true;
 presetMenu.setAttribute('role','menu');presetMenu.setAttribute('aria-label','プリセット');
 menu.append(presetMenu);
 function closePresetMenu(){presetMenu._openedByHover=false;presetMenu.hidden=true;presetToggle.setAttribute('aria-expanded','false')}
 function openPresetMenu(fromHover=false){
  if(presetToggle.hidden||presetToggle.disabled)return;
  if(!presetMenu.hidden){if(fromHover!==true)closePresetMenu();return}
  closeGroupMenu();
  const clipboardToggle=document.getElementById('contextClipboardToggle');
  if(clipboardToggle?.getAttribute('aria-expanded')==='true')clipboardToggle.click();
  addPhoneMenuClose(presetMenu,()=>{closePresetMenu();presetToggle.focus()});
  presetMenu.hidden=false;presetToggle.setAttribute('aria-expanded','true');
  const r=presetToggle.getBoundingClientRect(),width=presetMenu.offsetWidth,height=presetMenu.offsetHeight;
  presetMenu.style.left=Math.max(4,Math.min(r.right+4+width>innerWidth?r.left-width-4:r.right+4,innerWidth-width-4))+'px';
  presetMenu.style.top=Math.max(4,Math.min(r.top,innerHeight-height-4))+'px';
 }
 bindSubmenuHover(presetToggle,presetMenu,openPresetMenu,closePresetMenu);
 presetToggle.onclick=openPresetMenu;
 presetToggle.onkeydown=event=>{if(event.key==='ArrowRight'){event.preventDefault();if(presetMenu.hidden)openPresetMenu();presetMenu.querySelector('button:not(:disabled):not([hidden])')?.focus()}};
 presetMenu.addEventListener('keydown',event=>{if(['Escape','ArrowLeft'].includes(event.key)){event.preventDefault();event.stopPropagation();closePresetMenu();presetToggle.focus()}});
 for(const [id,label,asSvg] of [['contextRegisterPreset','オブジェクト群として登録',false],['contextRegisterSvgPreset','SVG画像として登録',true]]){
  const action=createMenuAction({label});action.id=id;presetMenu.append(action);
  action.onclick=()=>{
   if(presetToggle.disabled)return;
   selectedIds=JSON.parse(menu.dataset.ids||'[]').filter(id=>current().some(item=>item.id===id));selected=selectedIds.at(-1)||null;
   closeObjectContextMenu();userPresetLibrary.registerSelection(asSvg);
  };
 }
 const beforePresetClose=closeObjectContextMenu;
 closeObjectContextMenu=function(){closePresetMenu();beforePresetClose()};
 groupToggle.addEventListener('click',closePresetMenu);
 document.addEventListener('pointermove',e=>{
  if(!['group-scale','group-rotate'].includes(drag?.mode)||drag.pointerId!==e.pointerId)return;e.preventDefault();e.stopImmediatePropagation();
  if(drag.mode==='group-rotate'){
   if(drag.board!==data||drag.page!==current()){finish(null);return}
   const r=layer.getBoundingClientRect(),angle=Math.atan2(e.clientY-(r.top+drag.cy/100*r.height),e.clientX-(r.left+drag.cx/100*r.width));let delta=angle-drag.lastAngle;while(delta>Math.PI)delta-=2*Math.PI;while(delta<-Math.PI)delta+=2*Math.PI;drag.degrees+=delta*180/Math.PI;drag.lastAngle=angle;const degrees=Math.round(drag.degrees);drag.rotateContents=e.shiftKey;drag.orientationOnly=e.shiftKey;applyObjectGroupRotation(drag.items,drag.cx,drag.cy,degrees,drag.rotateContents,drag.orientationOnly);drag.moved=normalizedObjectRotation(degrees)!==0;for(const item of current().filter(o=>drag.items.some(original=>original.id===o.id)))updateShapeFromData(item,false);renderObjectGroupControls();const amount=objectGroupRotationValue(current().filter(o=>drag.items.some(original=>original.id===o.id)),drag.orientationOnly);for(const id of (drag.orientationOnly?['groupOrientationRange','groupOrientationNumber']:['groupRotationRange','groupRotationNumber'])){const input=document.getElementById(id);if(input)input.value=amount}const value=document.getElementById(drag.orientationOnly?'groupOrientationValue':'groupRotationValue');if(value)value.textContent=amount;const section=document.getElementById('objectGroupProperties');if(section)refreshObjectGroupDimensions(section,current().filter(o=>drag.items.some(original=>original.id===o.id)));return;
  }
  const denominator=drag.vx*drag.vx+drag.vy*drag.vy;if(!denominator)return;
  let factor=1+((e.clientX-drag.startX)*drag.vx+(e.clientY-drag.startY)*drag.vy)/denominator;
  drag.spacing=e.shiftKey;
  factor=applyObjectGroupScale(drag.items,drag.cx,drag.cy,factor,drag.spacing,drag.geometry);drag.moved=drag.moved||Math.abs(factor-1)>.0001;
  const ids=new Set(drag.items.map(item=>item.id)),items=current().filter(item=>ids.has(item.id));
  for(const item of items)updateShapeFromData(item,false);
  renderObjectGroupControls();
  const section=document.getElementById('objectGroupProperties');if(section)refreshObjectGroupDimensions(section,items);
 },true);
 function finish(e,cancel=false){
  if(!['group-scale','group-rotate'].includes(drag?.mode)||e&&drag.pointerId!==e.pointerId)return;e?.preventDefault();e?.stopImmediatePropagation();
  const gesture=drag;drag=null;if(stage.hasPointerCapture(gesture.pointerId))stage.releasePointerCapture(gesture.pointerId);
  if(gesture.board&&(gesture.board!==data||gesture.page!==current()))return;
  if(cancel){Object.assign(data,JSON.parse(gesture.beforeData));renderAndSave()}else if(gesture.moved){recordHistory(gesture.beforeData);renderAndSave()}
 }
 document.addEventListener('pointerup',e=>finish(e),true);document.addEventListener('pointercancel',e=>finish(e,true),true);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&['group-scale','group-rotate'].includes(drag?.mode)){e.preventDefault();e.stopImmediatePropagation();finish(null,true)}},true);
 window.addEventListener('blur',()=>finish(null,true));
 // The canvas and phone list both expose the same menu on a stationary long press.
 let press=null,suppressClick=false;
 function cancelPress(){if(press)clearTimeout(press.timer);press=null}
 document.addEventListener('pointerdown',e=>{
  cancelPress();suppressClick=false;if(e.pointerType!=='touch'||boardReadOnly||phaseComparisonActive())return;
  const node=e.target.closest('#objects .obj,#objectList .object-row');if(!node||e.target.closest('input,.object-index')||e.target.closest('button')&&!e.target.closest('.object-name'))return;
  const p={id:e.pointerId,x:e.clientX,y:e.clientY,objectId:node.dataset.id};press=p;
  p.timer=setTimeout(()=>{if(press!==p)return;drag=null;suppressClick=true;if(!individualGroupSelectionActive()||!selectedIds.includes(p.objectId))selectedIds=selectedIds.includes(p.objectId)?expandObjectGroups(selectedIds):objectGroupIds(p.objectId);selected=p.objectId;renderSelectionOnly();openObjectContextMenu(p.objectId,p.x,p.y);cancelPress()},500);
 },true);
 document.addEventListener('pointermove',e=>{if(press&&press.id===e.pointerId&&Math.hypot(e.clientX-press.x,e.clientY-press.y)>8)cancelPress()},true);
 for(const type of ['pointerup','pointercancel'])document.addEventListener(type,cancelPress,true);
 document.addEventListener('click',e=>{if(suppressClick){suppressClick=false;if(e.isTrusted||e.target.closest('#objects .obj,#objectList .object-row')){e.preventDefault();e.stopImmediatePropagation()}}},true);
 // Keep the membership frame in sync with individual position/size edits.
 let groupContextFrame=0;
 new MutationObserver(()=>{if(groupContextFrame||!individualGroupSelectionActive())return;groupContextFrame=requestAnimationFrame(()=>{groupContextFrame=0;renderObjectGroupControls()})}).observe(layer,{subtree:true,childList:true,attributes:true,attributeFilter:['style','class']});
 // A second stationary press enters a member; dragging still moves the whole group.
 let memberPick=null;
 document.addEventListener('pointerdown',event=>{
  memberPick=null;if(event.button!==0||event.shiftKey||event.ctrlKey||event.metaKey||event.altKey||boardReadOnly||phaseComparisonActive()||tapPlacementArmed)return;
  const node=event.target.closest('#objects .obj');if(!node||node.isContentEditable)return;
  const item=current().find(o=>o.id===node.dataset.id),group=selectedObjectGroup();
  if(!item?.objectGroupId||!group.some(o=>o.id===item.id))return;
  memberPick={pointerId:event.pointerId,id:item.id,board:data,page:current(),x:event.clientX,y:event.clientY};
 },true);
 document.addEventListener('pointermove',event=>{if(memberPick?.pointerId===event.pointerId&&Math.hypot(event.clientX-memberPick.x,event.clientY-memberPick.y)>8)memberPick=null},true);
 document.addEventListener('pointerup',event=>{
  const pick=memberPick;memberPick=null;if(!pick||pick.pointerId!==event.pointerId||pick.board!==data||pick.page!==current()||suppressClick||drag?.moved||boardReadOnly||phaseComparisonActive())return;
  selectIndividualGroupMember(pick.id,false,true);
 },true);
 document.addEventListener('pointercancel',()=>{memberPick=null},true);
 window.addEventListener('blur',()=>{memberPick=null});

})();

// Built-in presets use field-relative positions; each insertion is one undo step.
function createPresetArtworkThumbnail(items){const thumb=document.createElement('span');thumb.className='preset-thumbnail';thumb.setAttribute('aria-hidden','true');const scene=document.createElement('span');scene.className='user-preset-scene';
  const xs=items.map(o=>o.x/100*640),ys=items.map(o=>o.y/100*640),left=Math.min(...items.map((o,i)=>xs[i]-(o.width||32)/2)),top=Math.min(...items.map((o,i)=>ys[i]-(o.height||32)/2)),right=Math.max(...items.map((o,i)=>xs[i]+(o.width||32)/2)),bottom=Math.max(...items.map((o,i)=>ys[i]+(o.height||32)/2)),extent=Math.max(right-left,bottom-top,32),scale=18/extent;
  scene.style.cssText='position:absolute;width:640px;height:640px;transform-origin:0 0;transform:scale('+scale+');left:'+((26-(right-left)*scale)/2-left*scale)+'px;top:'+((26-(bottom-top)*scale)/2-top*scale)+'px;';
  for(const [i,item] of items.entries()){const visual={...item,visible:true};if(visual.type==='icon'){const factor=Math.max(1,8/(scale*Math.min(visual.width||32,visual.height||32)));visual.width=(visual.width||32)*factor;visual.height=(visual.height||32)*factor}const node=createCanvasObjectVisual(visual,i,[]);node.style.pointerEvents='none';for(const img of node.querySelectorAll('img')){img.style.setProperty('width','100%','important');img.style.setProperty('height','100%','important');img.style.setProperty('max-width','none','important');img.style.setProperty('max-height','none','important')}scene.append(node)}thumb.append(scene);return thumb;
 }

function createSvgPresetItem(items){
 const visible=items.filter(item=>item.visible!==false);
 if(!visible.length)throw new Error('表示中のオブジェクトを選択してください');
 const scene=document.createElement('div');
 scene.className='stage';
 scene.style.cssText='position:fixed;left:-2000px;top:0;width:640px;height:640px;margin:0;transform:none;border:0;opacity:0;pointer-events:none';
 document.body.append(scene);
 try{
  visible.forEach((item,index)=>scene.append(createCanvasObjectVisual(item,index,[])));
  const origin=scene.getBoundingClientRect(),bounds=[...scene.children].map(node=>node.getBoundingClientRect());
  const left=Math.floor(Math.min(...bounds.map(box=>box.left))-origin.left)-8;
  const top=Math.floor(Math.min(...bounds.map(box=>box.top))-origin.top)-8;
  const width=Math.ceil(Math.max(...bounds.map(box=>box.right))-origin.left)-left+8;
  const height=Math.ceil(Math.max(...bounds.map(box=>box.bottom))-origin.top)-top+8;
  const artwork=document.createElementNS('http://www.w3.org/1999/xhtml','div');
  artwork.style.cssText='position:relative;width:100%;height:100%';
  for(const [index,node] of [...scene.children].entries()){
   const copy=clonePngNode(node),item=visible[index];
   for(const side of ['inline-start','inline-end','block-start','block-end'])copy.style.removeProperty('inset-'+side);
   copy.style.left=(item.x*6.4-left)+'px';copy.style.top=(item.y*6.4-top)+'px';
   copy.style.right='auto';copy.style.bottom='auto';
   artwork.append(copy);
  }
  const markup=new XMLSerializer().serializeToString(artwork);
  const svg='<svg xmlns="http://www.w3.org/2000/svg" width="'+width+'" height="'+height+'" viewBox="0 0 '+width+' '+height+'"><foreignObject width="100%" height="100%">'+markup+'</foreignObject></svg>';
  return {type:'icon',svgPreset:true,iconName:'SVGプリセット',src:'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg),x:50,y:50,width,height,rotation:0,opacity:100,additionalOpacityInitialized:true,visible:true};
 }finally{scene.remove()}
}

(function setupBuiltinPresets(){
 const button=document.getElementById('builtinFieldMarkers');
 const preview=button.querySelector('.preset-thumbnail');
 for(const [name,x,y] of [['A',50,12],['B',88,50],['C',50,88],['D',12,50],['1',22,22],['2',78,22],['3',78,78],['4',22,78]]){const img=document.createElement('img');img.src=objectImageSource({src:iconPath(name.toLowerCase(),'field-marker-transparent')});img.alt='';img.style.left=x+'%';img.style.top=y+'%';preview.append(img)}
 function bind(button,icon){button.draggable=true;button.onclick=()=>{if(boardReadOnly||phaseComparisonActive())return;selectPlacementIcon(icon)};button.ondragstart=event=>{if(boardReadOnly||phaseComparisonActive()){event.preventDefault();return}selectPlacementIcon(icon,false);event.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));event.dataTransfer.effectAllowed='copy'}}
 bind(button,{name:button.title,presetId:'field-markers',src:objectImageSource({src:iconPath('a','field-marker-transparent')})});
 const artworkButton=document.getElementById('builtinGroupArtwork');artworkButton.append(createPresetArtworkThumbnail(phaseGroupArtworkData.objects));bind(artworkButton,{name:'そう、＊＊よ。',presetId:'group-artwork'});

})();

function placeBuiltinGroupArtwork(cx,cy){
 if(boardReadOnly||phaseComparisonActive()||window.Bolxiv?.pngPreview?.active||window.Bolxiv?.phaseMasters?.active)return;
 const items=JSON.parse(JSON.stringify(phaseGroupArtworkData.objects)),groupId=createObjectId();for(const item of items){item.id=createObjectId();item.x+=cx-50;item.y+=cy-50;item.objectGroupId=groupId;item.objectGroupName='そう、＊＊よ。'}
 snapshot();current().push(...items);individualGroupSelection=null;selectedIds=items.map(item=>item.id);selected=selectedIds[0];setTapPlacementArmed(false);selectPlacementTool('select');hideTouchPlacementPreview();renderAndSave();closePaletteAfterPlacement();notify('「そう、＊＊よ。」を配置しました');
}

function placeBuiltinFieldMarkers(cx,cy){
  if(boardReadOnly||phaseComparisonActive()||window.Bolxiv?.pngPreview?.active)return;
  const size=data.pageFieldSizes[data.page]||{width:538,height:538};
  const positions=[['A',0,-.285],['B',.285,0],['C',0,.275],['D',-.285,0],['1',-.17,-.17],['2',.175,-.17],['3',.175,.16],['4',-.17,.16]];
  const items=positions.map(([name,x,y])=>createPlacementObject({type:'icon',name:'フィールド'+name,src:iconPath(name.toLowerCase(),'field-marker-transparent')},cx+x*size.width/640*100,cy+y*size.height/640*100));
  const groupId=createObjectId();for(const item of items){item.objectGroupId=groupId;item.objectGroupName='フィールドマーカー'}
  snapshot();current().push(...items);selected=items[0].id;selectedIds=items.map(item=>item.id);
  setTapPlacementArmed(false);selectPlacementTool('select');hideTouchPlacementPreview();
  renderAndSave();closePaletteAfterPlacement();notify('フィールドマーカー8個を配置しました');
}

// ===== js/canvas/edit-mode-setup.js =====
(function setupEditMode(){
 const button=document.getElementById('editModeToggle'),disabledForView=new Set();
 function syncControls(){
  if(!boardReadOnly&&!window.Bolxiv?.pngPreview?.active){
   const guides=!!window.Bolxiv?.fieldGuideEditor?.active,group=!!data.activePhaseGroup,palette='.left .tool,.left .icon-choice',groupTargets=palette+',#builtinFieldMarkers,#objectList button,#objectList input,#inspector input,#inspector select,#inspector button,#inspector textarea,#layoutPropertiesPanel input,#layoutPropertiesPanel select,#layoutPropertiesPanel textarea,#layoutPropertiesPanel button';
   const blocked=node=>(guides&&node.matches(palette))||(group&&node.matches(groupTargets)&&!node.closest('#phaseGroupProperties'));
   for(const node of disabledForView)if(!blocked(node)){node.disabled=false;disabledForView.delete(node)}
   if(guides||group)for(const node of document.querySelectorAll(group?groupTargets:palette)){if(blocked(node)&&!node.disabled){node.disabled=true;disabledForView.add(node)}}
   return;
  }
  for(const node of document.querySelectorAll(readOnlyEditTargets+',#objectList button,#inspector input,#inspector select,#inspector button')){
   if(window.Bolxiv?.pngPreview?.active&&node.matches('#undo,#redo')){disabledForView.delete(node);continue}if(!node.matches('button,input,select,textarea')||node.disabled)continue;
   node.disabled=true;disabledForView.add(node);
  }
  for(const node of disabledForView)if(!node.isConnected)disabledForView.delete(node);
 }
 const observer=new MutationObserver(syncControls);observer.observe(document.querySelector('.app'),{subtree:true,childList:true,attributes:true,attributeFilter:['disabled']});
 function update(){document.body.classList.toggle('board-read-only',boardReadOnly);updateModeStatus();syncControls()}
 document.addEventListener('board-view-mode-changed',update);

 const menu=document.createElement('div');menu.id='modeSwitchMenu';menu.className='mode-switch-menu';menu.hidden=true;menu.setAttribute('role','menu');menu.setAttribute('aria-label','モード切替');document.body.append(menu);
 button.removeAttribute('aria-pressed');button.setAttribute('aria-haspopup','menu');button.setAttribute('aria-controls',menu.id);button.setAttribute('aria-expanded','false');
 const modes=[['edit','編集モード'],['view','閲覧モード'],['image','画像生成モード'],['print','印刷モード']];
 let editContentOpen=null;
 function currentMode(){return window.Bolxiv?.pngPreview?.active?window.Bolxiv.pngPreview.kind:boardReadOnly||phaseComparisonActive()?'view':'edit'}
 function closeMenu(focus=false){menu.hidden=true;button.setAttribute('aria-expanded','false');if(focus)button.focus({preventScroll:true})}
 async function selectMode(mode){
  if(mode==='output')mode='image';
  if(window.Bolxiv?.pngPreview?.saving||!modes.some(([key])=>key===mode))return;
  closeMenu();if(currentMode()===mode)return;const contentWasOpen=document.querySelector('.layout').classList.contains('phone-content-open');if(currentMode()==='edit')editContentOpen=contentWasOpen;
  if(mode==='image'||mode==='print'){await window.Bolxiv.pngPreview.open(1,mode);return}
  if(window.Bolxiv?.pngPreview?.active){window.Bolxiv.pngPreview.close();if(currentMode()===mode)return}
  document.activeElement?.blur();if(mode==='edit')selectedPhaseIndexes=[];boardReadOnly=mode==='view';
  try{localStorage.setItem('bolxiv-read-only',String(boardReadOnly))}catch{}
  selected=null;selectedIds=[];drag=null;setTapPlacementArmed(false);selectPlacementTool('select');hideTouchPlacementPreview();clearAlignmentGuides();closeObjectContextMenu();closeColorPopovers();closeJsonImportMenu();
  update();render();document.querySelector('.layout').classList.toggle('phone-content-open',mode==='edit'?(editContentOpen??contentWasOpen):false);
 }
 window.Bolxiv.setMode=selectMode;
 for(const [mode,label] of modes){const item=document.createElement('button');item.type='button';item.dataset.mode=mode;item.textContent=label;item.setAttribute('role','menuitemradio');item.onclick=()=>selectMode(mode).catch(error=>notify('モードを切り替えられませんでした：'+(error?.message||String(error))));menu.append(item)}
 function openMenu(){if(button.disabled)return;closeObjectContextMenu();closeColorPopovers();closeJsonImportMenu();closeJsonExportMenu();closeHelpMenu();document.querySelector('.top').classList.remove('phone-menu-open');document.querySelector('.phone-menu-toggle')?.setAttribute('aria-expanded','false');for(const item of menu.querySelectorAll('[data-mode]'))item.setAttribute('aria-checked',String(item.dataset.mode===currentMode()));addPhoneMenuClose(menu,()=>closeMenu(true));menu.hidden=false;button.setAttribute('aria-expanded','true');const rect=button.getBoundingClientRect();menu.style.left=Math.max(8,Math.min(rect.left,innerWidth-menu.offsetWidth-8))+'px';menu.style.top=Math.max(8,Math.min(rect.bottom+4,innerHeight-menu.offsetHeight-8))+'px';menu.querySelector('[aria-checked="true"]')?.focus({preventScroll:true})}
 button.onclick=()=>menu.hidden?openMenu():closeMenu();
 button.addEventListener('keydown',e=>{if(['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();openMenu()}});
 window.addEventListener('pointerdown',e=>{if(!menu.hidden&&!menu.contains(e.target)&&!button.contains(e.target))closeMenu()},true);
 window.addEventListener('keydown',e=>{if(menu.hidden)return;if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();closeMenu(true);return}if(!menu.contains(e.target))return;if(e.key==='Tab'){closeMenu();return}if(!['ArrowDown','ArrowUp','Home','End'].includes(e.key))return;e.preventDefault();e.stopImmediatePropagation();const items=[...menu.querySelectorAll('button:not(:disabled)')],at=items.indexOf(document.activeElement);items[e.key==='Home'?0:e.key==='End'?items.length-1:(at+(e.key==='ArrowDown'?1:items.length-1))%items.length]?.focus()},true);
 for(const name of ['resize','blur'])window.addEventListener(name,()=>closeMenu());
 window.addEventListener('scroll',e=>{if(!menu.hidden&&!menu.contains(e.target))closeMenu()},true);
 button.insertAdjacentHTML('beforeend','<span class="mode-chevron" aria-hidden="true">▾</span>');

 update();
})();

;
// ===== js/canvas/palette-long-press.js =====
(()=>{
 const pane=document.querySelector('.left');let gesture=null,suppressButton=null,lastTouch=0;
 function finish(){if(!gesture)return;clearTimeout(gesture.timer);const g=gesture;gesture=null;hideTouchPlacementPreview();if(g.button.hasPointerCapture(g.id))g.button.releasePointerCapture(g.id);g.button.draggable=g.draggable;return g}
 pane.addEventListener('pointerdown',e=>{
  if(e.pointerType!=='touch')return;const button=e.target.closest('.tool[data-tool],.icon-choice');if(!button)return;
  finish();lastTouch=Date.now();const g={id:e.pointerId,x:e.clientX,y:e.clientY,button,draggable:button.draggable,wasSelected:button.classList.contains('active'),active:false,moved:false};gesture=g;button.draggable=false;
  g.timer=setTimeout(()=>{if(gesture!==g||!button.isConnected)return;g.active=true;button.focus({preventScroll:true});button.click();suppressButton=button;setTapPlacementArmed(true);g.payload=tool==='icon'&&activeIcon?{type:'icon',...activeIcon}:{type:tool};showTouchPlacementPreview(g.payload,g.x,g.y);button.setPointerCapture(g.id);button.classList.add('palette-dragging')},450);
 });
 document.addEventListener('pointermove',e=>{if(!gesture||gesture.id!==e.pointerId)return;const distance=Math.hypot(e.clientX-gesture.x,e.clientY-gesture.y);if(!gesture.active){if(distance>10)finish();return}gesture.moved=distance>10;moveTouchPlacementPreview(e.clientX,e.clientY);e.preventDefault();e.stopImmediatePropagation()},true);
 pane.addEventListener('touchmove',event=>{if(gesture?.active&&event.cancelable)event.preventDefault()},{passive:false});
 document.addEventListener('pointerup',e=>{
  if(gesture?.id!==e.pointerId)return;const g=finish();g.button.classList.remove('palette-dragging');if(!g.active)return;e.preventDefault();e.stopImmediatePropagation();
  if(g.wasSelected&&!g.moved){setTapPlacementArmed(false);selectPlacementTool('select');return}const r=stage.getBoundingClientRect(),point=touchPlacementPoint(e.clientX,e.clientY);if(g.moved&&point.x>=r.left&&point.x<=r.right&&point.y>=r.top&&point.y<=r.bottom&&!phaseComparisonActive()){placeObject(g.payload,point.x,point.y);setTapPlacementArmed(false);selectPlacementTool('select');closePaletteAfterPlacement()}
 },true);
 document.addEventListener('pointercancel',e=>{if(gesture?.id===e.pointerId){const g=finish();g.button.classList.remove('palette-dragging');suppressButton=null}},true);
 pane.addEventListener('click',e=>{if(e.isTrusted&&suppressButton){const same=e.target.closest('.tool[data-tool],.icon-choice')===suppressButton;suppressButton=null;if(same){e.preventDefault();e.stopImmediatePropagation()}}},true);
 pane.addEventListener('click',e=>{const button=e.target.closest('.tool[data-tool],.icon-choice');if(!e.isTrusted||!button?.classList.contains('active'))return;e.preventDefault();e.stopImmediatePropagation();setTapPlacementArmed(false);selectPlacementTool('select');hideTouchPlacementPreview()},true);
 pane.addEventListener('contextmenu',e=>{if(Date.now()-lastTouch<2500&&e.target.closest('.tool[data-tool],.icon-choice'))e.preventDefault()});
 window.addEventListener('blur',()=>{suppressButton=null;const g=finish();g?.button.classList.remove('palette-dragging')});
})();

;
// ===== js/canvas/palette-drag-state.js =====
(()=>{
 const pane=document.querySelector('.left'),builtinBitmaps=new WeakMap();let nativeDragImage=null;
 function prepareBuiltin(button){
  const cached=builtinBitmaps.get(button);if(cached)return cached;
  const entry={bitmap:null};builtinBitmaps.set(button,entry);
  const host=document.createElement('div'),source=button.querySelector('.preset-thumbnail').cloneNode(true);host.className='left pinned';host.inert=true;host.setAttribute('aria-hidden','true');host.style.cssText='display:block!important;position:fixed!important;left:-10000px!important;top:0!important;width:26px!important;height:26px!important;padding:0!important;border:0!important;overflow:hidden!important;pointer-events:none!important';source.style.cssText='display:block;position:relative;width:26px;height:26px;overflow:hidden;background:transparent';const wrapper=document.createElement('div');wrapper.className='builtin-preset';wrapper.append(source);host.append(wrapper);document.body.append(host);
  rasterizePngSource(source,3).then(bitmap=>{entry.bitmap=bitmap;button.dataset.dragPreviewReady='true';}).catch(()=>builtinBitmaps.delete(button)).finally(()=>host.remove());return entry;
 }
 const warmBuiltins=()=>pane.querySelectorAll('.builtin-preset').forEach(prepareBuiltin);if(window.requestIdleCallback)requestIdleCallback(warmBuiltins,{timeout:1000});else setTimeout(warmBuiltins,0);
 pane.addEventListener('pointerover',event=>{const button=event.target.closest('.builtin-preset');if(button)prepareBuiltin(button);});
 function clear(){nativeDragImage?.remove();nativeDragImage=null;pane.querySelectorAll('.palette-dragging').forEach(button=>button.classList.remove('palette-dragging'))}
 pane.addEventListener('dragstart',e=>{
 clear();const button=e.target.closest('.tool[data-tool],.icon-choice');if(!button)return;button.classList.add('palette-dragging');
 if(button.matches('.user-preset,.builtin-preset')){
  const bitmap=button.classList.contains('user-preset')?userPresetLibrary.dragImage(button.dataset.presetId):prepareBuiltin(button).bitmap;
  if(!bitmap){e.preventDefault();clear();notify('プリセットのプレビューを準備中です。少し待ってからもう一度ドラッグしてください。');return}
  // A flat bitmap has no transformed DOM bounds for Chromium to include.
  const image=document.createElement('canvas');image.width=image.height=48;image.className='palette-native-drag-image';image.setAttribute('aria-hidden','true');
  image.style.cssText='position:fixed;left:-10000px;top:0;width:48px;height:48px;pointer-events:none;border:0;padding:0;margin:0;';
  image.getContext('2d').drawImage(bitmap,0,0,48,48);document.body.append(image);nativeDragImage=image;e.dataTransfer.setDragImage(image,24,24);return;
 }

 const artwork=button.querySelector('.preset-thumbnail')||button.querySelector('img,.glyph');if(!artwork||!e.dataTransfer)return;
 const preview=document.createElement('div');preview.style.cssText='position:fixed;left:-10000px;top:0;width:48px;height:48px;display:grid;place-items:center;background:transparent;border:0;box-shadow:none;pointer-events:none;';
 const clone=artwork.cloneNode(true);clone.style.cssText='display:grid;place-items:center;width:48px;height:48px;max-width:none;max-height:none;background:transparent;border:0;box-shadow:none;color:#f39c12;font-size:32px;';
 const svg=clone.querySelector('svg');if(svg){svg.style.width='48px';svg.style.height='48px'}
 preview.append(clone);
 document.body.append(preview);e.dataTransfer.setDragImage(preview,24,24);setTimeout(()=>preview.remove(),0);
});
 document.addEventListener('dragend',clear);document.addEventListener('drop',clear);window.addEventListener('blur',clear);
})();

;
// ===== js/canvas/palette-open-without-toggle.js =====
(()=>{
 const pane=document.querySelector('.left');let opening=false,openingPointer=null,suppressClick=false;
 // Delay mouse hover expansion; focus and pinned styles remain immediate.
 const desktopHover=matchMedia('(min-width:851px) and (hover:hover)');let hoverTimer=null;
 function clearDelayedHover(){clearTimeout(hoverTimer);hoverTimer=null;pane.classList.remove('palette-hover-open')}
 pane.addEventListener('pointerenter',e=>{
  clearDelayedHover();
  if(e.pointerType!=='mouse'||!desktopHover.matches||pane.classList.contains('pinned'))return;
  hoverTimer=setTimeout(()=>{hoverTimer=null;if(desktopHover.matches)pane.classList.add('palette-hover-open')},300);
 });
 pane.addEventListener('reset-material-hover',clearDelayedHover);
 pane.addEventListener('pointerleave',clearDelayedHover);
 pane.addEventListener('pointercancel',clearDelayedHover);
 window.addEventListener('blur',clearDelayedHover);
 desktopHover.addEventListener('change',clearDelayedHover);
 pane.setAttribute('tabindex','-1');
 function clearOpeningStyleIfClosed(){if(!pane.matches(':focus-within')&&!pane.matches(':hover')&&!pane.classList.contains('pinned'))pane.classList.remove('palette-opening-neutral')}
 pane.addEventListener('focusout',()=>queueMicrotask(()=>{if(!pane.matches(':focus-within'))pane.classList.remove('palette-opening-neutral')}));
 pane.addEventListener('pointerleave',()=>queueMicrotask(clearOpeningStyleIfClosed));
 document.addEventListener('pointerdown',e=>{if(!pane.contains(e.target)){pane.classList.remove('palette-opening-neutral');if(pane.contains(document.activeElement))document.activeElement.blur()}},true);

 pane.addEventListener('pointerenter',e=>{opening=e.pointerType!=='mouse'&&!pane.classList.contains('pinned')&&!pane.matches(':focus-within');if(e.pointerType==='mouse')pane.classList.remove('palette-opening-neutral')});
 pane.addEventListener('pointerleave',()=>{if(openingPointer===null)opening=false});
 document.addEventListener('pointerdown',e=>{
  if(!pane.contains(e.target))return;pane.classList.remove('palette-opening-neutral');if(e.pointerType!=='touch'&&e.pointerType!=='pen')return;
  suppressClick=false;
  const railButton=e.target.closest('button');const compactButton=railButton&&railButton.getBoundingClientRect().width<=44;const closed=!pane.classList.contains('pinned')&&(opening||!pane.matches(':focus-within')||pane.getBoundingClientRect().width<100||compactButton&&railButton.matches('.accordion-toggle'));
  if(!closed)return;
  // Consume the complete opening gesture before focusing expands the rail.
  e.preventDefault();e.stopImmediatePropagation();openingPointer=e.pointerId;suppressClick=true;opening=false;pane.classList.add('palette-opening-neutral');pane.focus({preventScroll:true});pane.setPointerCapture(e.pointerId);
 },true);
 for(const type of ['pointerup','pointercancel'])pane.addEventListener(type,e=>{if(e.pointerId!==openingPointer)return;e.preventDefault();e.stopImmediatePropagation();openingPointer=null;if(pane.hasPointerCapture(e.pointerId))pane.releasePointerCapture(e.pointerId)},true);
 document.addEventListener('click',e=>{if(suppressClick&&e.isTrusted){suppressClick=false;e.preventDefault();e.stopImmediatePropagation()}},true);
 pane.addEventListener('click',e=>{
  if(suppressClick){suppressClick=false;e.preventDefault();e.stopImmediatePropagation();return}
  const button=e.target.closest('.accordion-toggle:not(.rail-toggle)');if(!button)return;
  const expandOnly=opening&&!pane.classList.contains('pinned');opening=false;if(!expandOnly)return;e.preventDefault();e.stopImmediatePropagation();button.focus({preventScroll:true});
 },true);
})();

;
// ===== js/mobile/mobile-layout.js =====
(function setupPhoneLayout(){
 const mobile=matchMedia('(max-width:850px)'),layout=document.querySelector('.layout');
 const nav=document.createElement('nav');nav.className='phone-nav';nav.setAttribute('aria-label','スマホの画面切り替え');
 for(const [pane,label] of [['canvas','キャンバス']]){
  const button=document.createElement('button');button.type='button';button.textContent=label;button.dataset.pane=pane;button.setAttribute('aria-pressed',String(pane==='canvas'));
  button.onclick=()=>{closeMaterials();if(mobile.matches&&pane==='content'){layout.dataset.phonePane='canvas';layout.classList.add('phone-content-open');for(const item of nav.children)item.setAttribute('aria-pressed',String(item===button));return}layout.classList.remove('phone-content-open');layout.dataset.phonePane=pane;for(const item of nav.children)item.setAttribute('aria-pressed',String(item===button))};nav.append(button);
 }
 layout.dataset.phonePane='canvas';
 const contentIcon=document.createElement('button');contentIcon.type='button';contentIcon.className='phone-content-icon';contentIcon.setAttribute('aria-label','コンテンツを表示');contentIcon.title='コンテンツを表示';contentIcon.setAttribute('aria-controls','battlePanel');contentIcon.setAttribute('aria-expanded','false');
 contentIcon.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>';
 document.querySelector('.board-display-toolbar').prepend(contentIcon);
 contentIcon.onclick=()=>{closeMaterials();layout.classList.add('phone-content-open')};
 new MutationObserver(()=>contentIcon.setAttribute('aria-expanded',String(layout.classList.contains('phone-content-open')))).observe(layout,{attributes:true,attributeFilter:['class']});

 const materialPane=document.querySelector('.left'),pin=document.createElement('button');let desktopMaterialPinned=materialPane.classList.contains('pinned'),materialOpenObjectCount=0;
 const placementHelp=document.createElement('div');placementHelp.className='phone-material-help';placementHelp.innerHTML='<p>タップ→盤面タップで配置</p><p>長押し→移動・離して配置</p>';materialPane.querySelector('.object-pane-actions').append(placementHelp);
 const categoryStrip=document.createElement('div');categoryStrip.className='phone-material-category-tabs';categoryStrip.setAttribute('role','tablist');categoryStrip.setAttribute('aria-label','素材カテゴリー');
 const categoryTabs=[...materialPane.querySelectorAll('.accordion-group>.accordion-toggle[aria-controls]')].map(heading=>{
  const tab=document.createElement('button');tab.type='button';tab.className='btn';const name=heading.textContent.trim(),icon=heading.querySelector('.palette-category-icon')?.cloneNode(true)||document.createElement('span');icon.className='phone-material-category-icon';icon.setAttribute('aria-hidden','true');if(!icon.childNodes.length)icon.textContent=heading.dataset.railIcon||name;for(const node of icon.querySelectorAll('[stroke],[fill]'))for(const attribute of ['stroke','fill'])if(node.hasAttribute(attribute)&&!['none','transparent'].includes(node.getAttribute(attribute)))node.setAttribute(attribute,'currentColor');tab.append(icon);tab.title=name;tab.setAttribute('aria-label',name);tab.setAttribute('role','tab');tab.setAttribute('aria-controls',heading.getAttribute('aria-controls'));categoryStrip.append(tab);
  tab.onclick=()=>{if(heading.getAttribute('aria-expanded')!=='true')heading.click();syncCategoryTabs();const list=materialPane.querySelector('.material-categories-scroll');if(list)list.scrollTop=0;const bounds=tab.getBoundingClientRect(),strip=categoryStrip.getBoundingClientRect();if(bounds.left<strip.left)categoryStrip.scrollLeft+=bounds.left-strip.left;else if(bounds.right>strip.right)categoryStrip.scrollLeft+=bounds.right-strip.right};return {heading,tab};
 });
 function syncCategoryTabs(){if(!categoryTabs.some(({heading})=>heading.getAttribute('aria-expanded')==='true'))categoryTabs[0]?.heading.click();for(const {heading,tab} of categoryTabs){const active=heading.getAttribute('aria-expanded')==='true';tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1}}
 categoryStrip.addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();const at=categoryTabs.findIndex(({tab})=>tab===event.target),index=event.key==='Home'?0:event.key==='End'?categoryTabs.length-1:(at+(event.key==='ArrowRight'?1:categoryTabs.length-1))%categoryTabs.length;categoryTabs[index].tab.click();categoryTabs[index].tab.focus({preventScroll:true})});
 materialPane.insertBefore(categoryStrip,materialPane.querySelector('.accordion-group'));
 pin.type='button';pin.className='btn phone-material-pin';pin.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="6.5" cy="6.5" r="3.5"/><rect x="14" y="3" width="7" height="7" rx="1"/><path d="m6.5 13 4.5 8H2z"/><path d="m17.5 13 4.5 4.5-4.5 4.5-4.5-4.5z"/></svg>';
 pin.setAttribute('aria-label','マテリアルを開く');pin.title='マテリアルを開く';pin.setAttribute('aria-expanded','false');
 if(!materialPane.id)materialPane.id='materialPane';pin.setAttribute('aria-controls',materialPane.id);
 document.getElementById('objectLayerPanel').append(pin);
 function closeMaterials(){if(layout.classList.contains('phone-materials-open'))materialPane.classList.toggle('pinned',desktopMaterialPinned);layout.classList.remove('phone-materials-open');pin.setAttribute('aria-expanded','false');pin.setAttribute('aria-label','マテリアルを開く');pin.title='マテリアルを開く'}
 pin.onclick=()=>{if(layout.classList.contains('phone-materials-open')){closeMaterials();return}const panel=document.getElementById('objectLayerPanel'),rect=[...panel.querySelectorAll(':scope>.property-group')].find(node=>node.checkVisibility()).getBoundingClientRect(),style=getComputedStyle(panel),paneTop=panel.dataset.objectExpanded==='false'?panel.getBoundingClientRect().top+(parseFloat(style.paddingTop)||0)+phoneCanvasDisplayHeight(panel)+(parseFloat(style.rowGap)||0):rect.top,top=(paneTop-layout.getBoundingClientRect().top)+'px';if(layout.style.getPropertyValue('--phone-material-top')!==top)layout.style.setProperty('--phone-material-top',top);materialOpenObjectCount=current().length;if(!layout.classList.contains('phone-materials-open'))desktopMaterialPinned=materialPane.classList.contains('pinned');materialPane.classList.add('pinned');let firstOpen=null;for(const category of materialPane.querySelectorAll('.accordion-toggle[aria-controls]')){if(category.getAttribute('aria-expanded')!=='true')continue;if(!firstOpen){firstOpen=category;continue}category.setAttribute('aria-expanded','false');document.getElementById(category.getAttribute('aria-controls')).hidden=true}layout.classList.add('phone-materials-open');syncCategoryTabs();pin.setAttribute('aria-expanded','true');pin.setAttribute('aria-label','マテリアルを閉じる');pin.title='マテリアルを閉じる'};
 
 document.addEventListener('close-material-pane',closeMaterials);
 mobile.addEventListener('change',closeMaterials);
 // Selection keeps the palette open for re-selection; placement completion closes it.
 let materialDismissClick=false;
 document.addEventListener('pointerdown',event=>{
  materialDismissClick=false;
  if(!mobile.matches||!layout.classList.contains('phone-materials-open')||operationGuide.open||materialPane.classList.contains('preset-registering')||document.querySelector('#userPresetDialog[open]'))return;
  if(event.target.closest('#pcTutorial,#userPresetMenu,#objectContextMenu,#layerContextMenu')||materialPane.contains(event.target)||pin.contains(event.target)||contentIcon.contains(event.target))return;
  materialDismissClick=true;
  event.preventDefault();event.stopImmediatePropagation();
  closeMaterials();
 },true);
 document.addEventListener('click',event=>{
  if(!materialDismissClick)return;
  materialDismissClick=false;
  event.preventDefault();event.stopImmediatePropagation();
 },true);
 new MutationObserver(()=>{
  if(mobile.matches&&layout.classList.contains('phone-materials-open')&&current().length>materialOpenObjectCount)closeMaterials();
 }).observe(document.getElementById('objects'),{childList:true});


 // Pane changes retain the current zoom and browser scroll position.
 // Fitting is performed only by the explicit fit button.
})();

(function setupPhoneDisplayMenu(){
 const mobile=matchMedia('(max-width:850px)'),toolbar=document.querySelector('.board-display-toolbar'),trigger=document.createElement('button'),menu=document.createElement('div');
 trigger.type='button';trigger.className='board-grid-toggle phone-display-menu-toggle';trigger.title='表示設定';trigger.setAttribute('aria-label','表示設定');trigger.setAttribute('aria-haspopup','menu');trigger.setAttribute('aria-expanded','false');trigger.setAttribute('aria-controls','phoneDisplayMenu');
 trigger.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M5 3v4m0 5v9M12 3v10m0 5v3M19 3v4m0 5v9"/><rect x="2.5" y="7" width="5" height="5" rx="1"/><rect x="9.5" y="13" width="5" height="5" rx="1"/><rect x="16.5" y="7" width="5" height="5" rx="1"/></svg>';
 toolbar.insertBefore(trigger,document.getElementById('gridToggle'));
 menu.id='phoneDisplayMenu';menu.className='phone-display-menu';menu.hidden=true;menu.setAttribute('role','menu');menu.setAttribute('aria-label','表示設定');document.body.append(menu);
 const items=[['gridToggle','グリッド線の表示・間隔'],['fieldToggle','フィールドを表示'],['clipToggle','フィールド外を表示']].map(([id,label])=>{
  const source=document.getElementById(id),item=document.createElement('button');item.type='button';item.setAttribute('role','menuitemcheckbox');if(id==='gridToggle')item.setAttribute('aria-haspopup','menu');item.innerHTML='<span>'+label+'</span><span class="phone-display-state" aria-hidden="true"></span>';
  const sync=()=>{const pressed=source.getAttribute('aria-pressed')==='true',checked=id==='clipToggle'?!pressed:pressed;item.setAttribute('aria-checked',String(checked));item.lastElementChild.textContent=id==='gridToggle'?'▸':checked?'オン':'オフ';item.disabled=source.disabled};
  item.onclick=()=>{if(id==='gridToggle'){const bounds=item.getBoundingClientRect();window.Bolxiv.openGridMenu?.(trigger,bounds);return}source.click();sync();item.focus({preventScroll:true})};new MutationObserver(sync).observe(source,{attributes:true,attributeFilter:['aria-pressed','disabled']});sync();menu.append(item);return item;
 });
 const separator=document.createElement('div');separator.className='phone-display-menu-separator';separator.setAttribute('role','separator');menu.append(separator);
 const closeButton=document.createElement('button');closeButton.type='button';closeButton.setAttribute('role','menuitem');closeButton.textContent='閉じる';closeButton.onclick=()=>close(true);menu.append(closeButton);items.push(closeButton);
 function close(focus=false){menu.hidden=true;trigger.setAttribute('aria-expanded','false');if(focus)trigger.focus({preventScroll:true})}
 function open(){if(!mobile.matches)return;document.querySelector('#boardZoomMenu:not([hidden])')&&document.getElementById('resetBoardZoom').click();menu.hidden=false;trigger.setAttribute('aria-expanded','true');const rect=trigger.getBoundingClientRect();menu.style.left=Math.max(8,Math.min(rect.left,innerWidth-menu.offsetWidth-8))+'px';menu.style.top=Math.max(8,Math.min(rect.bottom+4,innerHeight-menu.offsetHeight-8))+'px';items[0].focus({preventScroll:true})}
 trigger.onclick=()=>menu.hidden?open():close();
 window.addEventListener('keydown',event=>{if(!menu.hidden&&event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();close(true)}},true);
 trigger.addEventListener('keydown',event=>{if(event.key==='ArrowDown'){event.preventDefault();open()}});
 menu.addEventListener('keydown',event=>{const index=items.indexOf(document.activeElement);if(event.key==='Escape'){event.preventDefault();close(true)}else if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();items[(index+(event.key==='ArrowDown'?1:items.length-1))%items.length].focus()}else if(event.key==='Home'||event.key==='End'){event.preventDefault();items[event.key==='Home'?0:items.length-1].focus()}else if(event.key==='Tab')close()});
 document.addEventListener('pointerdown',event=>{if(!menu.contains(event.target)&&!trigger.contains(event.target)&&!event.target.closest('#boardGridMenu'))close()},true);
 window.addEventListener('resize',()=>close());window.addEventListener('scroll',event=>{if(!menu.contains(event.target))close()},true);mobile.addEventListener('change',()=>close());
})();

;
// ===== js/mobile/mobile-object-panels.js =====
(function syncPhoneObjectPanels(){
 const mobile=matchMedia('(max-width:850px)'),layers=document.getElementById('toggleLayers'),objects=document.getElementById('toggleInspector');let syncing=false;
 function sync(source,target){if(!mobile.matches||syncing)return;if(source.getAttribute('aria-expanded')===target.getAttribute('aria-expanded'))return;syncing=true;try{target.click()}finally{syncing=false}}
 layers.addEventListener('click',()=>sync(layers,objects));objects.addEventListener('click',()=>sync(objects,layers));
 mobile.addEventListener('change',()=>sync(layers,objects));sync(layers,objects);
})();

;
// ===== js/mobile/mobile-delete-dialog.js =====
const phoneLayerDeletion=createConfirmationView({id:'phoneLayerDeleteDialog',messageId:'phoneLayerDeleteMessage',cancelId:'phoneLayerDeleteCancel',confirmId:'phoneLayerDeleteConfirm',autofocus:true,onConfirm(pending){if(data===pending.board&&current()===pending.page)removeObject(pending.id,pending.individual)}});
function confirmPhoneLayerDeletion(id,individual=false){
 const object=current().find(item=>item.id===id);if(!object||object.locked)return;
 phoneLayerDeletion.show('「'+(object.objectGroupId&&!individual?objectGroupName(current().filter(o=>o.objectGroupId===object.objectGroupId))+'（'+objectGroupIds(id).length+'個）':objectTitle(object))+'」を削除しますか？',{id,individual,board:data,page:current()});
}

;
// ===== js/mobile/mobile-content-panel.js =====
(function phoneContentPopup(){
 const mobile=matchMedia('(max-width:850px)'),layout=document.querySelector('.layout'),panel=layout.querySelector('.battle'),canvas=layout.querySelector('.right');
 const reducedMotion=matchMedia('(prefers-reduced-motion:reduce)'),originalInert=canvas.inert;
 const viewport=document.getElementById('boardZoomSpace').parentElement,anchor=document.createComment('phone preview canvas home');viewport.before(anchor);
 const preview=document.createElement('div');preview.className='phone-content-preview';preview.hidden=true;preview.setAttribute('aria-label','キャンバスプレビュー');document.querySelector('.content-select-row').before(preview);
 const originalViewportInert=viewport.inert;
 const originalOpacity=viewport.style.getPropertyValue('opacity'),originalOpacityPriority=viewport.style.getPropertyPriority('opacity');
 let savedPosition=null,previewFrame=null,mountFrame=null;
 function restoreOpacity(){if(originalOpacity)viewport.style.setProperty('opacity',originalOpacity,originalOpacityPriority);else viewport.style.removeProperty('opacity')}
 function capturePosition(){const ancestors=[];for(let node=viewport.parentElement;node;node=node.parentElement)ancestors.push({node,left:node.scrollLeft,top:node.scrollTop});return {left:viewport.scrollLeft,top:viewport.scrollTop,ancestors}}
 function restorePosition(position){if(viewport.parentElement===preview)return;for(const item of position.ancestors){item.node.scrollLeft=item.left;item.node.scrollTop=item.top}viewport.scrollLeft=position.left;viewport.scrollTop=position.top}
 window.Bolxiv.contentPanePosition={capture:()=>savedPosition||capturePosition(),restore(position){if(!position)return;if(layout.classList.contains('phone-content-open'))savedPosition=position;else{restorePosition(position);requestAnimationFrame(()=>restorePosition(position))}}};
 for(const button of document.querySelectorAll('.phone-content-icon,.phone-nav [data-pane="content"]')){const open=button.onclick;button.onclick=function(event){if(mobile.matches&&!layout.classList.contains('phone-content-open'))savedPosition=capturePosition();return open?.call(this,event)}}
 function fitPreview(){
  previewFrame=null;if(preview.hidden||viewport.parentElement!==preview)return;
  const comparison=document.querySelector('.phase-comparison-grid'),width=comparison?comparison.offsetWidth:640,height=comparison?comparison.offsetHeight:640;
  const scale=String(Math.max(0.01,Math.min(Math.max(0,viewport.clientWidth-8)/width,Math.max(0,viewport.clientHeight-8)/height)));
  // Only the surface consumes this non-inherited property. Updating it on the
  // whole preview used to invalidate styles for every object and SVG child.
  for(const surface of document.getElementById('boardZoomSpace').children)if(surface.matches('.stage,.phase-comparison-grid,.phase-group-overview')&&surface.style.getPropertyValue('--phone-preview-scale')!==scale)surface.style.setProperty('--phone-preview-scale',scale);
  if(viewport.scrollLeft)viewport.scrollLeft=0;if(viewport.scrollTop)viewport.scrollTop=0;
  restoreOpacity();preview.removeAttribute('aria-busy');
 }
 function schedulePreview(){if(preview.hidden||viewport.parentElement!==preview||closing||previewFrame!==null)return;previewFrame=requestAnimationFrame(fitPreview)}
 function syncPreview(open){
  if(window.Bolxiv?.pngPreview?.active)window.Bolxiv.pngPreview.setContentPreview(open,viewport);
  preview.hidden=!open;viewport.inert=open||originalViewportInert;
  if(open){if(viewport.parentElement!==preview){savedPosition??=capturePosition();viewport.style.opacity='0';preview.append(viewport)}schedulePreview()}
  else{
   cancelAnimationFrame(previewFrame);previewFrame=null;preview.removeAttribute('aria-busy');restoreOpacity();
   if(viewport.parentElement===preview)anchor.after(viewport);
   const position=savedPosition;savedPosition=null;if(position){restorePosition(position);requestAnimationFrame(()=>{restorePosition(position);requestAnimationFrame(()=>restorePosition(position))})}
  }
 }
 new ResizeObserver(schedulePreview).observe(preview);
 const renderBeforeContentPreview=render;render=function(){renderBeforeContentPreview();if(!preview.hidden)schedulePreview()};
 const backdrop=document.createElement('button');backdrop.type='button';backdrop.className='phone-content-backdrop';backdrop.hidden=true;backdrop.setAttribute('aria-label','コンテンツ管理ペインを閉じる');layout.append(backdrop);
 let visible=false,closing=false,panelAnimation=null,backdropAnimation=null,closeAnimation=null;
 const duration=(closing=false)=>reducedMotion.matches?0:closing?120:200;
 // The phone pane is width:calc(100% - 28px). CSS units avoid a forced layout
 // read of panel.offsetWidth immediately after moving the canvas subtree.
 const offscreen='translateX(calc(28px - 100vw))';
 function cancelAnimations(){cancelAnimationFrame(mountFrame);mountFrame=null;panelAnimation?.cancel();backdropAnimation?.cancel();closeAnimation?.cancel();panelAnimation=backdropAnimation=closeAnimation=null}
 function sync(){
  const open=mobile.matches&&layout.classList.contains('phone-content-open');
  if(open===visible)return;
  cancelAnimations();visible=open;closing=false;canvas.inert=open||originalInert;backdrop.hidden=!open;
  closeButton.style.removeProperty('visibility');
  if(open){preview.hidden=false;preview.setAttribute('aria-busy','true');viewport.inert=true}else syncPreview(false);
  if(open){
   panelAnimation=panel.animate([{transform:'translateX(-100%)'},{transform:'translateX(0)'}],{duration:duration(),easing:'ease-out'});
   closeAnimation=closeButton.animate([{transform:offscreen},{transform:'translateX(0)'}],{duration:duration(),easing:'ease-out'});
   backdropAnimation=backdrop.animate([{opacity:0},{opacity:1}],{duration:duration(),easing:'ease-out'});
   // Hold the pane offscreen until the live preview has its final size.
   // fitPreview is queued first, so start the slide in the same prepared frame.
   const opening=panelAnimation;
   panelAnimation.pause();closeAnimation.pause();backdropAnimation.pause();
   syncPreview(true);
   mountFrame=requestAnimationFrame(()=>{
    mountFrame=null;
    if(!visible||closing||!mobile.matches||panelAnimation!==opening)return;
    panelAnimation.play();closeAnimation.play();backdropAnimation.play();
   });
  }
 }
 function close(hideCloseButton=false){
  if(closing||!layout.classList.contains('phone-content-open'))return;
  cancelAnimations();closing=true;
  cancelAnimationFrame(previewFrame);previewFrame=null;
  // Stop navigation geometry updates while the pane is sliding away.
  preview.setAttribute('aria-busy','true');
  if(hideCloseButton===true)closeButton.style.visibility='hidden';
  panelAnimation=panel.animate([{transform:'translateX(0)'},{transform:'translateX(-100%)'}],{duration:duration(true),easing:'ease-out',fill:'forwards'});
  closeAnimation=closeButton.animate([{transform:'translateX(0)'},{transform:offscreen}],{duration:duration(true),easing:'ease-out',fill:'forwards'});
  backdropAnimation=backdrop.animate([{opacity:1},{opacity:0}],{duration:duration(true),easing:'ease-out',fill:'forwards'});
  const ending=panelAnimation;
  ending.finished.then(()=>{
   if(panelAnimation!==ending||!closing)return;
   layout.classList.remove('phone-content-open');sync();closeButton.style.removeProperty('visibility');
   if(mobile.matches){for(const button of document.querySelectorAll('.phone-nav button'))button.setAttribute('aria-pressed',String(button.dataset.pane==='canvas'));document.querySelector('.phone-content-icon')?.focus({preventScroll:true})}
  }).catch(()=>{});
 }
 backdrop.onclick=close;
 const closeButton=document.createElement('button');closeButton.type='button';closeButton.className='phone-content-close';closeButton.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" width="24" height="24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"><path d="M15 5l-7 7 7 7"/></svg>';closeButton.setAttribute('aria-label','コンテンツ管理ペインを閉じる');closeButton.title='コンテンツ管理ペインを閉じる';closeButton.onclick=()=>close(true);layout.append(closeButton);
 document.addEventListener('keydown',event=>{
  if(!mobile.matches||!layout.classList.contains('phone-content-open')||event.target.closest?.('#phoneIconHelp,dialog.confirm-dialog'))return;
  if(event.target.closest('input,select,textarea,[contenteditable="true"],dialog'))return;
  if(event.isComposing||event.keyCode===229)return;
  if(event.key==='Escape'){event.preventDefault();close();return}
  const key=event.key.toLowerCase(),shortcut=(event.ctrlKey||event.metaKey)&&['c','v','x','z','y'].includes(key),objectAction=['delete','backspace'].includes(key)||key.startsWith('arrow')&&!event.target.closest('#pages,button,[role="separator"]');
  if(shortcut||objectAction){event.preventDefault();event.stopImmediatePropagation()}
 },true);
 new MutationObserver(sync).observe(layout,{attributes:true,attributeFilter:['class']});
 mobile.addEventListener('change',()=>{layout.classList.remove('phone-content-open');sync()});sync();
 document.addEventListener('pointerdown',event=>{if(!mobile.matches||!visible||event.composedPath().some(node=>node instanceof Element&&node.matches('#editModeToggle,#modeSwitchMenu,#undo,#redo,.battle,.phone-phase-navigation,.phone-content-backdrop,.phone-content-close,.color-popover,.native-color-picker,.phone-nav,.phone-content-icon,.phase-content-copy-menu,.phase-item-menu,.content-item-menu,.phase-group-menu,.phase-copy-menu,#phaseMasterMenu,dialog.confirm-dialog,#phoneIconHelp,#pcTutorial')))return;close()},true);
})();

;
// ===== js/mobile/mobile-icon-help.js =====
(function setupPhoneIconHelp(){
 const mobile=matchMedia('(max-width:850px)'),toolbar=document.querySelector('.board-display-toolbar'),button=document.createElement('button');button.type='button';button.className='phone-icon-help-toggle';button.textContent='？';button.setAttribute('aria-label','アイコンの説明');button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-controls','phoneIconHelp');button.setAttribute('aria-expanded','false');toolbar.parentElement.append(button);
 const panel=document.createElement('dialog');panel.id='phoneIconHelp';panel.className='phone-icon-help';panel.setAttribute('aria-labelledby','phoneIconHelpTitle');panel.innerHTML='<div class="phone-icon-help-heading"><h2 id="phoneIconHelpTitle">アイコンの説明</h2><button type="button" class="btn">閉じる</button></div><div class="phone-icon-help-list"></div>';document.body.append(panel);
 const entries=[
  [
    "#editModeToggle",
    "編集・閲覧・画像生成・印刷を切り替えます。"
  ],
  [
    "help-png-mode",
    "編集・閲覧・画像生成・印刷を切り替えます。"
  ],
  [
    "#pngPropertiesToggle",
    "出力の設定欄を開閉します。"
  ],
  [
    ".phone-menu-toggle",
    "保存・読み込み・カスタマイズ・ヘルプなどのメニューを開きます。背景画像はカスタマイズから設定します。"
  ],
  [
    ".phone-content-icon",
    "コンテンツ・フェーズ・設定・ノートを開きます。"
  ],
  [
    ".phone-content-close",
    "コンテンツ管理ペインを閉じます。"
  ],
  [
    ".phone-material-pin",
    "素材の一覧を開閉します。"
  ],
  ["#phaseMasterModeToggle","コンテンツ／フィールドを切り替えます。フィールドへ移るときは、選択中フェーズの使用フィールドを表示します。"],
  ["#editUsedField","使用中のフィールドを選択して編集画面へ移動します。"],
  ["#addPhaseMaster","フィールド・グループの追加、同じ設定の統合、未使用フィールドの一括削除を選べます。"],
  ["#duplicatePhaseMaster","選択中のフィールドを複製します。フェーズの使用先は変わりません。"],
  ["#phaseMasterSelect","このフェーズで使用するフィールドを選びます。"],
  [
    "#addPage",
    "フェーズ／グループの追加を選びます。Enter・✓で確定、Esc・↶で取消。"
  ],
  [
    "#copyPage",
    "フェーズやグループの複製先を選びます。"
  ],
  [
    "#copyPageToContent",
    "別コンテンツへ複製します。元のデータは残します。"
  ],
  [
    "#phonePhaseSwitch-toggle",
    "フェーズリストとプロパティを切り替えます。ノートはプロパティ内です。"
  ],
  [
    "#phonePhaseSectionToggle",
    "設定・ノート欄を開閉します。"
  ],
  [
    "#phasePropertyResize",
    "上下に動かして欄の高さを調整します。"
  ],
  [
    "#toggleBattlePages",
    "フェーズリストを開閉します。"
  ],
  [
    ".phase-select-check",
    "並べて表示するフェーズを選びます。最大12個です。"
  ],
  [
    ".phone-phase-navigation>button:first-child",
    "前のフェーズへ移動します。"
  ],
  [
    ".phone-phase-navigation>button:last-child",
    "次のフェーズへ移動します。"
  ],
  [
    "help-name-edit",
    "コンテンツ名・フェーズ名を変更します。"
  ],
  [
    "help-item-delete",
    "単体は削除、グループの×は解除です。"
  ],
  [
    "help-name-confirm",
    "入力した名前を確定します。"
  ],
  [
    "help-add-cancel",
    "追加を取り消し、追加前の状態に戻します。"
  ],
  [
    "help-object-selection",
    "チェックで複数選択、「…」のタップでメニュー。つかみマーク・番号、または「…」の長押しから並べ替えます。"
  ],
  [
    "help-object-visibility",
    "選択したオブジェクトの表示・非表示を切り替えます。"
  ],
  [
    "help-object-lock",
    "移動・変形・削除をロックします。"
  ],
  [
    "help-number-step",
    "−／＋で数値を調整します。"
  ],
  [
    "help-disclosure",
    "タイトル・余白・＋／−で欄を開閉します。⇄は表示内容の切り替えです。"
  ],
  [
    "#pngPreviewSave",
    "出力倍率1倍／2倍／3倍／4倍でPNGを保存します。"
  ],
  [
    "#outputPrintButton",
    "用紙プレビューの設定で印刷します。PDF保存は印刷画面で選びます。"
  ],
  [
    "#swapSelectedPositions",
    "選択した2個の位置を交換します。"
  ],
  [
    "#presetUndo",
    "プリセットの操作を元に戻します。"
  ],
  [
    "#presetRedo",
    "元に戻したプリセット操作をやり直します。"
  ],
  [
    "#registerUserPreset",
    "選択中の2個以上を登録します。Enter・✓で保存、Esc・↶で取消。"
  ],
  [
    "#contentListUndo",
    "コンテンツの追加・削除・読み込みなどを元に戻します。"
  ],
  [
    "#contentListRedo",
    "元に戻したコンテンツリストの操作をやり直します。"
  ],
  [
    "#undo",
    "このコンテンツの操作を元に戻します。"
  ],
  [
    "#redo",
    "元に戻した操作をやり直します。"
  ],
  [
    "#clearBtn",
    "確認後、現在のフェーズのオブジェクトをすべて削除します。"
  ],
  [
    ".phone-display-menu-toggle",
    "グリッド・フィールド・フィールド外の表示を切り替えます。"
  ],
  [
    "#fitBoardZoom",
    "全体が収まる倍率で表示します。出力サイズは変わりません。"
  ],
  [
    "#zoomOut",
    "表示倍率を5ポイント下げます。"
  ],
  [
    "#resetBoardZoom",
    "数字を押して表示倍率を選びます。"
  ],
  [
    "#zoomIn",
    "表示倍率を5ポイント上げます。"
  ],
  [
    "#bulkVisibleInput",
    "選択中の全体を表示・非表示にします。「−」は混在状態です。"
  ],
  [
    "#bulkEditableInput",
    "選択中の全体の編集可否を切り替えます。「−」は混在状態です。"
  ],
  [
    ".handle.move-handle",
    "十字矢印をつかんで移動します。"
  ],
  [
    ".handle.rotate",
    "矢印をつかんで回転します。"
  ],
  [
    ".list-drag-grip",
    "長押しして動かすと並べ替えます。すぐ縦に動かすとスクロールします。"
  ],
  [
    ".phase-group-toggle",
    "三角でグループを開閉します。"
  ],
  [
    ".object-group-disclosure",
    "三角でグループを開閉します。"
  ],
  [
    "#outputNoteRows",
    "「なし」はノートを出力しません。5〜10行を選ぶと各図の下にノートを付けます。折り返し込みで指定行数までです。"
  ],
  [
    "#outputShowBorder",
    "図とノートの外側に枠と余白を付けます。"
  ],
  [
    "#outputPhaseGapField",
    "複数フェーズの横・縦の間隔を調整します。"
  ],
  [
    "#pngPreviewScale",
    "PNGの出力サイズを1倍／2倍／3倍／4倍から選びます。"
  ],
  [
    ".preset-manage",
    "オブジェクト配置とプリセット管理を切り替えます。"
  ]
];
 const defaultSymbols={"#editModeToggle":{"svg":"<svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M12 20h9\"/><path d=\"M16.5 3.5a2.1 2.1 0 013 3L8 18l-4 1 1-4Z\"/></svg>","text":"編集","color":"#000","background":"#eaf3ff"},".phone-menu-toggle":{"svg":"<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"><path d=\"M4 6h16M4 12h16M4 18h16\"/></svg>","text":"","color":"#fff","background":"var(--accent)"},".phone-content-icon":{"svg":"<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M9 5l7 7-7 7\"/></svg>","text":"","color":"#fff","background":"var(--accent)"},".phone-material-pin":{"svg":"<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"6.5\" cy=\"6.5\" r=\"3.5\"/><rect x=\"14\" y=\"3\" width=\"7\" height=\"7\" rx=\"1\"/><path d=\"m6.5 13 4.5 8H2z\"/><path d=\"m17.5 13 4.5 4.5-4.5 4.5-4.5-4.5z\"/></svg>","text":"","color":"#fff","background":"var(--accent)"},"#addPage":{"svg":"","text":"＋","color":"#000","background":"#fff"},"#copyPage":{"svg":"","text":"⧉","color":"#000","background":"#fff"},".phone-phase-navigation>button:first-child":{"svg":"<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M15 5l-7 7 7 7\"/></svg>","text":"","color":"#fff","background":"var(--accent)"},".phone-phase-navigation>button:last-child":{"svg":"<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M9 5l7 7-7 7\"/></svg>","text":"","color":"#fff","background":"var(--accent)"},"#undo":{"svg":"<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M9 5L4 10l5 5M4 10h10a6 6 0 0 1 6 6v3\"/></svg>","text":"","color":"#000","background":"#fff"},"#redo":{"svg":"<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M15 5l5 5-5 5M20 10H10a6 6 0 0 0-6 6v3\"/></svg>","text":"","color":"#000","background":"#fff"},"#clearBtn":{"svg":"<svg class=\"clear-icon\" viewBox=\"0 0 24 24\" aria-hidden=\"true\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M4 6h16M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7M14 10v7\"/></svg>","text":"","color":"#000","background":"#fff"},"#gridToggle":{"svg":"<svg viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M3 3h14v14H3zM8 3v14M13 3v14M3 8h14M3 13h14\"/></svg>","text":"","color":"#fff","background":"var(--accent)"},"#fieldToggle":{"svg":"<svg viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M2 10s3-5 8-5 8 5 8 5-3 5-8 5-8-5-8-5Z\"/><circle cx=\"10\" cy=\"10\" r=\"2.2\"/></svg>","text":"","color":"#fff","background":"var(--accent)"},"#clipToggle":{"svg":"<svg viewBox=\"0 0 20 20\" aria-hidden=\"true\"><rect x=\"2\" y=\"2\" width=\"12\" height=\"12\" rx=\"1\"/><path d=\"M9 8h8v9H8v-3M8 8v6M8 8h6\"/><path d=\"M14 8h3v9H8v-3\" stroke-dasharray=\"2 2\"/></svg>","text":"","color":"#fff","background":"var(--accent)"},"#fitBoardZoom":{"svg":"<svg viewBox=\"0 0 20 20\" aria-hidden=\"true\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M7 3H3v4M13 3h4v4M17 13v4h-4M7 17H3v-4\"/></svg>","text":"","color":"#fff","background":"var(--accent)"},"#zoomOut":{"svg":"","text":"−","color":"#fff","background":"var(--accent)"},"#resetBoardZoom":{"svg":"","text":"100%","color":"#fff","background":"var(--accent)"},"#zoomIn":{"svg":"","text":"＋","color":"#fff","background":"var(--accent)"}};

 entries.push(
  ["#phaseMemo textarea","フェーズごとのノートを編集します。変更は元のノートに保存されます。"],
  ["#outputNotePhase","選択中のフェーズから、ノートの編集対象だけを切り替えます。出力対象は変わりません。"],
  ["#editFieldGuides","コンテンツとフィールドの編集を切り替えます。"],
  ["[data-guide-tool=\"line\"]","直線を選び、キャンバスを押して配置します。"],
  ["[data-guide-tool=\"circle\"]","円を選び、キャンバスを押して配置します。"],
  ["[data-guide-tool=\"rect\"]","四角形を選び、キャンバスを押して配置します。"],
  ["[data-guide-tool=\"triangle\"]","三角形を選び、キャンバスを押して配置します。"],
  ["[data-guide-tool=\"diamond\"]","ひし形を選び、キャンバスを押して配置します。"],
  ["#guideHideObjects","オブジェクトを一時的に隠します。"],
  ["#fieldGuideCircles","フィールドの中心に同心円を表示します。"],
  ["#fieldGuide-ringScale","同心円の大きさを調整します。"],
  ["#fieldGuideOuterRing","一番外側の円を表示・非表示にします。"],
  ["#fieldGuideRays","フィールドの中心から放射線を表示します。"],
  ["#guideShapeFill","塗りを「なし」「薄く」「線と同じ濃さ」から選びます。"],
  [".guide-property-group[aria-label=\"線の見た目\"]","共通設定を使う固定ガイドと、同心円・放射線の色・濃さを設定します。"],
  ["#duplicateGuideShape","選択したガイドを複製します。"],
  ["#deleteGuideShape","選択したガイドを削除します。"],
  ["#groupGuideShapes","複数選択したガイドをグループ化します。"],
  ["#ungroupGuideShapes","図形を残してグループを解除します。"],
  ["#editGuideMember","グループ内の図形を個別に編集します。"],
  ["#finishGuideMemberEdit","所属するグループ全体の選択へ戻ります。"],
  [".guide-selection-controls .aoe-box-handle","白い丸でサイズを変更します。角は縦横比を保ちます。"],
  [".print-page-fields","用紙・向き・余白・図の幅・配置を調整します。"],
  ["#printSettingsReset","印刷設定を初期値に戻します。ノート・外枠の選択は保持します。"],
  ["#outputPrintReadability","文字と図形の線を少し太く印刷します。"],
  ["#outputPlainPaper","鮮やかさを少し抑えて印刷します。"],
  ["#outputPrintCutGuide","切り取り位置の点線を印刷します。PNGには含めません。"]
 );
 for(const selector of ['#guideHideObjects','#fieldGuideCircles','#fieldGuideRays','#outputPrintReadability','#outputPlainPaper','#outputPrintCutGuide'])defaultSymbols[selector]={text:'☑',color:'#33445f',background:'#fff'};
 Object.assign(defaultSymbols,{
  'help-png-mode':{svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 5-5 4 4 3-3 6 6"/></svg>',color:'#000',background:'#fff'},
  '#pngPropertiesToggle':{text:'＋ / −',color:'#33445f',background:'#eef2f7'},
  '.phone-display-menu-toggle':{svg:toolbar.querySelector('.phone-display-menu-toggle svg').outerHTML,color:'#000',background:'#fff'},
  '#addPhaseGroup':{svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7V4h7l2 3h9v13H3V7Z M9 13h6M12 10v6"/></svg>',color:'#000',background:'#fff'},
  '#copyPageToContent':{svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4H4v16h13v-6M8 8v8h5M12 3h9v9M21 3l-9 9"/></svg>',color:'#000',background:'#fff'},
  '.phone-content-close':{svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',color:'#33445f',background:'#eef2f7'},
  'help-name-edit':{svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L8 18l-4 1 1-4Z"/></svg>',color:'#000',background:'#fff'},
  'help-item-delete':{text:'×',color:'#000',background:'#fff'},
  'help-name-confirm':{text:'✓',color:'#000',background:'#fff'},
  'help-add-cancel':{text:'↶',color:'#000',background:'#fff'},
  'help-object-selection':{text:'☑',color:'#33445f',background:'#fff'},
  'help-object-visibility':{svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',color:'#33445f',background:'#fff'},
  'help-object-lock':{svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/></svg>',color:'#33445f',background:'#fff'},
  'help-number-step':{text:'− / ＋',color:'#33445f',background:'#fff'},
  'help-disclosure':{text:'＋ / −',color:'#33445f',background:'#eef2f7'},
  '#phonePhaseSwitch-toggle':{svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h16l-4-4M20 16H4l4 4"/></svg>',color:'#33445f',background:'#eef2f7'},
  '#phonePhaseSectionToggle':{text:'＋ / −',color:'#33445f',background:'#eef2f7'},
  '#phasePropertyResize':{text:'━',color:'#999',background:'#fff'},
  '#toggleBattlePages':{text:'＋ / −',color:'#33445f',background:'#eef2f7'},
  '.phase-select-check':{text:'☑',color:'#33445f',background:'#fff'}
 });
 Object.assign(defaultSymbols,{"#fieldGuide-ringScale":{"text":"％","color":"#33445f","background":"#fff"},"#fieldGuideOuterRing":{"text":"☑","color":"#33445f","background":"#fff"},"#guideShapeFill":{"text":"塗","color":"#33445f","background":"#fff"},".guide-property-group[aria-label=\"線の見た目\"]":{"text":"線","color":"#33445f","background":"#fff"},".print-page-fields":{"text":"紙","color":"#33445f","background":"#fff"},"#printSettingsReset":{"text":"↶","color":"#33445f","background":"#fff"}});
 for(const key of ['.phone-phase-navigation>button:first-child','.phone-phase-navigation>button:last-child'])Object.assign(defaultSymbols[key],{color:'#000',background:'#fff'});
 for(const key of ['#phonePhaseSectionToggle','#toggleBattlePages','help-disclosure'])defaultSymbols[key].svg='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 7h6M5 4v6M14 3l-4 18M16 17h6"/></svg>';
 defaultSymbols['help-number-step'].svg='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 7h6M14 3l-4 18M16 17h6M19 14v6"/></svg>';
 Object.assign(defaultSymbols,{'#outputNotePhase':{text:'フェーズ',color:'#33445f',background:'#f8fafc'},'#phaseMemo textarea':{text:'ノート',color:'#33445f',background:'#f8fafc'},'#outputNoteRows':{text:'5行',color:'#33445f',background:'#fff'},'#outputShowBorder':{text:'□',color:'#33445f',background:'#fff'},'#outputPhaseGapField':{text:'横／縦',color:'#33445f',background:'#fff'},'#pngPreviewScale':{text:'1倍',color:'#33445f',background:'#fff'},'#pngPreviewSave':{text:'保存',color:'#fff',background:'#293c66'},'#outputPrintButton':{text:'印刷',color:'#fff',background:'#293c66'}});
 defaultSymbols['#editModeToggle'].background='#fff';defaultSymbols['#bulkVisibleInput']=defaultSymbols['help-object-visibility'];defaultSymbols['#bulkEditableInput']=defaultSymbols['help-object-lock'];
 const contentButton=button.cloneNode(true);contentButton.classList.add('phone-content-help');contentButton.setAttribute('aria-label','コンテンツのアイコン説明');document.querySelector('.content-heading-row').append(contentButton);
 let opener=button;
 const visible=node=>!!node&&!node.closest('[inert]')&&node.getClientRects().length>0&&getComputedStyle(node).visibility!=='hidden';
 function close(){if(panel.open)panel.close();for(const node of document.querySelectorAll('.phone-icon-help-toggle'))if(node.getAttribute('aria-expanded')!=='false')node.setAttribute('aria-expanded','false')}
 function openHelp(source=button){
  if(panel.open){close();return}opener=source;
  const fieldMode=!!window.Bolxiv?.phaseMasters?.active,png=!!window.Bolxiv?.pngPreview?.active,guides=!!window.Bolxiv?.fieldGuideEditor?.active,content=source===contentButton,mode=fieldMode?'フィールド編集':guides?'ガイド編集':png?(window.Bolxiv.pngPreview.kind==='print'?'印刷':'画像生成'):boardReadOnly?'閲覧':'編集';
  panel.querySelector('h2').textContent='アイコン説明 · '+mode+' · '+(content?(fieldMode?'フィールド':'コンテンツ'):'キャンバス');
  const list=panel.querySelector('.phone-icon-help-list');list.replaceChildren();
  const intro=document.createElement('p');intro.className='phone-icon-help-intro';intro.textContent=fieldMode?'フィールドとガイドは全コンテンツ共通です。変更は使用中のすべてのフェーズへ反映されます。見出し横の切替からコンテンツへ戻ります。':png&&content?'出力画面で選択とノート編集を行います。⇄でフェーズリストと出力設定を切り替えます。':png&&matchMedia('(min-width:851px)').matches?'拡大したプレビューは左ドラッグで移動できます。':'現在の画面で使える操作です。';list.append(intro);
  const scope=content?document.querySelector('.battle'):png?document.getElementById('pngPreview'):document.querySelector('.right');
  const find=selector=>{try{return [...scope.querySelectorAll(selector),...document.querySelectorAll(selector)].find(node=>visible(node)&&!node.disabled&&(content?node.closest('.battle,.phone-content-close,.phone-phase-navigation,.header-mode-status'):!node.closest('.battle')))}catch{return null}};
  const outputProperties=mode+'プロパティ';
  const contextual=[];
  for(const [selector,original] of entries){
   if(['.phase-select-check','help-object-selection'].includes(selector))continue;if((boardReadOnly||png)&&selector==='.list-drag-grip')continue;if(guides&&['.phone-material-pin','.preset-manage','#clearBtn'].includes(selector))continue;
   let description=original,node=null;
   if(selector.startsWith('help-')){
    if(selector==='help-png-mode'){if(!png||content)continue;node=document.getElementById('editModeToggle');description='編集・閲覧・画像生成・印刷を切り替えます。'}
    else if(selector==='help-disclosure'){continue}
    else if(selector==='help-number-step'){if(!(content||guides||png)||!visible(document.querySelector(content?'.battle .phone-number-step-buttons':guides?'.guide-editor-properties .phone-number-step-buttons':'#pngPreview .phone-number-step-buttons')))continue}
    else if(selector.startsWith('help-object-')){if(content||png||guides||boardReadOnly||!visible(document.getElementById('objectList')))continue}
    else{if(!content||png||boardReadOnly||!visible(document.querySelector('.battle .page-tab-input,.battle .content-option-input')))continue}
   }else{
    if(selector==='#editModeToggle'){if(content||png)continue;description='編集・閲覧・画像生成・印刷を切り替えます。'}
    if(selector==='#pngPropertiesToggle')continue;
    if(selector==='.phone-content-icon'&&content)continue;
    if(selector==='.phone-content-close'&&!content)continue;
    if(selector==='.phone-menu-toggle'&&content)continue;
    if(selector==='#toggleBattlePages'&&!content)continue;
    const mapped=['#fitBoardZoom','#zoomOut','#resetBoardZoom','#zoomIn','#gridToggle','#fieldToggle','#clipToggle'].includes(selector)?png?'#png-'+selector.slice(1):guides&&matchMedia('(min-width:851px)').matches?'#guide-'+selector.slice(1):selector:selector;
    node=find(mapped);if(!node)continue;
    if(content&&!node.closest('.battle,.phone-content-close,.phone-phase-navigation,.header-mode-status'))continue;
    if(selector==='.phone-content-icon')description=png?'出力画面の設定欄でノートを編集します。':'コンテンツ・フェーズ・設定・ノートを開きます。';
    if(selector==='#editFieldGuides')description=guides?'見出し横の切替ボタンでコンテンツへ戻ります。':'見出し横の切替ボタンでフィールドへ移ります。';
    if(fieldMode&&selector==='.phone-content-icon')description='フィールド管理ペインを開きます。＋メニューから追加・統合・未使用フィールドの一括削除ができます。';if(fieldMode&&selector==='.phone-content-close')description='フィールド管理ペインを閉じ、選択中のフィールドの編集画面へ戻ります。';
    if(fieldMode&&selector==='#undo')description='フィールド・ガイドの編集や、フィールドの追加・整理を元に戻します。';
    if(guides&&selector==='#redo')description='元に戻した操作をやり直します。';
    if(selector==='#outputPrintButton')description='用紙プレビューの設定で印刷します。PDF保存は印刷画面で選びます。';
    if(selector==='#toggleBattlePages')description='フェーズリストを開閉します。';
    if(selector==='.list-drag-grip'&&matchMedia('(min-width:851px)').matches)description='つかんで上下に動かすと、リストを並べ替えます。';
    if(selector==='.phase-select-check'&&(png||boardReadOnly))description='フェーズをチェックして並べて表示します。';
    if(selector==='#fitBoardZoom')description='全体が収まる倍率で表示します。出力サイズは変わりません。';
    if(selector.startsWith('.phone-phase-navigation'))description=(selector.includes('first-child')?'前':'次')+'の'+(fieldMode?'フィールド':'フェーズ')+'へ移動します。';
   }
   contextual.push({selector,description,node});
  }
  for(const [selector,description] of [
   ['.output-selection-tabbed .phone-list-property-change','フェーズリストと'+outputProperties+'を切り替えます。ノートは出力設定内です。'],
   ['.output-selection-tabbed .phone-object-collapse','表示中のフェーズリスト／出力設定欄を開閉します。'],
   ['#contentPanel.phone-phase-list-tabbed .phone-list-property-change','フェーズリストとフェーズプロパティを切り替えます。ノートはプロパティ内で編集できます。'],
   ['#contentPanel.phone-phase-list-tabbed .phone-object-collapse','表示中のフェーズリスト／プロパティ欄を開閉します。'],
   ['.phone-reader-switch',png?'⇄で、フェーズリストと'+outputProperties+'を切り替えます。':'⇄で、フェーズリストとノートを切り替えます。'],
   ['.phone-reader-collapse',png?outputProperties+'欄を開閉します。':'フェーズリスト／ノートの共通枠を開閉します。'],
   ['#objectLayerPanel .phone-list-property-change','オブジェクトリストとオブジェクトプロパティを切り替えます。'],
   ['#objectLayerPanel .phone-object-collapse',fieldMode?'フィールドプロパティを開閉します。閉じると編集用の盤面が広がります。':'オブジェクト欄を開閉します。'],
   ['#inspector .property-value-mixed','オレンジは設定値が混在する項目です。最初の選択値を表示し、操作すると編集可能な対象をそろえます。'],
  ]){const node=find(selector);if(node)contextual.push({selector,description,node})}
  const helpTitles={
   '.output-selection-tabbed .phone-list-property-change':'フェーズリスト・出力設定の切り替え','.output-selection-tabbed .phone-object-collapse':'出力の欄を開閉',
   '#contentPanel.phone-phase-list-tabbed .phone-list-property-change':'フェーズリスト・プロパティの切り替え','#contentPanel.phone-phase-list-tabbed .phone-object-collapse':'フェーズ欄を開閉',
   '#phaseMasterModeToggle':'コンテンツ／フィールドの切り替え','#editUsedField':'使用フィールドを編集','#addPhaseMaster':'フィールドの追加・整理','#duplicatePhaseMaster':'フィールドを複製','#phaseMasterSelect':'使用フィールドの選択','#editModeToggle':'モード切替','help-png-mode':'モード切替',
   '.phone-menu-toggle':'操作メニュー','.phone-content-icon':fieldMode?'フィールド管理ペインを開く':'コンテンツ管理ペインを開く','.phone-content-close':fieldMode?'フィールド管理ペインを閉じる':'コンテンツ管理ペインを閉じる','.phone-material-pin':'マテリアルを開閉',
   '.preset-manage':'配置・プリセット管理の切り替え','#addPage':'フェーズを追加','#addPhaseGroup':'フェーズグループを追加','#copyPage':'フェーズを複製','#copyPageToContent':'別コンテンツへ複製',
   '#editFieldGuides':'コンテンツ／フィールドの切り替え','#phasePropertyResize':'ペインの高さ調整','#resetBoardZoom':'表示倍率を選ぶ','#guideHideObjects':'オブジェクトを一時的に隠す','#fieldGuide-ringScale':'同心円の大きさ','#fieldGuideOuterRing':'最外周を表示','#guideShapeFill':'ガイドの塗り','.guide-property-group[aria-label="線の見た目"]':'ガイド（共通）','.print-page-fields':'印刷の配置設定','#printSettingsReset':'印刷設定をリセット','#fieldGuideCircles':'同心円','#fieldGuideRays':'放射線','#duplicateGuideShape':'ガイドを複製','#deleteGuideShape':'ガイドを削除','.guide-selection-controls .aoe-box-handle':'サイズ変更ハンドル','#outputPrintReadability':'文字・線を強調','#outputPlainPaper':'普通紙向けの色調整','#outputPrintCutGuide':'切り取りガイド','#phonePhaseSwitch-toggle':'フェーズリスト・プロパティの切り替え','#phonePhaseSectionToggle':'フェーズ設定・ノート欄を開閉','#toggleBattlePages':'フェーズリストを開閉',
   '.phone-phase-navigation>button:first-child':fieldMode?'前のフィールドへ':'前のフェーズへ','.phone-phase-navigation>button:last-child':fieldMode?'次のフィールドへ':'次のフェーズへ',
   'help-name-edit':'名前を変更','help-item-delete':'項目を削除','help-name-confirm':'名前を確定','help-add-cancel':'追加を取り消す',
   '#bulkVisibleInput':'全体の表示・非表示','#bulkEditableInput':'全体の編集可否','.handle.move-handle':'移動ハンドル','.handle.rotate':'回転ハンドル','.list-drag-grip':'並べ替え','.phase-group-toggle':'フェーズグループを開閉','.object-group-disclosure':'オブジェクトグループを開閉','help-object-visibility':'オブジェクトの表示・非表示','help-object-lock':'オブジェクトをロック','help-number-step':'プロパティの数値を調整',
   '#phaseMemo textarea':'フェーズノート','#outputNotePhase':'ノートの編集対象','#outputNoteRows':'ノート','#outputShowBorder':'外枠を表示','#outputPhaseGapField':'フェーズ間隔','#pngPreviewScale':'出力倍率','#pngPreviewSave':'PNGを保存','#outputPrintButton':'印刷',
   '#presetUndo':'プリセット操作を元に戻す','#presetRedo':'プリセット操作をやり直す','#registerUserPreset':'プリセットを登録','#contentListUndo':'コンテンツリストの操作を元に戻す','#contentListRedo':'コンテンツリストの操作をやり直す','#undo':'元に戻す','#redo':'やり直す','#clearBtn':'フェーズ内のオブジェクトを全削除',
   '.phone-display-menu-toggle':'キャンバスの表示設定','#fitBoardZoom':'キャンバス全体を表示','#zoomOut':'キャンバスを縮小','#zoomIn':'キャンバスを拡大',
   '.phone-reader-switch':png?'フェーズリスト・'+outputProperties+'の切り替え':'フェーズリスト・ノートの切り替え',
   '.phone-reader-collapse':png?outputProperties+'欄を開閉':'フェーズリスト・ノート欄を開閉',
   '#objectLayerPanel .phone-list-property-change':'オブジェクトリスト・プロパティの切り替え','#objectLayerPanel .phone-object-collapse':fieldMode?'フィールドプロパティを開閉':'オブジェクト欄を開閉','#inspector .property-value-mixed':'設定値の混在'
  };
  // Follow the same top-to-bottom, left-to-right order as the current screen.
  const anchorFor=entry=>entry.node||find(entry.selector==='help-object-visibility'?'#visibleInput':entry.selector==='help-object-lock'?'#editableInput':entry.selector==='help-number-step'?'.phone-number-step-buttons':'.page-tab-input,.content-option-input');
  const ordered=contextual.map((entry,index)=>{
   const anchor=anchorFor(entry),rect=anchor?.getBoundingClientRect();
   const group=anchor?.closest('.top')?0:anchor?.closest('.board-title-row,.png-preview-heading,.phone-phase-navigation,.phone-content-preview,.phone-material-pin')?1:2;
   return {...entry,group,top:rect?.top??Infinity,left:rect?.left??Infinity,index};
  }).sort((a,b)=>a.group-b.group||a.top-b.top||a.left-b.left||a.index-b.index);
  let previousGroup=-1;
  for(const {selector,description,node,group} of ordered){
   if(group!==previousGroup){const section=document.createElement('h3');section.className='phone-icon-help-section';section.textContent=['上部の操作',content?'プレビューの操作':'キャンバスの操作',content?'コンテンツの操作':guides?'ガイドの操作':png?'フェーズリスト・出力の操作':'リスト・マテリアルの操作'][group];list.append(section);previousGroup=group}
   const row=document.createElement('div');row.className='phone-icon-help-row';row.dataset.helpFor=selector;
   const symbol=document.createElement('span');symbol.className='phone-icon-help-symbol';symbol.setAttribute('aria-hidden','true');
   const fallback=defaultSymbols[selector],svg=node?.querySelector('svg');
   if(svg){const copy=svg.cloneNode(true),sources=[svg,...svg.querySelectorAll('*')],copies=[copy,...copy.querySelectorAll('*')];sources.forEach((source,index)=>{const style=getComputedStyle(source),target=copies[index];for(const key of ['fill','stroke'])target.style.setProperty(key,style.getPropertyValue(key)==='none'?'none':'currentColor','important');target.style.setProperty('color','inherit','important');target.style.setProperty('stroke-width',style.strokeWidth,'important')});symbol.append(copy);symbol.style.color=fallback?.color||'#33445f';symbol.style.backgroundColor=fallback?.background||'#fff'}
   else if(fallback){symbol.style.color=fallback.color;symbol.style.backgroundColor=fallback.background;if(fallback.svg)symbol.innerHTML=fallback.svg;else symbol.textContent=fallback.text||'＋ / −'}
   else{symbol.textContent=selector==='#pngPreviewScale'?'1倍':selector==='#pngPreviewSave'?'保存':node?.textContent.trim().slice(0,5)||'＋ / −'}
   const text=document.createElement('div');text.className='phone-icon-help-text';
   const heading=document.createElement('h3');heading.className='phone-icon-help-item-title';heading.textContent=helpTitles[selector]||node?.getAttribute('aria-label')||'アイコンの操作';
   const detail=document.createElement('p');detail.textContent=description;text.append(heading,detail);row.append(symbol,text);list.append(row);
  }
  const guide=document.createElement('button');guide.type='button';guide.className='btn phone-icon-help-guide';guide.textContent='詳しい操作ガイドを開く';guide.onclick=()=>{close();operationGuide.querySelector('.operation-guide-body').scrollTop=0;operationGuide.showModal()};list.append(guide);
  panel.style.top='max(12px, 8dvh)';panel.style.maxHeight='calc(84dvh - 12px)';panel.showModal();list.scrollTop=0;source.setAttribute('aria-expanded','true');
 }
 const helpSeparator=document.createElement('span');helpSeparator.className='phone-help-separator';helpSeparator.setAttribute('aria-hidden','true');
 function placeCanvasHelp(){if(mobile.matches)toolbar.append(helpSeparator,button);else{helpSeparator.remove();toolbar.parentElement.append(button)}}
 mobile.addEventListener('change',placeCanvasHelp);placeCanvasHelp();
 button.onclick=()=>openHelp(button);contentButton.onclick=()=>openHelp(contentButton);
 window.Bolxiv.iconHelp={open:openHelp,close};
 panel.querySelector('button').onclick=()=>{close();opener?.focus({preventScroll:true})};panel.addEventListener('cancel',close);panel.addEventListener('close',close);
 panel.addEventListener('pointerdown',event=>{if(event.target!==panel)return;const rect=panel.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom){event.preventDefault();close()}});
 mobile.addEventListener('change',close);})();

;
// ===== js/mobile/mobile-menu.js =====
(function setupPhoneMenu(){
 const mobile=matchMedia('(max-width:850px)'),header=document.querySelector('.top'),actions=header.querySelector('.actions');
 actions.id='headerActions';actions.setAttribute('role','menu');actions.setAttribute('aria-label','操作メニュー');actions.hidden=true;
 for(const id of ['importBtn','clearUserDataBtn','operationGuideBtn']){const separator=document.createElement('div');separator.className='context-separator';separator.setAttribute('role','separator');actions.insertBefore(separator,document.getElementById(id))}
 for(const item of actions.querySelectorAll(':scope>button'))item.setAttribute('role','menuitem');
 const button=document.createElement('button');button.type='button';button.className='phone-menu-toggle';button.title='操作メニューを開閉';button.setAttribute('aria-label','操作メニュー');button.setAttribute('aria-controls',actions.id);button.setAttribute('aria-haspopup','menu');button.setAttribute('aria-expanded','false');
 button.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg><span class="header-menu-label">メニュー</span>';header.insertBefore(button,actions);
 function close(focus=false){actions._headerSession=(actions._headerSession||0)+1;actions._cancelSubmenuHover?.();closeJsonImportMenu();closeJsonExportMenu();closeHelpMenu();header.classList.remove('phone-menu-open');actions.hidden=true;button.setAttribute('aria-expanded','false');if(focus)button.focus({preventScroll:true})}
 function open(focus=false){closeObjectContextMenu();addPhoneMenuClose(actions,()=>close(true));actions.hidden=false;header.classList.add('phone-menu-open');button.setAttribute('aria-expanded','true');if(focus)actions.querySelector('button:not(:disabled)')?.focus({preventScroll:true})}
 button.onclick=()=>header.classList.contains('phone-menu-open')?close():open();
 button.onkeydown=event=>{if(['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();open(true);if(event.key==='ArrowUp')[...actions.querySelectorAll(':scope>button:not(:disabled)')].filter(n=>n.getClientRects().length).at(-1)?.focus()}};
 for(const [id,childId,closeChild] of [['importBtn','jsonImportMenu',closeJsonImportMenu],['exportBtn','jsonExportMenu',closeJsonExportMenu],['operationGuideBtn','helpMenu',closeHelpMenu]]){
  const trigger=document.getElementById(id),child=document.getElementById(childId),original=trigger.onclick;
  trigger.textContent=trigger.textContent.replace(/\s*▾$/,'');const arrow=document.createElement('span');arrow.className='header-submenu-arrow';arrow.setAttribute('aria-hidden','true');trigger.append(arrow);
  trigger.onclick=event=>{
   const fromHeader=!actions.hidden,session=actions._headerSession||0,origin=event?.submenuHover?document.activeElement:null;
   const finish=()=>{
    if(fromHeader&&(actions.hidden||session!==(actions._headerSession||0)||origin&&actions._submenuHover?.activeToggle!==trigger)){closeChild();if(origin)origin.focus({preventScroll:true});return}
    child._keyboardParent=fromHeader?actions:null;
    if(!mobile.matches&&!child.hidden&&fromHeader){
     const r=trigger.getBoundingClientRect(),parent=actions.getBoundingClientRect(),w=child.offsetWidth,h=child.offsetHeight,gap=-3,first=[...child.querySelectorAll('button')].find(node=>node.getClientRects().length),inset=first?first.getBoundingClientRect().top-child.getBoundingClientRect().top:0;
     child.style.left=Math.max(4,Math.min(parent.right+w+gap>innerWidth-4?parent.left-w-gap:parent.right+gap,innerWidth-w-4))+'px';
     child.style.top=Math.max(4,Math.min(r.top-inset,innerHeight-h-4))+'px';
    }
    if(origin&&!child.hidden){child._openedByHover=true;origin.focus({preventScroll:true})}
   };
   const result=original.call(trigger,event);if(result?.then)return result.then(finish);finish();
  };
  bindSubmenuHover(trigger,child,()=>{if(child.hidden)trigger.onclick({submenuHover:true})},closeChild);
  child.addEventListener('click',event=>{if(event.target.closest('button')&&!event.target.closest('[data-phone-menu-close]'))close()});
 }
 actions.addEventListener('click',event=>{const action=event.target.closest('button');if(action&&!['exportBtn','importBtn','operationGuideBtn'].includes(action.id)&&!action.hasAttribute('data-phone-menu-close'))close()});
 document.addEventListener('pointerdown',event=>{if(document.querySelector('dialog:modal'))return;if(!header.contains(event.target)&&!event.target.closest('#jsonExportMenu,#jsonImportMenu,#helpMenu'))close()},true);
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!document.querySelector('dialog:modal')&&header.classList.contains('phone-menu-open')){event.preventDefault();close(true)}});
 new MutationObserver(()=>{if(!header.classList.contains('phone-menu-open')){actions.hidden=true;actions._cancelSubmenuHover?.();button.setAttribute('aria-expanded','false')}}).observe(header,{attributes:true,attributeFilter:['class']});
 mobile.addEventListener('change',()=>close());
})();

(function setupPhoneSaveSubtitle(){
 const mobile=matchMedia('(max-width:850px)'),status=document.getElementById('saved'),home=status.parentElement,brand=document.querySelector('.top>.brand');
 const subtitle=brand.querySelector('small'),version=brand.querySelector('.brand-version'),caption=document.createElement('span');caption.className='phone-brand-caption';
 let timer,lastText=status.textContent.trim(),savedUntil=0;
 function update(){
  clearTimeout(timer);
  const text=status.textContent.trim();
  if(text!==lastText){savedUntil=text==='保存済み'?Date.now()+3000:0;lastText=text}
  if(!mobile.matches){if(caption.isConnected){brand.querySelector('div:not(.logo)').append(subtitle);brand.append(version);caption.remove()}home.append(status);brand.classList.remove('phone-save-status-visible');return}
  if(!caption.isConnected){caption.append(subtitle,version);brand.append(caption)}brand.append(status);
  const remaining=savedUntil-Date.now();
  brand.classList.toggle('phone-save-status-visible',text!=='保存済み'||remaining>0);
  if(text==='保存済み'&&remaining>0)timer=setTimeout(update,remaining);
 }
 new MutationObserver(update).observe(status,{childList:true,characterData:true,subtree:true});
 document.addEventListener('bolxiv-save-status',event=>{if(event.detail.text==='保存済み')savedUntil=Date.now()+3000;update()});mobile.addEventListener('change',update);update();
})();

;
// ===== js/mobile/mobile-hover.js =====
(function clearPhoneButtonHover(){
 const mobile=matchMedia('(max-width:850px)');
 function update(){document.documentElement.classList.toggle('phone-touch-mode',mobile.matches)}
 mobile.addEventListener('change',update);update();
 document.addEventListener('click',event=>{
  if(!mobile.matches)return;const button=event.target.closest('button');
  if(button)requestAnimationFrame(()=>{if(document.activeElement===button)button.blur()});
 });
})();

;
// ===== js/mobile/mobile-pinch-guard.js =====
(function disablePhonePinchZoom(){
 const mobile=matchMedia('(max-width:850px)');
 function preventPinch(event){if(mobile.matches&&event.touches.length>1&&event.cancelable)event.preventDefault()}
 document.addEventListener('touchstart',preventPinch,{passive:false,capture:true});
 document.addEventListener('touchmove',preventPinch,{passive:false,capture:true});
 for(const type of ['gesturestart','gesturechange'])document.addEventListener(type,event=>{if(mobile.matches&&event.cancelable)event.preventDefault()},{passive:false,capture:true});
})();

;
// ===== js/mobile/phone-phase-navigation.js =====
(function setupPhonePhaseNavigation(){
 const mobile=matchMedia('(max-width:850px)'),layout=document.querySelector('.layout'),viewport=document.getElementById('boardZoomSpace').parentElement;
 const nav=document.createElement('div');nav.className='phone-phase-navigation';nav.setAttribute('role','group');nav.setAttribute('aria-label','フェーズ切り替え');nav.hidden=true;
 function fieldNavigation(){const pm=window.Bolxiv?.phaseMasters;if(!pm?.active)return null;const items=pm.all();let index=items.findIndex(item=>item.id===pm.selectedId),groupAnchor=null;if(pm.selectedGroupId){groupAnchor=1;for(const unit of pm.units()){if(unit.group?.id===pm.selectedGroupId)break;groupAnchor+=unit.group?unit.items.length:1}}return {pm,items,index,groupAnchor}}
 function navigationIndex(step){const field=fieldNavigation();if(field)return field.groupAnchor!==null?field.groupAnchor+(step<0?-1:0):field.index+step;if(data.activePhaseGroup){const group=data.phaseGroups?.find(item=>item.id===data.activePhaseGroup),first=data.pageGroupIds?.indexOf(data.activePhaseGroup),anchor=first>=0?first:(group?.position??data.page);return step<0?anchor-1:anchor}return data.page+step}
 function button(label,path,step){const node=document.createElement('button');node.type='button';node.title=label;node.setAttribute('aria-label',label);node.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="'+path+'"/></svg>';node.addEventListener('pointerdown',event=>event.stopPropagation());node.onclick=()=>{const index=navigationIndex(step),field=fieldNavigation(),count=field?field.items.length:data.pages.length;if(index>=0&&index<count&&!phaseComparisonActive()){const zoom=boardDisplayZoom;if(field)field.pm.select(field.items[index].id);else selectPhase(index,false);setBoardDisplayZoom(zoom,false,false)}};nav.appendChild(node);return node}
 const previous=button('前のフェーズ','M15 5l-7 7 7 7',-1),next=button('次のフェーズ','M9 5l7 7-7 7',1);const materialButton=document.querySelector('.phone-material-pin');document.body.append(nav);
 function update(){const field=fieldNavigation(),count=field?field.items.length:data.pages.length;nav.setAttribute('aria-label',field?'フィールド切り替え':'フェーズ切り替え');for(const [button,direction] of [[previous,'前'],[next,'次']]){const label=direction+'の'+(field?'フィールド':'フェーズ');button.title=label;button.setAttribute('aria-label',label)}materialButton.hidden=!mobile.matches||boardReadOnly||!!data.activePhaseGroup||phaseComparisonActive()||!!window.Bolxiv?.fieldGuideEditor?.active||!!window.Bolxiv?.pngPreview?.active||layout.matches('.phone-content-open,.phone-materials-open')||layout.dataset.phonePane!=='canvas';if(mobile.matches){const heading=[...document.querySelectorAll('#objectLayerPanel>.property-group>.phone-object-tabs')].find(node=>node.checkVisibility());if(heading&&materialButton.parentElement!==heading)heading.prepend(materialButton)}const previewOpen=mobile.matches&&layout.classList.contains('phone-content-open'),previewHost=previewOpen?document.querySelector('.phone-content-preview'):null;if(previewHost&&nav.parentElement!==previewHost){nav.removeAttribute('style');previewHost.append(nav)}else if(!previewOpen&&nav.parentElement!==document.body){nav.removeAttribute('style');document.body.append(nav)}const waitingForPreview=mobile.matches&&layout.classList.contains('phone-content-open')&&document.querySelector('.phone-content-preview')?.getAttribute('aria-busy')==='true';nav.hidden=!!window.Bolxiv?.fieldGuideEditor?.active&&!field||waitingForPreview||(count<2&&!data.activePhaseGroup&&!field?.pm.selectedGroupId)||phaseComparisonActive()||(mobile.matches?(layout.dataset.phonePane!=='canvas'&&!layout.classList.contains('phone-content-open')):false);previous.hidden=mobile.matches&&(layout.classList.contains('phone-materials-open')||navigationIndex(-1)<0);next.hidden=mobile.matches&&(layout.classList.contains('phone-materials-open')||navigationIndex(1)>=count);previous.disabled=!mobile.matches&&navigationIndex(-1)<0;next.disabled=!mobile.matches&&navigationIndex(1)>=count;if(nav.hidden)return;const previewSurface=window.Bolxiv?.pngPreview?.active?document.querySelector('.png-preview-surface'):null;if(previewOpen)return;const fieldViewport=field&&!mobile.matches?document.querySelector('#fieldGuideEditor .guide-editor-viewport'):null;const rect=(fieldViewport||previewSurface||viewport).getBoundingClientRect();if(!mobile.matches){const left=Math.max(0,rect.left)+12,right=Math.min(innerWidth,rect.right)-12;nav.style.left=left+'px';nav.style.top=(Math.min(innerHeight,rect.bottom)-40)+'px';nav.style.width=Math.max(0,right-left)+'px';return}const layoutRect=layout.getBoundingClientRect();const left=layoutRect.left+8;const reader=document.querySelector('.phone-view-content'),readerClosed=boardReadOnly&&reader&&document.getElementById('toggleBattlePages').getAttribute('aria-expanded')==='false';const position={left,top:readerClosed?reader.getBoundingClientRect().top-36:rect.bottom-30,width:Math.max(0,layoutRect.width-(left-layoutRect.left)*2)};nav.style.left=position.left+'px';nav.style.top=position.top+'px';nav.style.width=position.width+'px'}
 let navigationFrame=0;function scheduleNavigation(){if(navigationFrame)return;navigationFrame=requestAnimationFrame(()=>{navigationFrame=0;update()})}const renderBeforeNavigation=render;render=function(){renderBeforeNavigation();update();scheduleNavigation()};new ResizeObserver(scheduleNavigation).observe(viewport);new MutationObserver(records=>{if(records.some(record=>!nav.contains(record.target)))scheduleNavigation()}).observe(layout,{subtree:true,attributes:true,attributeFilter:['class','data-phone-pane','style','aria-expanded','aria-busy']});new MutationObserver(scheduleNavigation).observe(document.body,{attributes:true,attributeFilter:['class']});mobile.addEventListener('change',scheduleNavigation);window.addEventListener('resize',scheduleNavigation);window.addEventListener('scroll',scheduleNavigation,true);update();scheduleNavigation();
})();

;
// Single owner for the stateful selection DOM used by editing, reading and output.
window.Bolxiv.selectionSurface=(()=>{
 const mobile=matchMedia('(max-width:850px)'),records=new Map();let reader=null,output=null,generation=0,noteOwned=false,currentDestination=null;
 function register(key,node){if(!records.has(key)){const home=document.createComment('selection surface '+key+' home');node.before(home);records.set(key,{node,home})}return records.get(key)}
 function place(record,target){const {node}=record;if(!target){if(node.previousSibling===record.home)return;target={parent:record.home.parentNode,before:record.home.nextSibling}}if(!target.parent||node===target.before||node.parentNode===target.parent&&(target.before?node.nextSibling===target.before:node===target.parent.lastChild))return;
  const focused=node.contains(document.activeElement)?document.activeElement:null,scrolls=[node,...node.querySelectorAll('textarea,#pages')].map(node=>({node,left:node.scrollLeft,top:node.scrollTop}));target.parent.insertBefore(node,target.before||null);focused?.focus({preventScroll:true});for(const item of scrolls){item.node.scrollLeft=item.left;item.node.scrollTop=item.top}
 }
 const row=register('content',document.querySelector('.content-select-row')),phases=register('phases',document.querySelector('.page-controls'));
 function sync(){const exporting=mobile.matches&&!!output,reading=mobile.matches&&!output&&!window.Bolxiv.pngPreview?.active&&boardReadOnly&&!!reader;
  const destination=exporting?output:reading?reader:null;
  if(destination!==currentDestination){document.getElementById('contentOptions').hidden=true;document.getElementById('contentSelect').setAttribute('aria-expanded','false');currentDestination=destination}
  const memo=document.getElementById('phaseMemo');if(memo&&(destination||noteOwned)){const record=register('note',memo);place(record,destination?{parent:destination.noteHost||destination.host}:null);noteOwned=!!destination}
  const noteInHost=destination&&memo?.parentNode===destination.host?memo:null;
  place(phases,destination?{parent:destination.host,before:destination.before||noteInHost}:null);
  place(row,destination?{parent:destination.host,before:destination.between||phases.node}:null);
  reader?.onChange(reading);
 }
 new MutationObserver(sync).observe(document.body,{attributes:true,attributeFilter:['class']});mobile.addEventListener('change',sync);
 return {registerReader(config){reader=config;sync()},acquireOutput(config){const token=++generation;output=config;sync();return ()=>{if(token!==generation)return;output=null;sync()}},sync};
})();

// Shared structure/presentation only; callers own state and event lifecycles.
function createGuideSectionHeading({label,body,actions=null}){
 const heading=document.createElement('h3'),toggle=document.createElement('button'),title=document.createElement('span'),mark=document.createElement('span');
 heading.className='guide-section-heading';toggle.type='button';toggle.className='guide-section-toggle';title.textContent=label;mark.className='guide-section-mark';mark.setAttribute('aria-hidden','true');
 const sync=()=>{toggle.setAttribute('aria-expanded',String(!body.hidden));mark.textContent=body.hidden?'＋':'−'};
 toggle.setAttribute('aria-controls',body.id);toggle.append(title,mark);heading.append(toggle);if(actions)heading.append(actions);
 toggle.onclick=()=>{body.hidden=!body.hidden;sync()};sync();return {heading,toggle};
}
function createPanelHeader({barClass,titleClass,switchClass,collapseClass,titleTag='span'}){
 const bar=document.createElement('div');bar.className=barClass;
 const title=document.createElement(titleTag);title.className=titleClass;if(titleTag==='button')title.type='button';
 const change=document.createElement('button');change.type='button';change.className=switchClass;change.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h16l-4-4M20 16H4l4 4"/></svg>';
 const collapse=document.createElement('button');collapse.type='button';collapse.className=collapseClass;
 bar.append(title,change,collapse);return {bar,title,change,collapse};
}
function updatePanelHeader({title,change,collapse},{markup,label,nextLabel,expanded,collapsible=true}){
 if(title.innerHTML!==markup)title.innerHTML=markup;
 const set=(node,name,value)=>{if(node.getAttribute(name)!==value)node.setAttribute(name,value)};
 const action=label+(expanded?'を閉じる':'を開く');
 if(collapsible){set(title,'aria-expanded',String(expanded));set(title,'aria-label',action)}else{title.removeAttribute('aria-expanded');title.removeAttribute('aria-label')}
 set(change,'aria-label',nextLabel);change.title=nextLabel;
 const mark=expanded?'−':'＋';if(collapse.textContent!==mark)collapse.textContent=mark;
 set(collapse,'aria-expanded',String(expanded));set(collapse,'aria-label',action);
}

// ===== js/mobile/phone-view-content.js =====
(()=>{
 const mobile=matchMedia('(max-width:850px)'),row=document.querySelector('.content-select-row');
 const phases=document.querySelector('.page-controls');
 const host=document.createElement('div');host.className='phone-view-content';host.setAttribute('aria-label','閲覧用コンテンツ・フェーズ選択');document.getElementById('objectLayerPanel').append(host);
 let active=false;
 const phaseToggle=document.getElementById('toggleBattlePages');let phaseMode=false,editExpanded=phaseToggle.getAttribute('aria-expanded')==='true',viewExpanded=typeof viewSettings.viewPhasesExpanded==='boolean'?viewSettings.viewPhasesExpanded:true;
 function syncPhaseMode(){if(!mobile.matches||phaseMode===boardReadOnly)return;const expanded=phaseToggle.getAttribute('aria-expanded')==='true';if(phaseMode)viewExpanded=expanded;else editExpanded=expanded;phaseMode=boardReadOnly;const target=phaseMode?viewExpanded:editExpanded;if(expanded!==target)phaseToggle.onclick({currentTarget:phaseToggle})}
 const header=createPanelHeader({barClass:'phone-reader-tabs',titleClass:'phone-reader-title',switchClass:'phone-reader-switch',collapseClass:'phone-reader-collapse',titleTag:'button'});
 const {bar:tabs,title,change,collapse}=header;
 tabs.addEventListener('click',event=>{if(event.target.closest('button'))return;collapse.click()});host.append(tabs);
 let readerTab=viewSettings.phoneReaderTab==='memo'?'memo':'list';
 function syncReaderTabs(){
  const open=phaseToggle.getAttribute('aria-expanded')==='true';
  const group=!!data.activePhaseGroup,visibleTab=group?'list':readerTab;
  change.hidden=group;
  if(host.dataset.readerTab!==visibleTab)host.dataset.readerTab=visibleTab;if(host.dataset.readerExpanded!==String(open))host.dataset.readerExpanded=String(open);
  const markup=group?'<strong>フェーズリスト</strong>':readerTab==='list'?'<strong>フェーズリスト</strong> / ノート':'フェーズリスト / <strong>ノート</strong>';
  updatePanelHeader(header,{markup,label:visibleTab==='list'?'フェーズリスト':'フェーズノート',nextLabel:readerTab==='list'?'フェーズノートを表示':'フェーズリストを表示',expanded:open});
  const memo=host.querySelector('.phase-memo');
  if(active&&memo&&visibleTab==='memo'&&!memo.open)memo.open=true;
 }
 collapse.onclick=()=>{phaseToggle.click();syncReaderTabs()};title.onclick=()=>collapse.click();
 change.onclick=()=>{readerTab=readerTab==='list'?'memo':'list';rememberViewSetting('phoneReaderTab',readerTab);if(phaseToggle.getAttribute('aria-expanded')!=='true')phaseToggle.click();syncReaderTabs();size()};
 const panel=document.getElementById('objectLayerPanel'),space=document.getElementById('boardZoomSpace'),viewport=space.parentElement;
 function size(){
  if(!active||window.Bolxiv?.pngPreview?.active)return;
  syncReaderTabs();
  const noteHeight=0;
  const closed=phaseToggle.getAttribute('aria-expanded')==='false',rowHeight=row.getBoundingClientRect().height,metrics=phoneReaderLayoutMetrics(panel,noteHeight,rowHeight),closedHeight=rowHeight+(parseFloat(getComputedStyle(tabs).marginTop)||0)+tabs.getBoundingClientRect().height+noteHeight;
  if(closed){
   if(panel.style.getPropertyValue('--phone-reader-controls-height')!==closedHeight+'px')panel.style.setProperty('--phone-reader-controls-height',closedHeight+'px');
   return;
  }
  const reserved=metrics.controlsMinHeight;
  const height=metrics.canvasHeight+'px';
  if(panel.style.getPropertyValue('--phone-reader-canvas-height')!==height)panel.style.setProperty('--phone-reader-canvas-height',height);
  if(panel.style.getPropertyValue('--phone-reader-controls-height')!==reserved+'px')panel.style.setProperty('--phone-reader-controls-height',reserved+'px');
 }
 let sizeFrame=0;function scheduleSize(){if(!sizeFrame)sizeFrame=requestAnimationFrame(()=>{sizeFrame=0;size()})}
 new MutationObserver(scheduleSize).observe(document.getElementById('toggleBattlePages'),{attributes:true,attributeFilter:['aria-expanded']});
 const resize=new ResizeObserver(scheduleSize);resize.observe(panel);resize.observe(viewport);window.addEventListener('resize',scheduleSize);
 host.addEventListener('toggle',scheduleSize,true);
 new MutationObserver(records=>{if(records.some(record=>!tabs.contains(record.target)))scheduleSize()}).observe(host,{childList:true,subtree:true,attributes:true,attributeFilter:['hidden']});
 new MutationObserver(scheduleSize).observe(space,{childList:true,attributes:true,attributeFilter:['style']});viewport.addEventListener('scroll',scheduleSize,{passive:true});
 function sync(next){syncPhaseMode();active=next;if(active)syncReaderTabs();scheduleSize()}
 window.Bolxiv.selectionSurface.registerReader({host,between:tabs,noteHost:host,onChange:sync});scheduleSize();
})();

;
// ===== js/canvas/board-zoom-menu.js =====
(()=>{
 const trigger=document.getElementById('resetBoardZoom'),menu=document.createElement('div');menu.id='boardZoomMenu';menu.className='board-zoom-menu';menu.hidden=true;menu.setAttribute('role','menu');menu.setAttribute('aria-label','表示倍率');document.body.append(menu);
 trigger.title='表示倍率を選択';trigger.setAttribute('aria-label','表示倍率を選択');trigger.setAttribute('aria-haspopup','menu');trigger.setAttribute('aria-controls',menu.id);trigger.setAttribute('aria-expanded','false');
 const items=[200,150,100,75,50,25].map(value=>{const item=document.createElement('button');item.type='button';item.setAttribute('role','menuitemradio');item.dataset.zoom=String(value);item.textContent=value+'%';item.onclick=()=>{setBoardDisplayZoom(value);close(true)};menu.append(item);return item});
 function mark(){for(const item of items)item.setAttribute('aria-checked',String(Number(item.dataset.zoom)===boardDisplayZoom))}
 function close(focus=false){menu.hidden=true;trigger.setAttribute('aria-expanded','false');if(focus)trigger.focus({preventScroll:true})}
 function open(){closeColorPopovers();closeJsonExportMenu();closeJsonImportMenu();closeHelpMenu();mark();addPhoneMenuClose(menu,()=>close(true));menu.hidden=false;trigger.setAttribute('aria-expanded','true');const rect=trigger.getBoundingClientRect(),height=menu.offsetHeight;menu.style.left=Math.max(8,Math.min(rect.right-menu.offsetWidth,window.innerWidth-menu.offsetWidth-8))+'px';menu.style.top=Math.max(8,Math.min(rect.bottom+4,window.innerHeight-height-8))+'px';menu.style.maxHeight=Math.max(36,window.innerHeight-16)+'px';(items.find(item=>item.getAttribute('aria-checked')==='true')||items[0]).focus({preventScroll:true})}
 trigger.onclick=()=>{if(menu.hidden)open();else close()};
 trigger.addEventListener('keydown',event=>{if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();open();if(event.key==='ArrowUp')items.at(-1).focus()}});
 menu.addEventListener('keydown',event=>{const index=items.indexOf(document.activeElement);if(event.key==='Escape'){event.preventDefault();close(true)}else if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();items[(index+(event.key==='ArrowDown'?1:items.length-1))%items.length].focus()}else if(event.key==='Home'||event.key==='End'){event.preventDefault();items[event.key==='Home'?0:items.length-1].focus()}else if(event.key==='Tab')close()});
 document.addEventListener('pointerdown',event=>{if(!menu.contains(event.target)&&!trigger.contains(event.target)&&!event.target.closest('#boardGridMenu'))close()},true);
 window.addEventListener('resize',()=>close());
 new MutationObserver(mark).observe(document.getElementById('boardZoomValue'),{childList:true,subtree:true,characterData:true});
})();

;

// Grid spacing is a display option shared by content and field editing.
(()=>{
 const menu=document.createElement('div');menu.id='boardGridMenu';menu.className='board-zoom-menu';menu.hidden=true;menu.setAttribute('role','menu');menu.setAttribute('aria-label','グリッド線');document.body.append(menu);
 const spacingOptions=[8,16,32,64,128],source=document.getElementById('gridToggle');
 let anchor=null;
 for(const trigger of [source,document.getElementById('guide-gridToggle')].filter(Boolean)){
  trigger.setAttribute('aria-haspopup','menu');trigger.setAttribute('aria-controls',menu.id);trigger.setAttribute('aria-expanded','false');
 }
 function close(focus=false){
  const trigger=anchor;anchor=null;menu.hidden=true;
  trigger?.setAttribute('aria-expanded','false');
  if(focus)trigger?.focus({preventScroll:true});
 }
 window.Bolxiv.openGridMenu=(trigger,originBounds=null)=>{
  if(source.disabled||trigger.disabled||window.Bolxiv.pngPreview?.active)return;
  if(anchor===trigger&&!menu.hidden){close(true);return}
  close();anchor=trigger;
  const tiled=activeBoardShape()==='image4',spacing=tiled&&gridSpacing===128?64:gridSpacing;
  const options=[0,...spacingOptions.filter(value=>!tiled||value!==128)];
  const items=options.map(value=>{
   const item=document.createElement('button');item.type='button';item.setAttribute('role','menuitemradio');
   item.textContent=value===0?'非表示':value===32?'32px（標準）':value+'px';
   item.setAttribute('aria-checked',String(value===(gridVisible?spacing:0)));
   item.onclick=()=>{
    gridVisible=value!==0;
    if(value)gridSpacing=value;
    updateGridToggle();render();close(true);
   };
   return item;
  });
  menu.replaceChildren(...items);addPhoneMenuClose(menu,()=>close(true));
  menu.hidden=false;trigger.setAttribute('aria-expanded','true');
  const bounds=originBounds||trigger.getBoundingClientRect();
  if(originBounds){
   menu.style.left=Math.max(4,Math.min(bounds.right+menu.offsetWidth<=innerWidth?bounds.right-2:bounds.left-menu.offsetWidth+2,innerWidth-menu.offsetWidth-4))+'px';
   menu.style.top=Math.max(4,Math.min(bounds.top,innerHeight-menu.offsetHeight-4))+'px';
  }else{
   menu.style.left=Math.max(4,Math.min(bounds.right-menu.offsetWidth,innerWidth-menu.offsetWidth-4))+'px';
   menu.style.top=Math.max(4,Math.min(bounds.bottom+4,innerHeight-menu.offsetHeight-4))+'px';
  }
  (items.find(item=>item.getAttribute('aria-checked')==='true')||items[0]).focus({preventScroll:true});
 };
 document.addEventListener('pointerdown',event=>{if(anchor&&!anchor.contains(event.target)&&!menu.contains(event.target))close()},true);
 window.addEventListener('resize',()=>close());
})();

// User presets are an independent library, never part of content JSON.
const userPresetLibrary=(()=>{
 const key='bolxiv-user-presets-v1';let presets=[],importedPresetToReveal=null;const presetHistory=[],presetFuture=[];
 try{const stored=JSON.parse(localStorage.getItem(key)||'[]');if(Array.isArray(stored))presets=stored.filter(p=>p&&typeof p.id==='string'&&typeof p.name==='string'&&Array.isArray(p.items)&&p.items.length)}catch{}
 const grid=document.getElementById('userPresetGrid'),empty=document.getElementById('userPresetEmpty'),panel=document.getElementById('presetPanel'),heading=document.querySelector('.accordion-toggle[aria-controls="presetPanel"]');
 const manage=document.createElement('button');manage.type='button';manage.className='btn preset-manage';manage.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2" stroke-dasharray="2 3"/><circle cx="8.5" cy="8.5" r="2.5"/><path d="M13 6h5v5h-5zM8.5 13l3 5h-6zM14 16h4M16 14v4"/></svg>';manage.title='プリセットの管理';manage.setAttribute('aria-label','プリセットの管理');manage.setAttribute('aria-haspopup','menu');manage.setAttribute('aria-expanded','false');manage.setAttribute('aria-pressed','false');document.querySelector('.left .object-pane-actions').prepend(manage);document.querySelector('.left .object-pane-actions').append(document.getElementById('leftRailToggle'));
 const presetManagementIcon=manage.innerHTML,objectPlacementIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 3v14l4-4 3 6 3-1-3-6 6-1Z"/><circle cx="18" cy="5" r="2.5"/><path d="M17 15h4v5h-4z"/></svg>';
 function syncMaterialViewIcon(managing){manage.innerHTML=managing?presetManagementIcon:objectPlacementIcon;manage.dataset.materialView=managing?'presets':'placement';manage.title=managing?'プリセット管理（クリックでオブジェクト配置へ）':'オブジェクト配置（クリックでプリセット管理へ）';manage.setAttribute('aria-label',manage.title)}
 syncMaterialViewIcon(false);
 const menu=document.createElement('div');menu.id='userPresetMenu';manage.setAttribute('aria-controls',menu.id);menu.className='object-context-menu';menu.hidden=true;menu.setAttribute('role','menu');document.body.append(menu);
 function close(){const restore=!menu.hidden&&menu.contains(document.activeElement)&&matchMedia('(min-width:851px)').matches,origin=menu._opener;menu.hidden=true;if(restore){manage.focus({preventScroll:true});origin?.closest('.preset-manager-row')?.focus({preventScroll:true})}}
 function blocked(){return boardReadOnly||phaseComparisonActive()||window.Bolxiv?.pngPreview?.active||window.Bolxiv?.phaseMasters?.active}
 function recordPresetChange(before,after,customLabel=null){if(before===after)return;const a=JSON.parse(before),b=JSON.parse(after),label=customLabel||(b.length>a.length?'登録':b.length<a.length?'削除':a.some((item,index)=>item.id!==b[index]?.id)?'並べ替え':'名前変更');presetHistory.push({before,after,label});if(presetHistory.length>50)presetHistory.shift();presetFuture.length=0}
 function save(next,{record=true,label=null}={}){const before=JSON.stringify(presets),after=JSON.stringify(next);window.BolxivSaveStatus.set('presets','保存中…');try{localStorage.setItem(key,after);presets=next;if(record)recordPresetChange(before,after,label);window.BolxivSaveStatus.set('presets','保存済み');render();renderManager();syncPresetHistory();return true}catch(error){window.BolxivSaveStatus.set('presets','未保存');console.warn('Preset persistence failed',error);notifyFailure('プリセットを保存できませんでした',{error,retained:editingPreset?'入力した名称はそのまま残っています':'保存済みのプリセットは変更していません',action:editingPreset?'ページを閉じずに空き容量・保存設定を確認し、もう一度確定してください':'「エクスポート」からユーザープリセットJSONを保存し、空き容量・保存設定を確認してください'});return false}}
 const historyButtons=[];for(const [id,redo] of [['presetUndo',false],['presetRedo',true]]){const button=document.createElement('button');button.id=id;button.type='button';button.className='btn preset-history content-history-button';button.innerHTML=document.getElementById(redo?'redo':'undo').innerHTML;button.onclick=()=>restorePresetHistory(redo);manage.parentElement.insertBefore(button,document.getElementById('leftRailToggle'));historyButtons.push(button)}
 function syncPresetHistory(){for(const [index,button] of historyButtons.entries()){const entries=index?presetFuture:presetHistory,action=index?'やり直す':'元に戻す';button.disabled=blocked()||!!editingPreset||!entries.length;button.title=entries.length?'プリセット：'+entries.at(-1).label+'を'+action:'プリセットに'+(index?'やり直せる':'元に戻せる')+'操作はありません';button.setAttribute('aria-label',button.title)}}
 function restorePresetHistory(redo=false){if(blocked()||editingPreset)return;const source=redo?presetFuture:presetHistory,target=redo?presetHistory:presetFuture,entry=source.at(-1);if(!entry)return;if(save(JSON.parse(redo?entry.after:entry.before),{record:false})){source.pop();target.push(entry);if(activeIcon?.userPresetId&&!presets.some(item=>item.id===activeIcon.userPresetId)){setTapPlacementArmed(false);selectPlacementTool('select')}syncPresetHistory();notify('プリセットの'+entry.label+'を'+(redo?'やり直しました':'元に戻しました'))}}

 function show(anchor,actions,point=null){close();menu._opener=anchor;menu.replaceChildren();for(const [label,action,disabled=false] of actions){menu.append(createMenuAction({label,disabled,destructive:label==='削除',shortcut:label==='名前変更'?'F2':null,onInvoke(){close();action()}}))}addPhoneMenuClose(menu,close);const r=point||anchor.getBoundingClientRect();menu.hidden=false;menu.style.left=Math.max(4,Math.min(r.left,innerWidth-menu.offsetWidth-4))+'px';menu.style.top=Math.max(4,Math.min(r.bottom+4,innerHeight-menu.offsetHeight-4))+'px';menu.querySelector('button:not(:disabled)')?.focus()}
 window.addEventListener('pointerdown',e=>{if(!menu.contains(e.target)&&!manage.contains(e.target))close()},true);window.addEventListener('keydown',e=>{if(e.key==='Escape'&&!menu.hidden){e.preventDefault();e.stopImmediatePropagation();const origin=menu._opener;close();(origin?.closest('.preset-manager-row')||origin)?.focus({preventScroll:true})}},true);window.addEventListener('resize',close);
 function liveThumbnail(items){return createPresetArtworkThumbnail(items)}
 const thumbnailCache=new Map(),thumbnailJobs=[];let thumbnailRunning=false;
 function thumbnailImage(url){const image=new Image();image.src=url;image.alt='';image.style.cssText='display:block;width:26px!important;height:26px!important;max-width:none!important;max-height:none!important';return image}
 function scheduleThumbnail(){if(thumbnailRunning||!thumbnailJobs.length)return;thumbnailRunning=true;const run=async()=>{const job=thumbnailJobs.shift(),host=document.createElement('div');host.className='left pinned';host.setAttribute('aria-hidden','true');host.style.cssText='display:block!important;position:fixed!important;left:-10000px!important;top:0!important;width:26px!important;height:26px!important;padding:0!important;border:0!important;overflow:hidden!important;pointer-events:none!important';const source=liveThumbnail(job.items);source.style.cssText='display:block;position:relative;width:26px;height:26px;overflow:hidden';host.append(source);document.body.append(host);try{const bitmap=await rasterizePngSource(source,3);job.bitmap=bitmap;job.url=bitmap.toDataURL('image/png');for(const node of job.nodes)if(node.isConnected)node.replaceChildren(thumbnailImage(job.url))}catch{thumbnailCache.delete(job.key)}finally{host.remove();job.nodes.clear();thumbnailRunning=false;scheduleThumbnail()}};if(window.requestIdleCallback)requestIdleCallback(run,{timeout:1000});else setTimeout(run,0)}
 function thumbnail(items){
  const desktop=matchMedia('(min-width:851px)').matches,key=JSON.stringify(items);let cached=thumbnailCache.get(key);
  if(!cached){cached={key,items:JSON.parse(key),nodes:new Set(),url:null,bitmap:null};thumbnailCache.set(key,cached);thumbnailJobs.push(cached);if(thumbnailCache.size>200)thumbnailCache.delete(thumbnailCache.keys().next().value)}
  if(!desktop&&cached.url){const thumb=document.createElement('span');thumb.className='preset-thumbnail';thumb.setAttribute('aria-hidden','true');thumb.append(thumbnailImage(cached.url));return thumb}
  const thumb=liveThumbnail(items);if(!desktop)cached.nodes.add(thumb);scheduleThumbnail();return thumb;
 }

 function dragImage(id){const preset=presets.find(p=>p.id===id);if(!preset)return null;const key=JSON.stringify(preset.items),cached=thumbnailCache.get(key);if(!cached)thumbnail(preset.items);return cached?.bitmap||null}
 function render(){grid.replaceChildren();empty.hidden=presets.length>0;for(const preset of presets){const button=document.createElement('button');button.type='button';button.className='icon-choice user-preset';button.dataset.presetId=preset.id;button.title=preset.name;button.setAttribute('aria-label',preset.name);button.draggable=true;button.disabled=blocked();button.append(thumbnail(preset.items));button.onpointerenter=()=>{if(matchMedia('(min-width:851px)').matches)dragImage(preset.id)};const icon={name:preset.name,userPresetId:preset.id};button.onclick=()=>{if(!blocked())selectPlacementIcon(icon)};button.ondragstart=e=>{if(blocked()){e.preventDefault();return}selectPlacementIcon(icon,false);e.dataTransfer.setData('application/x-tactica',JSON.stringify({type:'icon',...icon}));e.dataTransfer.effectAllowed='copy'};
  function actions(){show(button,[['名前変更',()=>renamePreset(preset),blocked()],['削除',()=>deletePreset(preset.id),blocked()]])}
  button.oncontextmenu=e=>{e.preventDefault();e.stopPropagation();if(!matchMedia('(max-width:850px)').matches)actions()};grid.append(button)}}
 let editingPreset=null,presetDraft=null;
 function renamePreset(preset,isNew=false,onFinish=null){
  if(blocked())return;if(editingPreset?.id===preset.id){editingPreset.input.focus();editingPreset.input.select();return}if(editingPreset&&!editingPreset.finish())return;
  if(manager.hidden)openManager();
  const row=[...manager.querySelectorAll('.preset-manager-row')].find(row=>row.dataset.presetId===preset.id);if(!row)return;
  const input=document.createElement('input');input.type='text';input.className='preset-manager-name-input';input.value=preset.name;input.maxLength=80;input.setAttribute('aria-label','プリセット名');row.classList.add('renaming');row.append(input);let done=false;const viewport=window.visualViewport;const revealInput=()=>{if(!input.isConnected){cleanup();return}const bounds=manager.getBoundingClientRect(),r=input.getBoundingClientRect(),top=Math.max(bounds.top+manager.clientTop,viewport?.offsetTop||0)+4,bottom=Math.min(bounds.top+manager.clientTop+manager.clientHeight,viewport?viewport.offsetTop+viewport.height:innerHeight)-4;if(r.top<top)manager.scrollTop+=r.top-top;else if(r.bottom>bottom)manager.scrollTop+=r.bottom-bottom};const resize=new ResizeObserver(()=>requestAnimationFrame(revealInput));resize.observe(manager);function cleanup(){resize.disconnect();window.removeEventListener('resize',revealInput);viewport?.removeEventListener('resize',revealInput);viewport?.removeEventListener('scroll',revealInput)}window.addEventListener('resize',revealInput);viewport?.addEventListener('resize',revealInput);viewport?.addEventListener('scroll',revealInput);
  const previousSaveStatus=window.BolxivSaveStatus.get('presets')||'保存済み';
  function complete(){done=true;cleanup();editingPreset=null;if(isNew){presetDraft=null;materialPane.classList.remove('preset-registering');manage.disabled=false;onFinish?.()}syncManagerControls();syncPresetHistory()}
  function finish(cancel=false){
   if(done)return true;
   if(cancel){if(isNew)presetDraft=null;window.BolxivSaveStatus.set('presets',previousSaveStatus);complete();renderManager();return true}
   if(blocked()){notify('編集モードに戻してから確定してください');return false}
   const name=input.value.trim()||preset.name;
   if(!isNew&&name===preset.name){window.BolxivSaveStatus.set('presets',previousSaveStatus);complete();renderManager();return true}
   const next=isNew?[...presets,{...preset,name}]:presets.map(item=>item.id===preset.id?{...item,name}:item),draft=presetDraft;
   if(isNew)presetDraft=null;
   if(!save(next)){presetDraft=draft;input.focus({preventScroll:true});revealInput();return false}
   complete();return true;
  }

  editingPreset={id:preset.id,input,finish,isNew};if(isNew){materialPane.classList.add('preset-registering');manage.disabled=true;manager.querySelector('#registerUserPreset').disabled=true}syncPresetHistory();if(isNew)window.BolxivSaveStatus.set('presets','未保存の変更あり');input.oninput=()=>window.BolxivSaveStatus.set('presets',isNew||input.value.trim()!==preset.name?'未保存の変更あり':previousSaveStatus);row.querySelectorAll('button').forEach(button=>button.remove());const confirm=document.createElement('button'),cancel=document.createElement('button');for(const button of [confirm,cancel]){button.type='button';button.className='btn preset-manager-action';button.dataset.presetAction='編集';button.onpointerdown=event=>event.preventDefault();row.append(button)}confirm.textContent='✓';confirm.title='変更を確定';confirm.setAttribute('aria-label',preset.name+'：変更を確定');confirm.onclick=()=>finish();cancel.textContent='↶';cancel.title=isNew?'登録を取り消す':'変更を取り消す';cancel.setAttribute('aria-label',preset.name+'：'+cancel.title);cancel.onpointerdown=event=>{event.preventDefault();event.stopPropagation()};cancel.onclick=()=>finish(true);
  input.onkeydown=event=>{if(event.isComposing||event.keyCode===229)return;if(event.key==='Enter'){event.preventDefault();event.stopPropagation();finish()}else if(event.key==='Escape'){event.preventDefault();event.stopPropagation();finish(true)}};input.onblur=()=>{if(!isNew)finish()};input.focus();input.select();revealInput();requestAnimationFrame(revealInput);
 }
 function deletePreset(id){if(blocked())return;if(editingPreset&&!editingPreset.finish())return;if(activeIcon?.userPresetId===id){setTapPlacementArmed(false);selectPlacementTool('select')}save(presets.filter(preset=>preset.id!==id))}
 function registerSelection(onFinish=null,asSvg=false){  if(blocked())return;const originals=current().filter(o=>selectedIds.includes(o.id));if(selectionHasImportedImages(originals)){notify('画像を含む選択はプリセットに登録できません');return}const reuseSvg=asSvg&&originals.length===1&&originals[0].type==='icon'&&originals[0].svgPreset===true;if(originals.length<2&&!reuseSvg)return;const items=asSvg&&!reuseSvg?[createSvgPresetItem(originals)]:JSON.parse(JSON.stringify(originals));if(reuseSvg)items[0].visible=true;for(const item of items){if(item.imageId){item.src=objectImageSource(item);delete item.imageId}delete item.id}
  if(editingPreset&&!editingPreset.finish())return;const name=reuseSvg?objectTitle(originals[0]).slice(0,80):selectedObjectGroup().length?objectGroupName(originals):'新しいプリセット',id=createObjectId();for(const item of items){item.locked=false;if(!item.svgPreset){item.objectGroupId=id;item.objectGroupName=name}else{delete item.objectGroupId;delete item.objectGroupName}delete item.objectGroupRotationOwner;delete item.objectGroupPlacementRotation;delete item.objectGroupOrientationRotation}const preset={id,name,items};presetDraft=preset;renderManager();renamePreset(preset,true,onFinish);
 }

 const materialCategories=document.createElement('div');materialCategories.className='material-categories-scroll';const materialHost=document.querySelector('.left');for(const child of [...materialHost.children])if(!child.matches('.material-heading,.object-pane-actions,.phone-material-category-tabs'))materialCategories.append(child);materialHost.append(materialCategories);const syncMaterialScrollInset=()=>{const style=getComputedStyle(materialHost),padding=parseFloat(style.paddingRight)||0,gutter=materialHost.offsetWidth-materialHost.clientWidth-(parseFloat(style.borderLeftWidth)||0)-(parseFloat(style.borderRightWidth)||0);materialHost.style.setProperty('--material-scroll-inset',padding+'px');materialHost.style.setProperty('--material-scroll-outset',(padding+gutter)+'px')};new ResizeObserver(syncMaterialScrollInset).observe(materialHost);syncMaterialScrollInset();
 const manager=document.createElement('section');manager.id='userPresetManager';manager.className='preset-manager-panel';manager.hidden=true;manager.setAttribute('role','region');manager.setAttribute('aria-labelledby','userPresetManagerTitle');manager.innerHTML='<header class="preset-manager-heading"><span class="preset-manager-title-icon" aria-hidden="true"></span><h2 id="userPresetManagerTitle">プリセット管理</h2><button type="button" class="btn" id="registerUserPreset" aria-label="選択中のオブジェクトを登録" title="選択中をプリセットに登録"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg></button></header><div class="preset-manager-body"><p class="preset-manager-hint">2個以上選択して登録</p><div class="preset-manager-list" role="list" aria-label="登録済みプリセット"></div><p class="preset-manager-empty">登録済みプリセットはありません。</p></div>';manager.querySelector('.preset-manager-title-icon').innerHTML=heading.querySelector('.palette-category-icon').innerHTML;const managerFrame=document.createElement('div');managerFrame.className='preset-manager-frame';managerFrame.append(...manager.childNodes);manager.append(managerFrame);const materialPane=document.querySelector('.left');materialPane.append(manager);let materialScroll=0,categoryDisabled=false;const categoryMode=document.getElementById('categoryModeToggle');
 manage.removeAttribute('aria-haspopup');manage.setAttribute('aria-controls',manager.id);
 function revealImportedPreset(){if(!importedPresetToReveal||manager.hidden||!manager.clientHeight)return;const row=[...manager.querySelectorAll('.preset-manager-row')].find(row=>row.dataset.presetId===importedPresetToReveal);if(row)revealMovedListItems(manager,[row]);importedPresetToReveal=null}
 function openManager(){if(!manager.hidden)return;close();materialScroll=materialCategories.scrollTop;renderManager();manager.hidden=false;materialPane.classList.add('preset-managing');materialCategories.scrollTop=0;manage.setAttribute('aria-expanded','true');manage.setAttribute('aria-pressed','true');syncMaterialViewIcon(true);categoryDisabled=categoryMode.disabled;categoryMode.disabled=true;requestAnimationFrame(revealImportedPreset)}
 function closeManager(){if(editingPreset&&!editingPreset.finish())return;manager.hidden=true;materialPane.classList.remove('preset-managing');manage.setAttribute('aria-expanded','false');manage.setAttribute('aria-pressed','false');syncMaterialViewIcon(false);categoryMode.disabled=categoryDisabled;manage.focus({preventScroll:true});materialCategories.scrollTop=materialScroll;requestAnimationFrame(()=>{if(manager.hidden)materialCategories.scrollTop=materialScroll})}
 manager.querySelector('#registerUserPreset').onclick=()=>registerSelection();
 manager.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();if(editingPreset)editingPreset.finish(true);else closeManager()}});
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!manager.hidden&&!event.defaultPrevented){event.preventDefault();if(editingPreset)editingPreset.finish(true);else closeManager()}});
 function movePreset(id,targetId,after=false){if(blocked()||editingPreset||id===targetId)return;const next=presets.slice(),from=next.findIndex(item=>item.id===id);if(from<0)return;const [item]=next.splice(from,1),at=next.findIndex(item=>item.id===targetId);if(at<0)return;next.splice(at+(after?1:0),0,item);save(next)}
 // Native drag images are flat rows, never a live transformed thumbnail tree.
 manager._createNativeDragImage=row=>{
  const bitmap=dragImage(row.dataset.presetId);if(!bitmap)return null;
  const bounds=row.getBoundingClientRect(),canvas=document.createElement('canvas');canvas.width=Math.ceil(bounds.width);canvas.height=Math.ceil(bounds.height);canvas.setAttribute('aria-label',row.querySelector('.preset-manager-name').textContent);const ctx=canvas.getContext('2d'),style=getComputedStyle(row);ctx.fillStyle=style.backgroundColor;ctx.beginPath();ctx.roundRect(0,0,bounds.width,bounds.height,parseFloat(style.borderRadius)||0);ctx.fill();
  const thumb=row.querySelector('.preset-thumbnail'),icon=thumb.getBoundingClientRect();ctx.drawImage(bitmap,icon.left-bounds.left,icon.top-bounds.top,icon.width,icon.height);
  const name=row.querySelector('.preset-manager-name'),label=name.getBoundingClientRect(),labelStyle=getComputedStyle(name);ctx.font=labelStyle.font;ctx.fillStyle=labelStyle.color;ctx.textBaseline='middle';let text=name.textContent;if(ctx.measureText(text).width>label.width){while(text&&ctx.measureText(text+'…').width>label.width)text=text.slice(0,-1);text+='…';}ctx.fillText(text,label.left-bounds.left,label.top-bounds.top+label.height/2);
  for(const dot of row.querySelectorAll('.list-drag-grip circle')){const r=dot.getBoundingClientRect();if(!r.width)continue;ctx.fillStyle=getComputedStyle(dot).color;ctx.beginPath();ctx.arc(r.left-bounds.left+r.width/2,r.top-bounds.top+r.height/2,r.width/2,0,Math.PI*2);ctx.fill();}
  for(const button of row.querySelectorAll('.preset-manager-desktop-delete')){const r=button.getBoundingClientRect();if(!r.width)continue;const b=getComputedStyle(button);ctx.font=b.font;ctx.fillStyle=b.color;ctx.textAlign='center';ctx.fillText('×',r.left-bounds.left+r.width/2,r.top-bounds.top+r.height/2);}
  return canvas;
 };
 function bindPresetReorder(row,preset){row.draggable=true;row.onpointerdown=event=>{row.draggable=!blocked()&&!editingPreset&&!event.target.closest('button,input')};row.ondragstart=event=>{if(blocked()||editingPreset){event.preventDefault();return}event.dataTransfer.setData('application/x-bolxiv-user-preset-order',preset.id);event.dataTransfer.effectAllowed='move'};row.ondragover=event=>{if(!event.dataTransfer.types.includes('application/x-bolxiv-user-preset-order')||blocked()||editingPreset)return;event.preventDefault();const after=event.clientY>row.getBoundingClientRect().top+row.offsetHeight/2;row.classList.toggle('drop-after',after);row.classList.toggle('drop-before',!after);row.classList.add('drag-over')};row.ondragleave=()=>row.classList.remove('drag-over','drop-before','drop-after');row.ondrop=event=>{event.preventDefault();row.classList.remove('drag-over','drop-before','drop-after');movePreset(event.dataTransfer.getData('application/x-bolxiv-user-preset-order'),preset.id,event.clientY>row.getBoundingClientRect().top+row.offsetHeight/2)};row.ondragend=()=>manager.querySelectorAll('.preset-manager-row.drag-over').forEach(node=>node.classList.remove('drag-over','drop-before','drop-after'))}
 window.bindTouchListReorder?.(['userPresetManager','.preset-manager-row','.preset-manager-leading,.preset-manager-menu','application/x-bolxiv-user-preset-order']);
 function renderManager(){
  const list=manager.querySelector('.preset-manager-list');list.replaceChildren();manager.querySelector('#registerUserPreset').disabled=selectionHasImportedImages()||!!editingPreset?.isNew||blocked()||current().filter(o=>selectedIds.includes(o.id)).length<2;manager.querySelector('.preset-manager-hint').textContent=selectionHasImportedImages()?'画像を含む選択は登録できません':'2個以上選択して登録';manager.querySelector('.preset-manager-hint').hidden=!manager.querySelector('#registerUserPreset').disabled;manager.querySelector('.preset-manager-empty').hidden=presets.length>0||!!presetDraft;
  for(const preset of presetDraft?[...presets,presetDraft]:presets){const row=document.createElement('div');row.className='preset-manager-row';row.dataset.presetId=preset.id;row.tabIndex=0;row.addEventListener('rename-item',()=>{if(!blocked())renamePreset(preset)});row.onclick=event=>{if(!event.target.closest('button,input'))row.focus({preventScroll:true})};row.setAttribute('role','listitem');const leading=document.createElement('span');leading.className='preset-manager-leading';const grip=document.createElement('span');grip.className='list-drag-grip';grip.setAttribute('aria-hidden','true');grip.innerHTML='<svg viewBox="0 0 10 16" fill="currentColor"><circle cx="3" cy="3" r="1.2"/><circle cx="7" cy="3" r="1.2"/><circle cx="3" cy="8" r="1.2"/><circle cx="7" cy="8" r="1.2"/><circle cx="3" cy="13" r="1.2"/><circle cx="7" cy="13" r="1.2"/></svg>';leading.append(grip,thumbnail(preset.items));row.append(leading);const summary=document.createElement('div');summary.className='preset-manager-summary';const name=document.createElement('span');name.className='preset-manager-name';name.textContent=preset.name;name.title=preset.name;summary.append(name);row.append(summary);const button=document.createElement('button');button.type='button';button.className='btn preset-manager-action preset-manager-menu';button.textContent='…';button.title='操作メニュー';button.setAttribute('aria-label',preset.name+'：操作メニュー');button.setAttribute('aria-haspopup','menu');button.setAttribute('aria-controls',menu.id);button.disabled=blocked();button.dataset.presetAction='メニュー';button.onpointerdown=event=>event.preventDefault();const actions=()=>{const index=presets.findIndex(item=>item.id===preset.id);return [['名前変更',()=>renamePreset(preset),blocked()],['前へ移動',()=>movePreset(preset.id,presets[index-1]?.id),blocked()||index===0],['後ろへ移動',()=>movePreset(preset.id,presets[index+1]?.id,true),blocked()||index===presets.length-1],['削除',()=>deletePreset(preset.id),blocked()]]};button.onclick=()=>show(button,actions());row.oncontextmenu=event=>{if(event.target.closest('input'))return;event.preventDefault();event.stopPropagation();if(!row.classList.contains('renaming'))show(button,actions(),{left:event.clientX,bottom:event.clientY})};row.append(button);const remove=document.createElement('button');remove.type='button';remove.className='btn preset-manager-action preset-manager-delete preset-manager-desktop-delete';remove.textContent='×';remove.title='削除';remove.setAttribute('aria-label',preset.name+'：削除');remove.dataset.presetAction='削除';remove.disabled=blocked();remove.onpointerdown=event=>event.preventDefault();remove.onclick=()=>deletePreset(preset.id);row.append(remove);bindPresetReorder(row,preset);row.querySelector('.preset-thumbnail').title='ドラッグで並べ替え';list.append(row)}
 }
 let reopenManager=false;manage.addEventListener('pointerdown',()=>{reopenManager=matchMedia('(min-width:851px)').matches&&!materialPane.matches('.pinned,.palette-hover-open,:focus-within')},true);
 manage.onclick=event=>{event.stopPropagation();if(reopenManager){reopenManager=false;manage.focus({preventScroll:true});return}if(manager.hidden)openManager();else closeManager()};

 function place(id,x,y){if(blocked())return;const preset=presets.find(p=>p.id===id);if(!preset)return;const items=JSON.parse(JSON.stringify(preset.items)),cx=(Math.min(...items.map(o=>o.x))+Math.max(...items.map(o=>o.x)))/2,cy=(Math.min(...items.map(o=>o.y))+Math.max(...items.map(o=>o.y)))/2;
  for(const item of items){item.id=createObjectId();item.x+=x-cx;item.y+=y-cy;if(item.objectGroupId)item.objectGroupName=preset.name;if(item.svgPreset)item.svgPresetName=preset.name;if(item.type==='icon'&&item.src?.startsWith('data:image/')){item.imageId=boardImageLibrary.register(item.src);delete item.src}}remapCopiedObjectGroups(items);snapshot();current().push(...items);individualGroupSelection=null;selectedIds=items.map(o=>o.id);selected=selectedIds[0];setTapPlacementArmed(false);selectPlacementTool('select');hideTouchPlacementPreview();renderAndSave();closePaletteAfterPlacement();
 }
 function syncManagerControls(){syncPresetHistory();if(manager.hidden)return;manager.querySelector('#registerUserPreset').disabled=selectionHasImportedImages()||!!editingPreset||blocked()||current().filter(o=>selectedIds.includes(o.id)).length<2;manager.querySelector('.preset-manager-hint').textContent=selectionHasImportedImages()?'画像を含む選択は登録できません':'2個以上選択して登録';manager.querySelector('.preset-manager-hint').hidden=!manager.querySelector('#registerUserPreset').disabled;for(const button of manager.querySelectorAll('[data-preset-action]'))button.disabled=blocked()}
 new MutationObserver(syncManagerControls).observe(document.body,{attributes:true,attributeFilter:['class']});
 const beforeManagerInspector=renderInspector;renderInspector=function(){const result=beforeManagerInspector.apply(this,arguments);syncManagerControls();return result};const beforeManagerSelection=renderSelectionOnly;renderSelectionOnly=function(){const result=beforeManagerSelection.apply(this,arguments);syncManagerControls();return result};

 const presetFileFormat='board-of-light-xiv-user-presets';
 function parsePresetFile(text){
  const value=JSON.parse(text,(key,value)=>{if(['__proto__','prototype','constructor'].includes(key))throw new Error('使用できない項目が含まれています');return value});
  if(value?.contents)throw new Error('コンテンツ用のJSONです。コンテンツの読み込みを選んでください');
  if(!value||value.format!==presetFileFormat||value.version!==1||!Array.isArray(value.presets))throw new Error('対応するユーザープリセットのJSONではありません');
  const types=new Set(['circle','donut','aoe','line','segment','text','marker','gaze','stack','linestack','targetcircle','knockback','lineknockback','icon']);
  return value.presets.map((preset,index)=>{
   if(!preset||typeof preset.name!=='string'||!preset.name.trim()||preset.name.length>80||!Array.isArray(preset.items)||!preset.items.length)throw new Error((index+1)+'件目のプリセットの名称またはオブジェクトが不正です');
   const id=createObjectId(),name=preset.name.trim();
   const items=preset.items.map(source=>{
    if(!source||!types.has(source.type)||!Number.isFinite(source.x)||!Number.isFinite(source.y))throw new Error(name+'：オブジェクトの種類または位置が不正です');
    for(const [key,value] of Object.entries(source))if(typeof value==='number'&&!Number.isFinite(value))throw new Error(name+'：数値が不正です');
    for(const key of ['width','height','fontSize'])if(source[key]!=null&&(!Number.isFinite(source[key])||source[key]<=0))throw new Error(name+'：サイズが不正です');
    for(const key of ['label','iconName','iconBadge','color'])if(source[key]!=null&&typeof source[key]!=='string')throw new Error(name+'：文字情報が不正です');
    for(const key of ['visible','locked'])if(source[key]!=null&&typeof source[key]!=='boolean')throw new Error(name+'：表示・編集設定が不正です');
    const item={...source};delete item.id;if(item.color&&!CSS.supports('color',item.color))throw new Error(name+'：色の指定が不正です');
    if(item.type==='icon'){
     if(item.imageId)throw new Error(name+'：画像データが含まれていません');
     if(isTowerObject(item)&&/^assets\/aoe\/tower[1-4]\.svg$/.test(item.src||''))item.src=towerIconSource(item);if(isBossObject(item)&&['assets/enemies/mini-boss.svg','assets/enemies/mid-boss.svg','assets/enemies/small-boss.svg'].includes(item.src))item.src=bossIconSource(item);
     if(item.src){const src=embeddedPngs[item.src]||item.src;if(typeof src!=='string'||!/^data:image\/(?:png|jpeg|gif|webp|svg\+xml)(?:;|,)/i.test(src))throw new Error(name+'：対応する埋め込み画像ではありません');item.src=src}
     else if(!isBossObject(item)&&!isTowerObject(item))throw new Error(name+'：画像がありません');
    }
    item.locked=false;if(!item.svgPreset){item.objectGroupId=id;item.objectGroupName=name}else{delete item.objectGroupId;delete item.objectGroupName}delete item.objectGroupRotationOwner;delete item.objectGroupPlacementRotation;delete item.objectGroupOrientationRotation;
    return item;
   });return {id,name,items};
  });
 }
 function presetSyncPayload(){
  if(editingPreset)throw new Error('プリセットの名前を確定または取り消してください');
  return {format:presetFileFormat,version:1,presets:presets.map(preset=>({...preset,items:preset.items.map(source=>{const item={...source};if(item.type==='icon'){item.src=isTowerObject(item)?towerIconSource(item):isBossObject(item)?bossIconSource(item):objectImageSource(item);if(!item.src)throw new Error('プリセットの画像が見つかりません');delete item.imageId}return item})}))};
 }
 async function exportPresets(){
  const payload=presetSyncPayload();
  return saveExportBlob(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),'BOARD_OF_LIGHT_XIV_ユーザープリセット.json','application/json','ユーザープリセット');
 }

 const presetImportInput=document.createElement('input');presetImportInput.type='file';presetImportInput.accept='.json,application/json';presetImportInput.id='presetFileInput';presetImportInput.hidden=true;document.body.append(presetImportInput);let presetImportMode='append';
 const presetReplaceDialog=document.createElement('dialog');presetReplaceDialog.id='replacePresetImportDialog';presetReplaceDialog.className='confirm-dialog';presetReplaceDialog.setAttribute('aria-labelledby','replacePresetImportTitle');presetReplaceDialog.innerHTML='<h2 id="replacePresetImportTitle">ユーザープリセットをすべて置き換え</h2><p data-preset-import-summary></p><p>コンテンツと配置済みオブジェクトは変更しません。置き換え後はプリセットの「元に戻す」で復元できます。</p><div class="confirm-actions"><button class="btn" type="button" data-preset-import-cancel autofocus>キャンセル</button><button class="btn primary" type="button" data-preset-import-confirm>置き換える</button></div>';document.body.append(presetReplaceDialog);
 function confirmPresetReplace(count){return new Promise(resolve=>{presetReplaceDialog.querySelector('[data-preset-import-summary]').textContent='現在のユーザープリセット（'+presets.length+'件）を、読み込んだデータ（'+count+'件）に置き換えます。';let done=false;const finish=accepted=>{if(done)return;done=true;presetReplaceDialog.oncancel=null;presetReplaceDialog.onclose=null;presetReplaceDialog.close();resolve(accepted)};presetReplaceDialog.querySelector('[data-preset-import-cancel]').onclick=()=>finish(false);presetReplaceDialog.querySelector('[data-preset-import-confirm]').onclick=()=>finish(true);presetReplaceDialog.oncancel=event=>{event.preventDefault();finish(false)};presetReplaceDialog.onclose=()=>finish(false);presetReplaceDialog.showModal()})}
 function choosePresetImport(mode){if(blocked()||editingPreset){notify('編集モードで名前入力を終えてから読み込んでください');return}presetImportMode=mode==='replace'?'replace':'append';presetImportInput.value='';presetImportInput.click()}
 presetImportInput.onchange=async()=>{const file=presetImportInput.files[0],mode=presetImportMode;if(!file)return;try{const imported=await withDesktopDisplayBusy(async()=>parsePresetFile(await file.text()));if(mode==='replace'&&!await confirmPresetReplace(imported.length))return;if(blocked()||editingPreset)throw new Error('編集モードで名前入力を終えてから読み込んでください');if(mode==='append'&&!imported.length){notify('追加するプリセットがありません');return}if(save(mode==='append'?[...presets,...imported]:imported,{label:mode==='append'?'追加読み込み':'全置き換え'})){if(activeIcon?.userPresetId&&!presets.some(preset=>preset.id===activeIcon.userPresetId)){setTapPlacementArmed(false);selectPlacementTool('select')}importedPresetToReveal=imported[0]?.id||null;requestAnimationFrame(revealImportedPreset);notify((mode==='append'?imported.length+'件のユーザープリセットを追加しました':'ユーザープリセットを'+imported.length+'件に置き換えました')+(imported[0]?'（先頭：「'+imported[0].name+'」）':''))}}catch(error){console.error('Preset import failed',error);notifyFailure('ユーザープリセットを読み込めませんでした',{error,retained:'保存済みのプリセットは変更していません',action:'ユーザープリセット用JSONを選び直してください。コンテンツ用JSONはコンテンツの読み込み項目を選んでください'})}finally{presetImportInput.value=''}};
 document.addEventListener('board-view-mode-changed',()=>{render();syncPresetHistory()});document.addEventListener('keydown',event=>{if(manager.hidden||editingPreset||!materialPane.contains(event.target)||event.target.closest('input,textarea,[contenteditable="true"]')||!(event.ctrlKey||event.metaKey))return;const key=event.key.toLowerCase();if(key==='z'||key==='y'){event.preventDefault();event.stopImmediatePropagation();restorePresetHistory(key==='y'||event.shiftKey)}},true);render();syncPresetHistory();return {syncReady:()=>!editingPreset,syncPayload:presetSyncPayload,prepareSync(value){parsePresetFile(JSON.stringify(value));const ids=new Set();for(const p of value.presets)if(typeof p.id!=='string'||ids.has(p.id))throw Error('プリセットのIDが不正です');else ids.add(p.id);return JSON.parse(JSON.stringify(value.presets))},replaceForSync(value){if(editingPreset)throw new Error('プリセットの名前を確定してください');if(!save(value,{record:false}))throw new Error('プリセットの保存に失敗しました');presetHistory.length=presetFuture.length=0;if(activeIcon?.userPresetId&&!presets.some(p=>p.id===activeIcon.userPresetId)){setTapPlacementArmed(false);selectPlacementTool('select')}syncPresetHistory()},dragImage,place,exportAll:exportPresets,chooseImport:choosePresetImport,registerSelection:(asSvg=false)=>{if(selectionHasImportedImages()){notify('画像を含む選択はプリセットに登録できません');return}const originals=current().filter(o=>selectedIds.includes(o.id));if(blocked()||(originals.length<2&&!(asSvg&&originals.length===1&&originals[0].type==='icon'&&originals[0].svgPreset===true)))return;const layout=document.querySelector('.layout'),phone=matchMedia('(max-width:850px)').matches,wasManaging=!manager.hidden,wasOpen=phone?layout.classList.contains('phone-materials-open'):materialPane.matches('.pinned,.palette-hover-open,:focus-within'),scroll=wasManaging?manager.scrollTop:materialCategories.scrollTop;const restore=()=>{if(!wasManaging)closeManager();if(wasManaging)manager.scrollTop=scroll;else materialCategories.scrollTop=scroll;if(!wasOpen){if(materialPane.contains(document.activeElement))document.activeElement.blur();materialPane.dispatchEvent(new Event('reset-material-hover'));if(phone)document.dispatchEvent(new Event('close-material-pane'))}else if(!phone)manage.focus({preventScroll:true})};if(matchMedia('(max-width:850px)').matches&&!document.querySelector('.layout').classList.contains('phone-materials-open'))document.querySelector('.phone-material-pin')?.click();manage.focus({preventScroll:true});openManager();try{registerSelection(restore,asSvg)}catch(error){restore();notifyFailure('SVG画像を登録できませんでした',{error})}},thumbnail:id=>{const p=presets.find(p=>p.id===id);return p?liveThumbnail(p.items):null}};
})();
// Desktop keeps history/save status together and the mode next to the menu.
(function placeDesktopModeBesideMenu(){
 const desktop=matchMedia('(min-width:851px)'),header=document.querySelector('.top'),home=header.querySelector('.header-mode-status'),mode=document.getElementById('editModeToggle'),menu=header.querySelector('.phone-menu-toggle'),group=document.createElement('div');group.className='header-mode-menu';header.insertBefore(group,menu);
 function update(){if(desktop.matches)group.append(mode);else home.querySelector('.header-history-actions').after(mode)}
 desktop.addEventListener('change',update);update();
})();

// Reflect the actual popup state on its opener, including indirect dismissal.
(()=>{
 const watched=new WeakSet();let pending=false;
 function sync(){pending=false;const buttons=[...document.querySelectorAll('button[aria-haspopup="menu"][aria-controls]')],menus=new Map(),counts=new Map();for(const button of buttons){const id=button.getAttribute('aria-controls');counts.set(id,(counts.get(id)||0)+1);if(!menus.has(id))menus.set(id,document.getElementById(id))}for(const menu of document.querySelectorAll('[role="menu"]'))if(!menus.has(menu.id))menus.set(menu.id,menu);const visible=new Map();for(const [id,menu] of menus)visible.set(id,!!menu&&(id==='headerActions'?document.querySelector('.top').classList.contains('phone-menu-open'):!menu.hidden&&menu.getClientRects().length>0));for(const menu of menus.values())if(menu?._openerResolver)menu._opener=menu._openerResolver();const openers=new Set([...menus.values()].filter(menu=>menu&&visible.get(menu.id)&&menu._opener).map(menu=>menu._opener));const shared=new Set(['userPresetMenu','phaseItemMenu','contentItemMenu','objectContextMenu']);const changes=buttons.map(button=>{const id=button.getAttribute('aria-controls'),menu=menus.get(id);return {button,open:openers.has(button)||!!visible.get(id)&&!menu?._opener&&!shared.has(id)&&counts.get(id)===1}});for(const {button,open} of changes){if(button.classList.contains('menu-open-trigger')!==open)button.classList.toggle('menu-open-trigger',open);const value=String(open);if(button.getAttribute('aria-expanded')!==value)button.setAttribute('aria-expanded',value)}}

 function schedule(){if(pending)return;pending=true;queueMicrotask(sync)}
 function watch(){for(const menu of document.querySelectorAll('[role="menu"],#headerActions')){if(watched.has(menu))continue;watched.add(menu);new MutationObserver(schedule).observe(menu,{attributes:true,attributeFilter:['hidden','style']})}schedule()}
 for(const id of ['pages','objectList','contentOptions','userPresetManager']){const list=document.getElementById(id);if(list)new MutationObserver(schedule).observe(list,{childList:true,subtree:true})}new MutationObserver(watch).observe(document.body,{childList:true});new MutationObserver(schedule).observe(document.querySelector('.top'),{attributes:true,attributeFilter:['class']});watch();
})();

// Match the mode button's left edge to the visible desktop property pane.
(()=>{const header=document.querySelector('.app>.top'),button=document.getElementById('editModeToggle'),desktop=matchMedia('(min-width:851px)');let frame=0;function sync(){frame=0;if(!desktop.matches)return;const pane=window.Bolxiv?.pngPreview?.active?document.querySelector('.png-preview-settings'):(document.getElementById('desktopPhaseSidebar')||document.getElementById('toggleInspector')?.closest('.property-group'));if(!pane?.getClientRects().length)return;const target=pane.getBoundingClientRect(),rect=button.getBoundingClientRect();if(!target.width)return;const detached=pane.id==='desktopPhaseSidebar'&&document.querySelector('.layout').classList.contains('desktop-tools-two-columns'),targetLeft=target.left+(detached?(parseFloat(getComputedStyle(pane).paddingLeft)||0):0);const width=Math.max(148,Math.min(240,rect.right-targetLeft)),value=width+'px';if(header.style.getPropertyValue('--mode-button-width')!==value)header.style.setProperty('--mode-button-width',value)}function schedule(){if(!frame)frame=requestAnimationFrame(sync)}const observer=new ResizeObserver(schedule);for(const node of [header,document.querySelector('.layout'),document.getElementById('toggleInspector')?.closest('.property-group'),document.getElementById('propertyPanel'),document.querySelector('.png-preview-settings')])if(node)observer.observe(node);const stateObserver=new MutationObserver(schedule);for(const node of [document.body,document.querySelector('.layout')])if(node)stateObserver.observe(node,{attributes:true,attributeFilter:['class']});desktop.addEventListener('change',schedule);window.addEventListener('resize',schedule);schedule()})();
// ===== Object appearance clipboard =====
(()=>{
 const menu=document.getElementById('objectContextMenu'),toggle=document.createElement('button'),sub=document.createElement('div');
 toggle.id='contextClipboardToggle';toggle.type='button';toggle.textContent='コピー・貼り付け ▸';toggle.setAttribute('role','menuitem');toggle.setAttribute('aria-haspopup','menu');toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-controls','contextClipboardMenu');
 const copy=document.getElementById('contextCopy'),paste=document.getElementById('contextPaste');menu.insertBefore(toggle,copy);sub.id='contextClipboardMenu';sub.className='object-context-menu';sub.setAttribute('role','menu');sub.setAttribute('aria-label','コピー・貼り付け');sub.hidden=true;menu.append(sub);copy.textContent='オブジェクトをコピー';paste.textContent='オブジェクトを貼り付け';sub.append(copy,paste);
 const separator=document.createElement('div');separator.className='context-separator';separator.setAttribute('role','separator');sub.append(separator);
 const make=(id,label)=>{const b=createMenuAction({label});b.id=id;sub.append(b);return b},copyStyle=make('contextCopyAppearance','見た目をコピー'),pasteStyle=make('contextPasteAppearance','見た目を貼り付け');
 let clipboard=null;
 const fields=['color','strokeColor','opacity','width','height','gradient','fillType','innerSize','angle','fontSize','lineStyle','arrowEnds','arrowSize','brightness'];
 const kind=o=>JSON.stringify([objectCategory(o),o.type,o.type==='icon'?objectTitle(o):o.type==='segment'?objectTitle(o):'']);
 const items=()=>{const ids=JSON.parse(menu.dataset.ids||'[]');return current().filter(o=>ids.includes(o.id))};
 const blocked=()=>boardReadOnly||phaseComparisonActive()||!!window.Bolxiv?.pngPreview?.active||!!window.Bolxiv?.fieldGuideEditor?.active;
 const compatible=objects=>clipboard&&objects.length&&objects.every(o=>!o.locked&&kind(o)===clipboard.kind);
 function close(){sub._openedByHover=false;sub.hidden=true;toggle.setAttribute('aria-expanded','false')}
 function open(fromHover=false){if(!sub.hidden){if(fromHover!==true)close();return}document.getElementById('contextGroupMenu').hidden=true;document.getElementById('contextGroupMenuToggle').setAttribute('aria-expanded','false');addPhoneMenuClose(sub,()=>{close();toggle.focus()});sub.hidden=false;toggle.setAttribute('aria-expanded','true');const r=toggle.getBoundingClientRect();sub.style.left=Math.max(4,Math.min(r.right+4+sub.offsetWidth>innerWidth?r.left-sub.offsetWidth-4:r.right+4,innerWidth-sub.offsetWidth-4))+'px';sub.style.top=Math.max(4,Math.min(r.top,innerHeight-sub.offsetHeight-4))+'px';if(fromHover!==true)sub.querySelector('button:not(:disabled)')?.focus({preventScroll:true})}
 bindSubmenuHover(toggle,sub,open,close);
 toggle.onclick=open;toggle.onkeydown=e=>{if(e.key==='ArrowRight'){e.preventDefault();if(sub.hidden)open();sub.querySelector('button:not(:disabled)')?.focus()}};sub.addEventListener('keydown',e=>{if(['Escape','ArrowLeft'].includes(e.key)){e.preventDefault();e.stopPropagation();close();toggle.focus()}});
 document.getElementById('contextGroupMenuToggle').addEventListener('click',close);toggle.addEventListener('click',()=>{const preset=document.getElementById('contextPresetToggle');if(preset.getAttribute('aria-expanded')==='true')preset.click()});
 const previousOpen=openObjectContextMenu;openObjectContextMenu=function(...args){close();previousOpen(...args);const objects=items();copyStyle.disabled=blocked()||objects.length!==1;pasteStyle.disabled=blocked()||!compatible(objects)};
 const previousClose=closeObjectContextMenu;closeObjectContextMenu=function(){close();previousClose()};
 copyStyle.onclick=()=>{const objects=items();if(blocked()||objects.length!==1)return;const o=objects[0];clipboard={kind:kind(o),values:Object.fromEntries(fields.filter(k=>Object.hasOwn(o,k)).map(k=>[k,o[k]]))};closeObjectContextMenu();notify('見た目をコピーしました')};
 pasteStyle.onclick=()=>{const objects=items();if(blocked()||!compatible(objects))return;const updates=objects.map(o=>{const next={...o};for(const key of fields){if(Object.hasOwn(clipboard.values,key))next[key]=clipboard.values[key];else delete next[key]}if(o.type==='image'){next.height=o.height*next.width/o.width}return next});closeObjectContextMenu();if(updates.every((o,i)=>JSON.stringify(o)===JSON.stringify(objects[i]))){notify('見た目はすでに同じ設定です');return}recordHistory();objects.forEach((o,i)=>{for(const key of fields){if(Object.hasOwn(updates[i],key))o[key]=updates[i][key];else delete o[key]}});renderAndSave();notify(objects.length+'個のオブジェクトに見た目を貼り付けました')};
})();

// Show only keyboard shortcuts implemented for the normal object menu.
for(const [id,key] of [["contextCopy","Ctrl+C"],["contextPaste","Ctrl+V"],["contextDelete","Delete"]])document.getElementById(id).dataset.shortcut=key;

for(const [id,key] of [['contextDuplicate','Ctrl+D'],['contextGroup','Ctrl+G'],['contextUngroup','Ctrl+Shift+G']])document.getElementById(id).dataset.shortcut=key;
